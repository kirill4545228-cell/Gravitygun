package com.gravitygun.client;

import com.gravitygun.client.model.GunAnimController;

/** Client-only runtime state of the first person gun. */
public final class ClientState {
    private ClientState() {}

    public static final GunAnimController ANIM = new GunAnimController();
    public static boolean lastUse;
    public static boolean suppressUse;
    public static boolean wasHolding;
    public static int lastSlot = -1;
    /** Cannon: true while the player is charging a shot. */
    public static boolean charging;
    public static int chargeTicks;
    /** Real time (ms) when the mode was switched last, used by the HUD flash. */
    public static long switchAtMs;

    public static final int CHARGE_MIN = 24;
    public static final int CHARGE_FULL = 40;
}
