package com.gravitygun.client;

import com.gravitygun.client.model.GunAnimController;

/** Client-only runtime state of the first person gun. */
public final class ClientState {
    private ClientState() {}

    public static final GunAnimController ANIM = new GunAnimController();
    public static boolean attracting;
    public static boolean lastUse;
    public static boolean suppressUse;
    public static boolean wasHolding;
    public static int lastSlot = -1;
}
