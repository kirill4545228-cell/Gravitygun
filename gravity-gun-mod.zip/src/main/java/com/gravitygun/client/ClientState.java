package com.gravitygun.client;

import com.gravitygun.client.model.GunAnimController;

/** Client-only runtime state of the first person gun. */
public final class ClientState {
    private ClientState() {}

    public static final GunAnimController ANIM = new GunAnimController();
    public static boolean lastUse;
    public static boolean suppressUse;
    public static boolean wasHolding;
    public static int lastSlot = -1;
    /** Grab mode: the server confirmed that an object is currently held. */
    public static boolean holdingObject;
    /** Safety on: the gun is lowered and does nothing. */
    public static boolean holstered;
    /** Cannon: true while the player is charging a shot. */
    public static boolean charging;
    public static int chargeTicks;
    /** Ticks without any activity, after enough of them the gun inspects itself. */
    public static int idleTicks;
    /** Real time (ms) when the mode was switched last, used by the HUD flash. */
    public static long switchAtMs;

    public static final int CHARGE_MIN = 24;
    public static final int CHARGE_FULL = 40;
    public static final int CHARGE_OVER = 80;
    public static final int INSPECT_AFTER_TICKS = 600;
}
