package com.gravitygun.client.model;

/**
 * Small state machine: EQUIP / LAUNCH play once, IDLE / ATTRACT loop,
 * with a short cross-fade between animations.
 */
public final class GunAnimController {
    private GunAnim current = GunAnimData.EQUIP;
    private float time = 0f;
    private float[][] fromPose = null;
    private float blend = 1f;
    private float blendTime = 0.1f;
    private double lastNow = -1;
    private float[][] shown = GunAnim.newPose();

    public GunAnim current() {
        return current;
    }

    /** Restarts the given animation (used for equip / launch). */
    public void trigger(GunAnim anim, float fade) {
        switchTo(anim, fade);
    }

    private void switchTo(GunAnim anim, float fade) {
        fromPose = GunAnim.lerp(shown, shown, 0f);
        blend = 0f;
        blendTime = Math.max(0.001f, fade);
        current = anim;
        time = 0f;
    }

    /** @param now real time in seconds, @param attracting RMB is held */
    public float[][] update(double now, boolean attracting) {
        float dt = lastNow < 0 ? 0f : (float) (now - lastNow);
        lastNow = now;
        if (dt < 0f || dt > 0.25f) dt = 0f;
        time += dt;
        if (blend < 1f) blend = Math.min(1f, blend + dt / blendTime);

        if (!current.loop) {
            if (time >= current.length) {
                switchTo(attracting ? GunAnimData.ATTRACT : GunAnimData.IDLE, 0.2f);
            }
        } else if (attracting && current == GunAnimData.IDLE) {
            switchTo(GunAnimData.ATTRACT, 0.15f);
        } else if (!attracting && current == GunAnimData.ATTRACT) {
            switchTo(GunAnimData.IDLE, 0.25f);
        }

        float[][] target = current.sample(time);
        if (fromPose != null && blend < 1f) {
            float s = blend * blend * (3f - 2f * blend);
            shown = GunAnim.lerp(fromPose, target, s);
        } else {
            shown = target;
        }
        return shown;
    }
}
