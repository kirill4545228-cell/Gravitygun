package com.gravitygun.client.model;

/**
 * Plays animations: a once-animation runs to its end and then continues with the follow-up animation
 * (a loop, usually IDLE or a hold loop). Switching between animations is cross-faded.
 */
public final class GunAnimController {
    private GunAnim current = GunAnims.EQUIP;
    private GunAnim next = GunAnimData.IDLE;
    private float time = 0f;
    private float[][] fromPose = null;
    private float blend = 1f;
    private float blendTime = 0.1f;
    private double lastNow = -1;
    private float[][] shown = GunAnim.newPose();

    public GunAnim current() {
        return current;
    }

    /** Starts {@code anim}; when it ends (if it does not loop) {@code then} is played. */
    public void play(GunAnim anim, GunAnim then, float fade) {
        fromPose = GunAnim.lerp(shown, shown, 0f);
        blend = 0f;
        blendTime = Math.max(0.001f, fade);
        current = anim;
        next = then == null ? GunAnimData.IDLE : then;
        time = 0f;
    }

    /** @param now real time in seconds */
    public float[][] update(double now) {
        float dt = lastNow < 0 ? 0f : (float) (now - lastNow);
        lastNow = now;
        if (dt < 0f || dt > 0.25f) dt = 0f;
        time += dt;
        if (blend < 1f) blend = Math.min(1f, blend + dt / blendTime);

        if (!current.loop && time >= current.length) {
            float over = time - current.length;
            GunAnim n = next;
            play(n, GunAnimData.IDLE, 0.15f);
            time = over;
        }

        float[][] target = current.sample(time);
        if (fromPose != null && blend < 1f) {
            float s = blend * blend * (3f - 2f * blend);
            shown = GunAnim.lerp(fromPose, target, s);
        } else {
            shown = target;
        }
        return shown;
    }
}
