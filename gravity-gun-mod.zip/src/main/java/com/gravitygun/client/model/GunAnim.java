package com.gravitygun.client.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Blockbench-style keyframe animation (position / rotation / scale per bone).
 * No Minecraft dependencies, so it can be unit tested on its own.
 *
 * Pose layout per bone: [posX,posY,posZ, rotX,rotY,rotZ, sclX,sclY,sclZ]
 */
public final class GunAnim {
    public static final int BONES = GunModelData.NAMES.length;

    public static final class Key {
        final float time;
        final float[] v;
        final boolean smooth;

        Key(float time, float x, float y, float z, boolean smooth) {
            this.time = time;
            this.v = new float[]{x, y, z};
            this.smooth = smooth;
        }
    }

    public static Key key(float time, float x, float y, float z, boolean smooth) {
        return new Key(time, x, y, z, smooth);
    }

    public final String name;
    public final float length;
    public final boolean loop;
    private final Key[][][] channels = new Key[BONES][3][];

    public GunAnim(String name, float length, boolean loop) {
        this.name = name;
        this.length = length;
        this.loop = loop;
    }

    public void channel(int bone, int channel, Key... keys) {
        List<Key> list = new ArrayList<>(List.of(keys));
        list.sort((a, b) -> Float.compare(a.time, b.time));
        channels[bone][channel] = list.toArray(new Key[0]);
    }

    public static float[][] newPose() {
        float[][] p = new float[BONES][9];
        for (float[] b : p) {
            b[6] = 1f;
            b[7] = 1f;
            b[8] = 1f;
        }
        return p;
    }

    /** Samples this animation at the given time (seconds) into a new pose. */
    public float[][] sample(float time) {
        if (loop) {
            time = length > 0 ? time % length : 0;
            if (time < 0) time += length;
        } else {
            time = Math.max(0f, Math.min(length, time));
        }
        float[][] pose = newPose();
        for (int b = 0; b < BONES; b++) {
            for (int c = 0; c < 3; c++) {
                Key[] keys = channels[b][c];
                if (keys == null || keys.length == 0) continue;
                float[] v = eval(keys, time);
                System.arraycopy(v, 0, pose[b], c * 3, 3);
            }
        }
        return pose;
    }

    private static float[] eval(Key[] k, float t) {
        if (t <= k[0].time) return k[0].v.clone();
        int last = k.length - 1;
        if (t >= k[last].time) return k[last].v.clone();
        int i = 0;
        while (i < last && k[i + 1].time <= t) i++;
        Key a = k[i];
        Key b = k[i + 1];
        float f = (t - a.time) / (b.time - a.time);
        float[] out = new float[3];
        if (a.smooth || b.smooth) {
            Key p0 = i > 0 ? k[i - 1] : a;
            Key p3 = i + 2 <= last ? k[i + 2] : b;
            for (int j = 0; j < 3; j++) {
                out[j] = catmull(p0.v[j], a.v[j], b.v[j], p3.v[j], f);
            }
        } else {
            for (int j = 0; j < 3; j++) out[j] = a.v[j] + (b.v[j] - a.v[j]) * f;
        }
        return out;
    }

    private static float catmull(float p0, float p1, float p2, float p3, float t) {
        float t2 = t * t;
        float t3 = t2 * t;
        return 0.5f * ((2f * p1) + (-p0 + p2) * t
                + (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2
                + (-p0 + 3f * p1 - 3f * p2 + p3) * t3);
    }

    public static float[][] lerp(float[][] a, float[][] b, float f) {
        float[][] r = new float[BONES][9];
        for (int i = 0; i < BONES; i++) {
            for (int j = 0; j < 9; j++) {
                float d = b[i][j] - a[i][j];
                if (j >= 3 && j < 6) {
                    // rotations: always take the short way round (avoids spinning back when a loop restarts)
                    d -= 360f * Math.round(d / 360f);
                }
                r[i][j] = a[i][j] + d * f;
            }
        }
        return r;
    }
}
