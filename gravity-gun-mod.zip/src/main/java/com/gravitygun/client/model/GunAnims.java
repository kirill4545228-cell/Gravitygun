package com.gravitygun.client.model;

import static com.gravitygun.client.model.GunModelData.*;

/** Hand written animations that are not in the Blockbench file: equip and mode switch. */
public final class GunAnims {
    private GunAnims() {}

    public static final GunAnim EQUIP = buildEquip();
    public static final GunAnim SWITCH = buildSwitch();

    private static GunAnim.Key k(float t, float x, float y, float z) {
        return GunAnim.key(t, x, y, z, true);
    }

    private static void claws(GunAnim a, float t0, float v0, float t1, float v1, float t2, float v2, float t3, float v3) {
        a.channel(B_CLAW_TOP, 1, k(t0, v0, 0, 0), k(t1, v1, 0, 0), k(t2, v2, 0, 0), k(t3, v3, 0, 0));
        a.channel(B_CLAW_BOTTOM, 1, k(t0, -v0, 0, 0), k(t1, -v1, 0, 0), k(t2, -v2, 0, 0), k(t3, -v3, 0, 0));
        a.channel(B_CLAW_RIGHT, 1, k(t0, 0, -v0, 0), k(t1, 0, -v1, 0), k(t2, 0, -v2, 0), k(t3, 0, -v3, 0));
        a.channel(B_CLAW_LEFT, 1, k(t0, 0, v0, 0), k(t1, 0, v1, 0), k(t2, 0, v2, 0), k(t3, 0, v3, 0));
    }

    private static void gauge(GunAnim a, int bone, float t0, float t1, float t2, float len) {
        float lo = 0.25f;
        a.channel(bone, 2,
                k(0f, lo, lo, lo), k(t0, lo, lo, lo), k(t1, 1f, 1f, 1f), k(t2, lo, lo, lo), k(len, lo, lo, lo));
    }

    /** Gun is raised from below, claws snap shut, rings spin up, gauges light up one after another. */
    private static GunAnim buildEquip() {
        float len = 0.9f;
        GunAnim a = new GunAnim("equip", len, false);
        a.channel(B_GUN, 0, k(0f, 0, -14, 10), k(0.35f, 0, -3, 3), k(0.6f, 0, 0.8f, -0.8f), k(len, 0, 0, 0));
        a.channel(B_GUN, 1, k(0f, 55, -12, 0), k(0.35f, 10, -2, 0), k(0.6f, -4, 1, 0), k(len, 0, 0, 0));
        claws(a, 0f, 28f, 0.3f, 28f, 0.5f, -4f, len, 0f);
        a.channel(B_RING_A, 1, k(0f, 0, 0, 0), k(len, 0, 0, 360));
        a.channel(B_RING_B, 1, k(0f, 0, 0, 0), k(len, 0, 0, -540));
        a.channel(B_ROTOR, 1, k(0f, 0, 0, 0), k(len, 0, 0, -720));
        a.channel(B_CORE, 2, k(0f, 0.3f, 0.3f, 0.3f), k(0.5f, 1.6f, 1.6f, 1.6f), k(len, 0.9f, 0.9f, 0.9f));
        a.channel(B_PROJECTILE, 2, k(0f, 0, 0, 0));
        gauge(a, B_GAUGE_1, 0.1f, 0.25f, 0.5f, len);
        gauge(a, B_GAUGE_2, 0.3f, 0.5f, 0.75f, len);
        gauge(a, B_GAUGE_3, 0.5f, 0.7f, 0.88f, len);
        return a;
    }

    /** Short "ratchet" animation played when the mode changes (the glow colour changes with it). */
    private static GunAnim buildSwitch() {
        float len = 0.6f;
        GunAnim a = new GunAnim("switch", len, false);
        a.channel(B_GUN, 0, k(0f, 0, 0, 0), k(0.1f, 0, 0.5f, 3), k(0.3f, 0, 0, -0.5f), k(len, 0, 0, 0));
        a.channel(B_GUN, 1, k(0f, 0, 0, 0), k(0.1f, 4, 0, 0), k(len, 0, 0, 0));
        claws(a, 0f, 0f, 0.08f, 22f, 0.25f, -2f, len, 0f);
        a.channel(B_RING_A, 1, k(0f, 0, 0, 0), k(len, 0, 0, 360));
        a.channel(B_RING_B, 1, k(0f, 0, 0, 0), k(len, 0, 0, -540));
        a.channel(B_ROTOR, 1, k(0f, 0, 0, 0), k(len, 0, 0, -720));
        a.channel(B_CORE, 2, k(0f, 0.9f, 0.9f, 0.9f), k(0.1f, 0.3f, 0.3f, 0.3f), k(0.25f, 2.0f, 2.0f, 2.0f), k(len, 0.9f, 0.9f, 0.9f));
        a.channel(B_PROJECTILE, 2, k(0f, 0, 0, 0));
        gauge(a, B_GAUGE_1, 0.0f, 0.1f, 0.3f, len);
        gauge(a, B_GAUGE_2, 0.1f, 0.2f, 0.4f, len);
        gauge(a, B_GAUGE_3, 0.2f, 0.3f, 0.5f, len);
        return a;
    }
}
