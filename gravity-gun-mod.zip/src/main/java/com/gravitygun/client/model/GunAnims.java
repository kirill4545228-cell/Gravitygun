package com.gravitygun.client.model;

import static com.gravitygun.client.model.GunModelData.*;

import java.util.concurrent.ThreadLocalRandom;

/** Hand written inspect animations (the Blockbench file only has one), chosen at random. */
public final class GunAnims {
    private GunAnims() {}

    public static final GunAnim INSPECT_SIDE = buildSide();
    public static final GunAnim INSPECT_MECH = buildMech();
    public static final GunAnim INSPECT_SHAKE = buildShake();

    private static final GunAnim[] INSPECTS = {GunAnimData.INSPECT, INSPECT_SIDE, INSPECT_MECH, INSPECT_SHAKE};
    private static int last = -1;

    /** A random inspect animation, never the same one twice in a row. */
    public static GunAnim randomInspect() {
        int n;
        do {
            n = ThreadLocalRandom.current().nextInt(INSPECTS.length);
        } while (n == last);
        last = n;
        return INSPECTS[n];
    }

    private static GunAnim.Key k(float t, float x, float y, float z) {
        return GunAnim.key(t, x, y, z, true);
    }

    private static GunAnim.Key sharp(float t, float x, float y, float z) {
        return GunAnim.key(t, x, y, z, false);
    }

    private static void flex(GunAnim a, int claw, int tip, float t) {
        a.channel(claw, 1, k(0f, 0, 0, 0), k(t, 0, 0, 0), k(t + 0.35f, -28, 0, 0), k(t + 0.8f, 0, 0, 0));
        a.channel(tip, 1, k(0f, 0, 0, 0), k(t + 0.1f, 0, 0, 0), k(t + 0.45f, 30, 0, 0), k(t + 0.9f, 0, 0, 0));
    }

    /** The gun is turned towards the player and shown from both sides, the claws flex one by one. */
    private static GunAnim buildSide() {
        float len = 5.0f;
        GunAnim a = new GunAnim("inspect_side", len, false).setBase(GunAnimData.IDLE);
        a.channel(B_GRAVITY_GUN, 0, k(0f, 0, 0, 0), k(0.9f, 0, 1.5f, 5), k(4.0f, 0, 1.5f, 5), k(len, 0, 0, 0));
        a.channel(B_GRAVITY_GUN, 1, k(0f, 0, 0, 0), k(0.9f, 6, -38, -18), k(2.2f, 6, -38, -18),
                k(3.2f, 0, 30, 14), k(4.0f, 0, 30, 14), k(len, 0, 0, 0));
        flex(a, B_CLAW_A, B_CLAW_TIP_A, 1.2f);
        flex(a, B_CLAW_B, B_CLAW_TIP_B, 1.6f);
        flex(a, B_CLAW_C, B_CLAW_TIP_C, 2.0f);
        a.channel(B_CORE_GLOW, 2, k(0f, 1, 1, 1), k(2.4f, 1, 1, 1), k(2.9f, 1.5f, 1.5f, 1.2f), k(3.5f, 1, 1, 1), k(len, 1, 1, 1));
        a.channel(B_ROTOR, 1, k(0f, 0, 0, 0), k(len, 0, 0, 720));
        a.channel(B_GYRO, 1, k(0f, 0, 0, 0), k(len, 0, 0, -720));
        return a;
    }

    /** The barrel is lifted, the rotor spins up and the indicator bars run one after another. */
    private static GunAnim buildMech() {
        float len = 4.5f;
        GunAnim a = new GunAnim("inspect_mech", len, false).setBase(GunAnimData.IDLE);
        a.channel(B_GRAVITY_GUN, 0, k(0f, 0, 0, 0), k(0.8f, 0, 2, 3), k(3.6f, 0, 2, 3), k(len, 0, 0, 0));
        a.channel(B_GRAVITY_GUN, 1, k(0f, 0, 0, 0), k(0.8f, -22, 0, 0), k(1.4f, -22, 0, 0), k(2.2f, -22, 10, 6),
                k(3.2f, -22, -10, -6), k(3.6f, -22, 0, 0), k(len, 0, 0, 0));
        a.channel(B_ROTOR, 1, k(0f, 0, 0, 0), k(1.0f, 0, 0, 0), k(2.5f, 0, 0, 1440), k(len, 0, 0, 2160));
        a.channel(B_GYRO, 1, k(0f, 0, 0, 0), k(1.0f, 0, 0, 0), k(2.5f, 0, 0, -1440), k(len, 0, 0, -2160));
        int[] bars = {B_BAR_0, B_BAR_1, B_BAR_2, B_BAR_3, B_BAR_4};
        for (int i = 0; i < bars.length; i++) {
            float t = 1.0f + 0.35f * i;
            a.channel(bars[i], 2, k(0f, 1, 0.4f, 1), k(t, 1, 0.4f, 1), k(t + 0.4f, 1, 1.3f, 1), k(t + 0.9f, 1, 0.4f, 1), k(len, 1, 0.4f, 1));
        }
        a.channel(B_CORE_GLOW, 2, k(0f, 1, 1, 1), k(1.2f, 1.6f, 1.6f, 1.2f), k(3.0f, 1.6f, 1.6f, 1.2f), k(3.6f, 1, 1, 1), k(len, 1, 1, 1));
        a.channel(B_ANTENNA, 1, k(0f, 0, 0, 0), k(1.5f, 14, 0, 10), k(2.5f, -14, 0, -10), k(3.5f, 10, 0, 6), k(len, 0, 0, 0));
        a.channel(B_CABLE, 1, k(0f, 0, 0, 0), k(1.5f, 0, -12, 0), k(3.0f, 0, 12, 0), k(len, 0, 0, 0));
        return a;
    }

    /** The gun is shaken like a stuck device, then all claws flare and snap shut. */
    private static GunAnim buildShake() {
        float len = 2.6f;
        GunAnim a = new GunAnim("inspect_shake", len, false).setBase(GunAnimData.IDLE);
        java.util.List<GunAnim.Key> pos = new java.util.ArrayList<>();
        java.util.List<GunAnim.Key> rot = new java.util.ArrayList<>();
        pos.add(sharp(0f, 0, 0, 0));
        rot.add(sharp(0f, 0, 0, 0));
        for (int i = 0; i < 8; i++) {
            float t = 0.3f + 0.1f * i;
            float sign = i % 2 == 0 ? 1f : -1f;
            float amp = 1.2f * (1f - i / 9f);
            pos.add(sharp(t, sign * amp, -sign * 0.7f * amp, 0.5f * amp));
            rot.add(sharp(t, sign * 3f * (amp / 1.2f), sign * 2f * (amp / 1.2f), -sign * 6f * (amp / 1.2f)));
        }
        pos.add(k(1.2f, 0, 0, 0));
        rot.add(k(1.2f, 0, 0, 0));
        pos.add(k(1.95f, 0, 0.4f, 2.5f));
        rot.add(k(1.95f, -4, 0, 0));
        pos.add(k(len, 0, 0, 0));
        rot.add(k(len, 0, 0, 0));
        a.channel(B_GRAVITY_GUN, 0, pos.toArray(new GunAnim.Key[0]));
        a.channel(B_GRAVITY_GUN, 1, rot.toArray(new GunAnim.Key[0]));
        int[] claws = {B_CLAW_A, B_CLAW_B, B_CLAW_C};
        int[] tips = {B_CLAW_TIP_A, B_CLAW_TIP_B, B_CLAW_TIP_C};
        for (int i = 0; i < 3; i++) {
            a.channel(claws[i], 1, sharp(0f, 0, 0, 0), sharp(1.2f, 0, 0, 0), k(1.45f, -30, 0, 0), sharp(1.8f, -30, 0, 0), sharp(1.95f, 0, 0, 0), sharp(len, 0, 0, 0));
            a.channel(tips[i], 1, sharp(0f, 0, 0, 0), sharp(1.2f, 0, 0, 0), k(1.45f, 35, 0, 0), sharp(1.8f, 35, 0, 0), sharp(1.95f, 0, 0, 0), sharp(len, 0, 0, 0));
        }
        a.channel(B_CORE_GLOW, 2, k(0f, 1, 1, 1), k(1.9f, 1, 1, 1), k(2.0f, 1.8f, 1.8f, 1.3f), k(2.5f, 1, 1, 1), k(len, 1, 1, 1));
        return a;
    }
}
