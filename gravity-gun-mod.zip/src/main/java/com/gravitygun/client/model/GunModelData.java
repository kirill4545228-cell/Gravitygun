package com.gravitygun.client.model;

/** AUTO-GENERATED from blockbench/gravity_gun.bbmodel */
public final class GunModelData {
    private GunModelData() {}

    /** Bone names, order matches pose arrays. */
    public static final String[] NAMES = {"gun", "ring", "core", "prong_top", "prong_bottom", "prong_left", "prong_right"};
    public static final int[] PARENT = {-1, 0, 0, 0, 0, 0, 0};
    public static final float[][] PIVOT = {
        {0.0f, 0.0f, 0.0f},
        {0.0f, 0.0f, -5.5f},
        {0.0f, 0.0f, -8.5f},
        {0.0f, 2.0f, -8.6f},
        {0.0f, -2.0f, -8.6f},
        {-2.0f, 0.0f, -8.6f},
        {2.0f, 0.0f, -8.6f},
    };
    /** Cubes per bone: x0,y0,z0,x1,y1,z1,u0,v0,u1,v1,emissive(0 no,1 yes,2 bright core) */
    public static final float[][][] CUBES = {
        {
            {-2.5f, -2.5f, -2.0f, 2.5f, 2.5f, 8.0f, 0.0f, 0.0f, 4.0f, 4.0f, 0.0f}, // body
            {-2.0f, 2.5f, -1.0f, 2.0f, 3.0f, 7.0f, 4.0f, 0.0f, 8.0f, 4.0f, 0.0f}, // body_top_plate
            {-0.5f, 3.0f, 0.0f, 0.5f, 3.8f, 3.0f, 12.0f, 0.0f, 16.0f, 4.0f, 0.0f}, // sight
            {-2.0f, -2.0f, 8.0f, 2.0f, 2.0f, 10.0f, 12.0f, 0.0f, 16.0f, 4.0f, 0.0f}, // rear_cap
            {-1.0f, -1.0f, 10.0f, 1.0f, 1.0f, 10.6f, 4.0f, 4.0f, 8.0f, 8.0f, 1.0f}, // rear_core
            {-1.0f, -7.0f, 3.0f, 1.0f, -2.5f, 6.0f, 0.0f, 8.0f, 4.0f, 12.0f, 0.0f}, // grip
            {-1.0f, -7.6f, 3.0f, 1.0f, -7.0f, 6.0f, 12.0f, 4.0f, 16.0f, 8.0f, 0.0f}, // grip_guard
            {-3.1f, -1.0f, 0.0f, -2.5f, 1.0f, 5.0f, 4.0f, 4.0f, 8.0f, 8.0f, 1.0f}, // cell_left
            {2.5f, -1.0f, 0.0f, 3.1f, 1.0f, 5.0f, 4.0f, 4.0f, 8.0f, 8.0f, 1.0f}, // cell_right
            {-1.5f, -1.5f, -8.0f, 1.5f, 1.5f, -2.0f, 4.0f, 0.0f, 8.0f, 4.0f, 0.0f}, // barrel
            {-2.0f, -2.0f, -3.0f, 2.0f, 2.0f, -2.0f, 12.0f, 0.0f, 16.0f, 4.0f, 0.0f}, // barrel_ring_a
            {-2.0f, -2.0f, -8.6f, 2.0f, 2.0f, -8.0f, 12.0f, 0.0f, 16.0f, 4.0f, 0.0f}, // barrel_ring_b
        },
        {
            {-3.6f, 2.6f, -6.0f, 3.6f, 3.6f, -5.0f, 0.0f, 4.0f, 4.0f, 8.0f, 0.0f}, // ring_t
            {-3.6f, -3.6f, -6.0f, 3.6f, -2.6f, -5.0f, 0.0f, 4.0f, 4.0f, 8.0f, 0.0f}, // ring_b
            {-3.6f, -2.6f, -6.0f, -2.6f, 2.6f, -5.0f, 0.0f, 4.0f, 4.0f, 8.0f, 0.0f}, // ring_l
            {2.6f, -2.6f, -6.0f, 3.6f, 2.6f, -5.0f, 0.0f, 4.0f, 4.0f, 8.0f, 0.0f}, // ring_r
        },
        {
            {-0.9f, -0.9f, -9.4f, 0.9f, 0.9f, -7.6f, 8.0f, 4.0f, 12.0f, 8.0f, 2.0f}, // core_cube
        },
        {
            {-0.6f, 1.4f, -13.0f, 0.6f, 2.6f, -8.6f, 8.0f, 0.0f, 12.0f, 4.0f, 0.0f}, // prong_top_c
        },
        {
            {-0.6f, -2.6f, -13.0f, 0.6f, -1.4f, -8.6f, 8.0f, 0.0f, 12.0f, 4.0f, 0.0f}, // prong_bottom_c
        },
        {
            {-2.6f, -0.6f, -13.0f, -1.4f, 0.6f, -8.6f, 8.0f, 0.0f, 12.0f, 4.0f, 0.0f}, // prong_left_c
        },
        {
            {1.4f, -0.6f, -13.0f, 2.6f, 0.6f, -8.6f, 8.0f, 0.0f, 12.0f, 4.0f, 0.0f}, // prong_right_c
        },
    };
}
