package com.gravitygun.client.model;

/** AUTO-GENERATED from blockbench/gravity_gun.bbmodel animations */
public final class GunAnimData {
    private GunAnimData() {}

    public static final GunAnim EQUIP = buildEquip();
    public static final GunAnim IDLE = buildIdle();
    public static final GunAnim ATTRACT = buildAttract();
    public static final GunAnim LAUNCH = buildLaunch();

    private static GunAnim buildEquip() {
        GunAnim a = new GunAnim("first_person_equip", 0.7f, false);
        a.channel(0, 0, GunAnim.key(0.0f, 0.0f, -10.0f, 8.0f, true), GunAnim.key(0.45f, 0.0f, 1.0f, -1.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(0, 1, GunAnim.key(0.0f, 70.0f, -15.0f, 0.0f, true), GunAnim.key(0.45f, -6.0f, 2.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(1, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.7f, 0.0f, 0.0f, 360.0f, false));
        a.channel(2, 2, GunAnim.key(0.0f, 0.2f, 0.2f, 0.2f, true), GunAnim.key(0.5f, 1.3f, 1.3f, 1.3f, true), GunAnim.key(0.7f, 1.0f, 1.0f, 1.0f, true));
        a.channel(3, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, 22.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 6.0f, 0.0f, 0.0f, true));
        a.channel(4, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, -22.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, -6.0f, 0.0f, 0.0f, true));
        a.channel(5, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, 0.0f, 22.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 6.0f, 0.0f, true));
        a.channel(6, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, 0.0f, -22.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, -6.0f, 0.0f, true));
        return a;
    }

    private static GunAnim buildIdle() {
        GunAnim a = new GunAnim("first_person_idle", 4.0f, true);
        a.channel(0, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 0.5f, 0.2f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(0, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.8f, 0.6f, 0.0f, true), GunAnim.key(3.0f, -0.8f, -0.6f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(1, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(4.0f, 0.0f, 0.0f, 360.0f, false));
        a.channel(2, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(1.0f, 1.18f, 1.18f, 1.18f, true), GunAnim.key(2.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(3.0f, 1.18f, 1.18f, 1.18f, true), GunAnim.key(4.0f, 1.0f, 1.0f, 1.0f, true));
        a.channel(3, 1, GunAnim.key(0.0f, 6.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 9.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, 6.0f, 0.0f, 0.0f, true));
        a.channel(4, 1, GunAnim.key(0.0f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, -9.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, -6.0f, 0.0f, 0.0f, true));
        a.channel(5, 1, GunAnim.key(0.0f, 0.0f, 6.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 9.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 6.0f, 0.0f, true));
        a.channel(6, 1, GunAnim.key(0.0f, 0.0f, -6.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, -9.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, -6.0f, 0.0f, true));
        return a;
    }

    private static GunAnim buildAttract() {
        GunAnim a = new GunAnim("first_person_attract", 0.8f, true);
        a.channel(0, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 1.5f, true), GunAnim.key(0.1f, 0.15f, -0.1f, 1.7f, true), GunAnim.key(0.2f, -0.15f, 0.1f, 1.4f, true), GunAnim.key(0.3f, 0.15f, 0.0f, 1.7f, true), GunAnim.key(0.4f, -0.15f, -0.1f, 1.4f, true), GunAnim.key(0.5f, 0.1f, 0.1f, 1.7f, true), GunAnim.key(0.6f, -0.1f, 0.0f, 1.5f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 1.5f, true));
        a.channel(0, 1, GunAnim.key(0.0f, -3.0f, 0.0f, 0.0f, true));
        a.channel(1, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.8f, 0.0f, 0.0f, 720.0f, false));
        a.channel(2, 2, GunAnim.key(0.0f, 1.5f, 1.5f, 1.5f, true), GunAnim.key(0.2f, 1.9f, 1.9f, 1.9f, true), GunAnim.key(0.4f, 1.5f, 1.5f, 1.5f, true), GunAnim.key(0.6f, 2.0f, 2.0f, 2.0f, true), GunAnim.key(0.8f, 1.5f, 1.5f, 1.5f, true));
        a.channel(3, 1, GunAnim.key(0.0f, 32.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 36.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 32.0f, 0.0f, 0.0f, true));
        a.channel(4, 1, GunAnim.key(0.0f, -32.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -36.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -32.0f, 0.0f, 0.0f, true));
        a.channel(5, 1, GunAnim.key(0.0f, 0.0f, 32.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 36.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 32.0f, 0.0f, true));
        a.channel(6, 1, GunAnim.key(0.0f, 0.0f, -32.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, -36.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, -32.0f, 0.0f, true));
        return a;
    }

    private static GunAnim buildLaunch() {
        GunAnim a = new GunAnim("first_person_launch", 0.9f, false);
        a.channel(0, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.05f, 0.0f, -0.5f, 4.5f, true), GunAnim.key(0.3f, 0.0f, 0.2f, -0.8f, true), GunAnim.key(0.9f, 0.0f, 0.0f, 0.0f, true));
        a.channel(0, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.05f, -14.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.9f, 0.0f, 0.0f, 0.0f, true));
        a.channel(1, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.9f, 0.0f, 0.0f, 540.0f, false));
        a.channel(2, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.05f, 2.4f, 2.4f, 2.4f, true), GunAnim.key(0.4f, 0.7f, 0.7f, 0.7f, true), GunAnim.key(0.9f, 1.0f, 1.0f, 1.0f, true));
        a.channel(3, 1, GunAnim.key(0.0f, 6.0f, 0.0f, 0.0f, true), GunAnim.key(0.05f, 42.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.9f, 6.0f, 0.0f, 0.0f, true));
        a.channel(4, 1, GunAnim.key(0.0f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(0.05f, -42.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.9f, -6.0f, 0.0f, 0.0f, true));
        a.channel(5, 1, GunAnim.key(0.0f, 0.0f, 6.0f, 0.0f, true), GunAnim.key(0.05f, 0.0f, 42.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.9f, 0.0f, 6.0f, 0.0f, true));
        a.channel(6, 1, GunAnim.key(0.0f, 0.0f, -6.0f, 0.0f, true), GunAnim.key(0.05f, 0.0f, -42.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.9f, 0.0f, -6.0f, 0.0f, true));
        return a;
    }

}
