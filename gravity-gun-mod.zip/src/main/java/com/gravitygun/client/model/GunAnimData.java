package com.gravitygun.client.model;

/** AUTO-GENERATED from blockbench/gravity_gun_1.bbmodel animations */
public final class GunAnimData {
    private GunAnimData() {}

    public static final GunAnim IDLE = build_IDLE();
    public static final GunAnim CHARGE = build_CHARGE();
    public static final GunAnim CHARGED_HOLD = build_CHARGED_HOLD();
    public static final GunAnim FIRE = build_FIRE();
    public static final GunAnim GRAB = build_GRAB();
    public static final GunAnim GRAB_HOLD = build_GRAB_HOLD();
    public static final GunAnim RELEASE = build_RELEASE();

    private static GunAnim build_IDLE() {
        GunAnim a = new GunAnim("idle", 4.0f, true);
        a.channel(GunModelData.B_RING_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(4.0f, 0.0f, 0.0f, 720.0f, false));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(4.0f, 0.0f, 0.0f, -1080.0f, false));
        a.channel(GunModelData.B_CORE, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(4.0f, 0.0f, 0.0f, -1080.0f, false));
        a.channel(GunModelData.B_CORE, 2, GunAnim.key(0.0f, 0.9f, 0.9f, 0.9f, true), GunAnim.key(1.0f, 1.6f, 1.6f, 1.6f, true), GunAnim.key(2.0f, 0.9f, 0.9f, 0.9f, true), GunAnim.key(3.0f, 1.6f, 1.6f, 1.6f, true), GunAnim.key(4.0f, 0.9f, 0.9f, 0.9f, true));
        a.channel(GunModelData.B_PROJECTILE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 1.3f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GUN, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 1.2f, 0.0f, 1.8f, true), GunAnim.key(2.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(3.0f, -1.2f, 0.0f, -1.8f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GAUGE_1, 2, GunAnim.key(0.0f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(0.4f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.8f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(2.0f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(2.4f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(2.8f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(4.0f, 0.25f, 0.25f, 0.25f, true));
        a.channel(GunModelData.B_GAUGE_2, 2, GunAnim.key(0.0f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(0.4f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(0.8f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(1.2f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(2.0f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(2.4f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(2.8f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(3.2f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(4.0f, 0.25f, 0.25f, 0.25f, true));
        a.channel(GunModelData.B_GAUGE_3, 2, GunAnim.key(0.0f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(0.8f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(1.2f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(1.6f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(2.8f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(3.2f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(3.6f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(4.0f, 0.25f, 0.25f, 0.25f, true));
        a.channel(GunModelData.B_CLAW_TOP, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_BOTTOM, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_RIGHT, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_LEFT, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_RING_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, -0.0f, false), GunAnim.key(4.0f, 0.0f, 0.0f, -1080.0f, false));
        return a;
    }

    private static GunAnim build_CHARGE() {
        GunAnim a = new GunAnim("charge", 2.0f, false);
        a.channel(GunModelData.B_RING_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 120.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, 500.0f, true), GunAnim.key(2.0f, 0.0f, 0.0f, 1080.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, -160.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, -700.0f, true), GunAnim.key(2.0f, 0.0f, 0.0f, -1440.0f, true));
        a.channel(GunModelData.B_CORE, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.5f, 0.55f, 0.55f, 0.55f, true), GunAnim.key(1.2f, 1.2f, 1.2f, 1.2f, true), GunAnim.key(2.0f, 1.7f, 1.7f, 1.7f, true));
        a.channel(GunModelData.B_PROJECTILE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.6f, 0.6f, 0.6f, true), GunAnim.key(2.0f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_PROJ_ORBIT, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 180.0f, true), GunAnim.key(2.0f, 0.0f, 0.0f, 900.0f, true));
        a.channel(GunModelData.B_TRIGGER, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, -18.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GAUGE_1, 2, GunAnim.key(0.0f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(0.4f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_GAUGE_2, 2, GunAnim.key(0.0f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(0.8f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(1.1f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_GAUGE_3, 2, GunAnim.key(0.0f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(1.3f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(1.7f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_CLAW_TOP, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -2.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 24.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 26.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_BOTTOM, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 2.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, -24.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, -26.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_RIGHT, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 2.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, -24.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, -26.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_LEFT, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, -2.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 24.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 26.0f, 0.0f, true));
        a.channel(GunModelData.B_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 0.01f, -0.01f, -0.0f, true), GunAnim.key(0.2f, -0.03f, -0.02f, -0.01f, true), GunAnim.key(0.3f, 0.02f, 0.03f, -0.01f, true), GunAnim.key(0.4f, -0.02f, 0.01f, -0.02f, true), GunAnim.key(0.5f, -0.01f, 0.03f, -0.02f, true), GunAnim.key(0.6f, -0.09f, -0.08f, 0.02f, true), GunAnim.key(0.7f, 0.09f, 0.04f, 0.03f, true), GunAnim.key(0.8f, 0.01f, -0.09f, -0.04f, true), GunAnim.key(0.9f, -0.03f, -0.07f, 0.01f, true), GunAnim.key(1.0f, 0.14f, 0.12f, -0.05f, true), GunAnim.key(1.1f, -0.17f, -0.11f, -0.06f, true), GunAnim.key(1.2f, 0.13f, 0.15f, 0.08f, true), GunAnim.key(1.3f, 0.16f, -0.06f, -0.04f, true), GunAnim.key(1.4f, -0.08f, -0.17f, -0.09f, true), GunAnim.key(1.5f, -0.24f, -0.15f, 0.01f, true), GunAnim.key(1.6f, 0.0f, -0.13f, -0.11f, true), GunAnim.key(1.7f, -0.22f, 0.02f, 0.09f, true), GunAnim.key(1.8f, 0.27f, 0.18f, 0.16f, true), GunAnim.key(1.9f, -0.03f, 0.23f, 0.04f, true), GunAnim.key(2.0f, 0.27f, -0.1f, -0.13f, true));
        a.channel(GunModelData.B_GUN, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 0.01f, 0.0f, 0.02f, true), GunAnim.key(0.2f, 0.03f, 0.0f, 0.02f, true), GunAnim.key(0.3f, -0.0f, 0.0f, -0.1f, true), GunAnim.key(0.4f, 0.06f, 0.0f, -0.08f, true), GunAnim.key(0.5f, 0.04f, 0.0f, -0.03f, true), GunAnim.key(0.6f, 0.1f, 0.0f, 0.08f, true), GunAnim.key(0.7f, 0.12f, 0.0f, 0.05f, true), GunAnim.key(0.8f, -0.17f, 0.0f, -0.22f, true), GunAnim.key(0.9f, 0.16f, 0.0f, -0.15f, true), GunAnim.key(1.0f, 0.05f, 0.0f, -0.21f, true), GunAnim.key(1.1f, -0.28f, 0.0f, -0.37f, true), GunAnim.key(1.2f, -0.27f, 0.0f, -0.4f, true), GunAnim.key(1.3f, 0.14f, 0.0f, 0.03f, true), GunAnim.key(1.4f, 0.16f, 0.0f, 0.4f, true), GunAnim.key(1.5f, -0.18f, 0.0f, -0.01f, true), GunAnim.key(1.6f, -0.07f, 0.0f, 0.35f, true), GunAnim.key(1.7f, 0.06f, 0.0f, -0.18f, true), GunAnim.key(1.8f, -0.19f, 0.0f, -0.02f, true), GunAnim.key(1.9f, 0.05f, 0.0f, 0.02f, true), GunAnim.key(2.0f, -0.34f, 0.0f, -0.36f, true));
        a.channel(GunModelData.B_RING_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, -0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, -180.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, -750.0f, true), GunAnim.key(2.0f, 0.0f, 0.0f, -1620.0f, true));
        return a;
    }

    private static GunAnim build_CHARGED_HOLD() {
        GunAnim a = new GunAnim("charged_hold", 0.6f, true);
        a.channel(GunModelData.B_RING_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.6f, 0.0f, 0.0f, 360.0f, false));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.6f, 0.0f, 0.0f, -720.0f, false));
        a.channel(GunModelData.B_CORE, 2, GunAnim.key(0.0f, 1.7f, 1.7f, 1.7f, true), GunAnim.key(0.3f, 1.95f, 1.95f, 1.95f, true), GunAnim.key(0.6f, 1.7f, 1.7f, 1.7f, true));
        a.channel(GunModelData.B_PROJECTILE, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.3f, 1.1f, 1.1f, 1.1f, true), GunAnim.key(0.6f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_PROJ_ORBIT, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.6f, 0.0f, 0.0f, 720.0f, false));
        a.channel(GunModelData.B_GUN, 0, GunAnim.key(0.0f, -0.24f, 0.29f, 0.02f, true), GunAnim.key(0.05f, 0.01f, -0.16f, 0.12f, true), GunAnim.key(0.1f, 0.15f, 0.22f, 0.15f, true), GunAnim.key(0.15f, 0.2f, -0.05f, -0.09f, true), GunAnim.key(0.2f, -0.15f, 0.16f, -0.05f, true), GunAnim.key(0.25f, -0.23f, 0.17f, 0.08f, true), GunAnim.key(0.3f, -0.2f, 0.0f, 0.1f, true), GunAnim.key(0.35f, 0.08f, -0.2f, -0.13f, true), GunAnim.key(0.4f, -0.15f, -0.06f, 0.06f, true), GunAnim.key(0.45f, 0.26f, -0.14f, -0.08f, true), GunAnim.key(0.5f, -0.24f, 0.28f, 0.02f, true), GunAnim.key(0.55f, 0.25f, -0.15f, 0.08f, true));
        a.channel(GunModelData.B_GUN, 1, GunAnim.key(0.0f, 0.27f, 0.0f, -0.05f, true), GunAnim.key(0.05f, -0.07f, 0.0f, -0.11f, true), GunAnim.key(0.1f, -0.02f, 0.0f, -0.09f, true), GunAnim.key(0.15f, -0.02f, 0.0f, -0.23f, true), GunAnim.key(0.2f, 0.11f, 0.0f, -0.24f, true), GunAnim.key(0.25f, 0.18f, 0.0f, 0.13f, true), GunAnim.key(0.3f, 0.26f, 0.0f, 0.11f, true), GunAnim.key(0.35f, 0.31f, 0.0f, -0.58f, true), GunAnim.key(0.4f, 0.18f, 0.0f, 0.44f, true), GunAnim.key(0.45f, -0.34f, 0.0f, -0.2f, true), GunAnim.key(0.5f, -0.01f, 0.0f, -0.53f, true), GunAnim.key(0.55f, -0.27f, 0.0f, -0.28f, true));
        a.channel(GunModelData.B_TRIGGER, 1, GunAnim.key(0.0f, -18.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GAUGE_1, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_GAUGE_2, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_GAUGE_3, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.3f, 0.7f, 0.7f, 0.7f, true), GunAnim.key(0.6f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_CLAW_TOP, 1, GunAnim.key(0.0f, 26.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 23.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 26.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_BOTTOM, 1, GunAnim.key(0.0f, -26.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -23.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, -26.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_RIGHT, 1, GunAnim.key(0.0f, 0.0f, -26.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, -23.0f, 0.0f, true), GunAnim.key(0.6f, 0.0f, -26.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_LEFT, 1, GunAnim.key(0.0f, 0.0f, 26.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 23.0f, 0.0f, true), GunAnim.key(0.6f, 0.0f, 26.0f, 0.0f, true));
        a.channel(GunModelData.B_RING_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, -0.0f, false), GunAnim.key(0.6f, 0.0f, 0.0f, -540.0f, false));
        return a;
    }

    private static GunAnim build_FIRE() {
        GunAnim a = new GunAnim("fire", 1.2f, false);
        a.channel(GunModelData.B_RING_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 0.0f, 240.0f, true), GunAnim.key(0.9f, 0.0f, 0.0f, 340.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 360.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 0.0f, -480.0f, true), GunAnim.key(0.9f, 0.0f, 0.0f, -700.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, -720.0f, true));
        a.channel(GunModelData.B_CORE, 2, GunAnim.key(0.0f, 1.7f, 1.7f, 1.7f, true), GunAnim.key(0.1f, 0.3f, 0.3f, 0.3f, true), GunAnim.key(0.4f, 0.9f, 0.9f, 0.9f, true), GunAnim.key(0.8f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(1.2f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_PROJECTILE, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.08f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.75f, 0.0f, 0.0f, -170.0f, false));
        a.channel(GunModelData.B_PROJECTILE, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.08f, 1.3f, 1.3f, 1.3f, true), GunAnim.key(0.25f, 1.5f, 1.5f, 1.5f, true), GunAnim.key(0.65f, 0.5f, 0.5f, 0.5f, true), GunAnim.key(0.75f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_PROJ_ORBIT, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 900.0f, true));
        a.channel(GunModelData.B_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, 0.0f, 0.4f, 7.0f, true), GunAnim.key(0.3f, 0.0f, 0.0f, -1.0f, true), GunAnim.key(0.55f, 0.0f, 0.0f, 0.4f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GUN, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, 9.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -1.5f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 0.3f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 1, GunAnim.key(0.0f, -18.0f, 0.0f, 0.0f, true), GunAnim.key(0.05f, -26.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GAUGE_1, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.4f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.55f, 0.25f, 0.25f, 0.25f, true));
        a.channel(GunModelData.B_GAUGE_2, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.25f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.4f, 0.25f, 0.25f, 0.25f, true));
        a.channel(GunModelData.B_GAUGE_3, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.1f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.25f, 0.25f, 0.25f, 0.25f, true));
        a.channel(GunModelData.B_CLAW_TOP, 1, GunAnim.key(0.0f, 26.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, -3.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 1.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_BOTTOM, 1, GunAnim.key(0.0f, -26.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -1.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_RIGHT, 1, GunAnim.key(0.0f, 0.0f, -26.0f, 0.0f, true), GunAnim.key(0.1f, 0.0f, 3.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, -1.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_LEFT, 1, GunAnim.key(0.0f, 0.0f, 26.0f, 0.0f, true), GunAnim.key(0.1f, 0.0f, -3.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 1.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_RING_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, -0.0f, true), GunAnim.key(0.4f, 0.0f, 0.0f, -360.0f, true), GunAnim.key(0.9f, 0.0f, 0.0f, -510.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, -540.0f, true));
        return a;
    }

    private static GunAnim build_GRAB() {
        GunAnim a = new GunAnim("grab", 0.8f, false);
        a.channel(GunModelData.B_RING_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 0.0f, 200.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 420.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 0.0f, -260.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, -560.0f, true));
        a.channel(GunModelData.B_CORE, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.15f, 0.6f, 0.6f, 0.6f, true), GunAnim.key(0.5f, 1.9f, 1.9f, 1.9f, true), GunAnim.key(0.8f, 1.5f, 1.5f, 1.5f, true));
        a.channel(GunModelData.B_PROJECTILE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 3.0f, true), GunAnim.key(0.6f, 0.0f, 0.0f, 2.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GUN, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 5.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.15f, -14.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GAUGE_1, 2, GunAnim.key(0.0f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(0.3f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_GAUGE_2, 2, GunAnim.key(0.0f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(0.4f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_GAUGE_3, 2, GunAnim.key(0.0f, 0.25f, 0.25f, 0.25f, true), GunAnim.key(0.5f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_CLAW_TOP, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.15f, 34.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 36.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, -4.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, -1.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -3.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_BOTTOM, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.15f, -34.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -36.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 4.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 1.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 3.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_RIGHT, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.15f, 0.0f, -34.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, -36.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 4.0f, 0.0f, true), GunAnim.key(0.6f, 0.0f, 1.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 3.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_LEFT, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.15f, 0.0f, 34.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 36.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, -4.0f, 0.0f, true), GunAnim.key(0.6f, 0.0f, -1.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, -3.0f, 0.0f, true));
        a.channel(GunModelData.B_RING_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, -0.0f, true), GunAnim.key(0.4f, 0.0f, 0.0f, -300.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, -630.0f, true));
        return a;
    }

    private static GunAnim build_GRAB_HOLD() {
        GunAnim a = new GunAnim("grab_hold", 0.8f, true);
        a.channel(GunModelData.B_RING_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.8f, 0.0f, 0.0f, 360.0f, false));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.8f, 0.0f, 0.0f, -720.0f, false));
        a.channel(GunModelData.B_CORE, 2, GunAnim.key(0.0f, 1.5f, 1.5f, 1.5f, true), GunAnim.key(0.4f, 1.9f, 1.9f, 1.9f, true), GunAnim.key(0.8f, 1.5f, 1.5f, 1.5f, true));
        a.channel(GunModelData.B_PROJECTILE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GUN, 0, GunAnim.key(0.0f, -0.15f, 0.01f, -0.04f, true), GunAnim.key(0.1f, -0.11f, -0.15f, 0.0f, true), GunAnim.key(0.2f, -0.05f, -0.13f, -0.08f, true), GunAnim.key(0.3f, 0.08f, 0.06f, 0.0f, true), GunAnim.key(0.4f, 0.01f, -0.02f, -0.05f, true), GunAnim.key(0.5f, -0.04f, 0.12f, -0.08f, true), GunAnim.key(0.6f, -0.11f, -0.08f, -0.02f, true), GunAnim.key(0.7f, 0.14f, -0.14f, 0.07f, true), GunAnim.key(0.8f, -0.04f, -0.1f, 0.08f, true));
        a.channel(GunModelData.B_GUN, 1, GunAnim.key(0.0f, 0.04f, 0.0f, 0.17f, true), GunAnim.key(0.1f, -0.06f, 0.0f, -0.04f, true), GunAnim.key(0.2f, 0.14f, 0.0f, 0.11f, true), GunAnim.key(0.3f, -0.18f, 0.0f, 0.33f, true), GunAnim.key(0.4f, -0.07f, 0.0f, 0.38f, true), GunAnim.key(0.5f, 0.06f, 0.0f, -0.18f, true), GunAnim.key(0.6f, 0.09f, 0.0f, -0.07f, true), GunAnim.key(0.7f, -0.04f, 0.0f, 0.23f, true), GunAnim.key(0.8f, 0.08f, 0.0f, 0.18f, true));
        a.channel(GunModelData.B_TRIGGER, 1, GunAnim.key(0.0f, -14.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GAUGE_1, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_GAUGE_2, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_GAUGE_3, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.4f, 0.6f, 0.6f, 0.6f, true), GunAnim.key(0.8f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_CLAW_TOP, 1, GunAnim.key(0.0f, -3.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, 2.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -5.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 1.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -3.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_BOTTOM, 1, GunAnim.key(0.0f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, -2.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 5.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, -1.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 3.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_RIGHT, 1, GunAnim.key(0.0f, 0.0f, 3.0f, 0.0f, true), GunAnim.key(0.2f, 0.0f, -2.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 5.0f, 0.0f, true), GunAnim.key(0.6f, 0.0f, -1.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 3.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_LEFT, 1, GunAnim.key(0.0f, 0.0f, -3.0f, 0.0f, true), GunAnim.key(0.2f, 0.0f, 2.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, -5.0f, 0.0f, true), GunAnim.key(0.6f, 0.0f, 1.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, -3.0f, 0.0f, true));
        a.channel(GunModelData.B_RING_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, -0.0f, false), GunAnim.key(0.8f, 0.0f, 0.0f, -540.0f, false));
        return a;
    }

    private static GunAnim build_RELEASE() {
        GunAnim a = new GunAnim("release", 1.0f, false);
        a.channel(GunModelData.B_RING_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 120.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 180.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, -200.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, -360.0f, true));
        a.channel(GunModelData.B_CORE, 2, GunAnim.key(0.0f, 1.5f, 1.5f, 1.5f, true), GunAnim.key(0.15f, 0.5f, 0.5f, 0.5f, true), GunAnim.key(0.5f, 1.1f, 1.1f, 1.1f, true), GunAnim.key(1.0f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_PROJECTILE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.08f, 0.0f, 0.0f, 5.0f, true), GunAnim.key(0.4f, 0.0f, 0.0f, -0.5f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 1, GunAnim.key(0.0f, -14.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GAUGE_1, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.6f, 0.25f, 0.25f, 0.25f, true));
        a.channel(GunModelData.B_GAUGE_2, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.4f, 0.25f, 0.25f, 0.25f, true));
        a.channel(GunModelData.B_GAUGE_3, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.2f, 0.25f, 0.25f, 0.25f, true));
        a.channel(GunModelData.B_CLAW_TOP, 1, GunAnim.key(0.0f, -3.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 30.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_BOTTOM, 1, GunAnim.key(0.0f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -14.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_RIGHT, 1, GunAnim.key(0.0f, 0.0f, 3.0f, 0.0f, true), GunAnim.key(0.1f, 0.0f, -30.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, -14.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_LEFT, 1, GunAnim.key(0.0f, 0.0f, -3.0f, 0.0f, true), GunAnim.key(0.1f, 0.0f, 30.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 14.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_RING_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, -0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, -180.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, -270.0f, true));
        return a;
    }

}
