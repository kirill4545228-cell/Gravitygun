package com.gravitygun.client.model;

/** AUTO-GENERATED from blockbench/gravity_gun.bbmodel animations */
public final class GunAnimData {
    private GunAnimData() {}

    public static final GunAnim IDLE = build_IDLE();
    public static final GunAnim DRAW = build_DRAW();
    public static final GunAnim INSPECT = build_INSPECT();
    public static final GunAnim GRAB_START = build_GRAB_START();
    public static final GunAnim GRAB_HOLD = build_GRAB_HOLD();
    public static final GunAnim GRAB_RELEASE = build_GRAB_RELEASE();
    public static final GunAnim CHARGE = build_CHARGE();
    public static final GunAnim CHARGED_HOLD = build_CHARGED_HOLD();
    public static final GunAnim SHOOT = build_SHOOT();
    public static final GunAnim PUNT = build_PUNT();
    public static final GunAnim HOLSTER = build_HOLSTER();
    public static final GunAnim WALK = build_WALK();
    public static final GunAnim SPRINT = build_SPRINT();
    public static final GunAnim PULL = build_PULL();
    public static final GunAnim LAUNCH_HELD = build_LAUNCH_HELD();
    public static final GunAnim OVERCHARGE = build_OVERCHARGE();
    public static final GunAnim COOLDOWN = build_COOLDOWN();
    public static final GunAnim DENY = build_DENY();

    private static GunAnim build_IDLE() {
        GunAnim a = new GunAnim("idle", 4.0f, true);
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(4.0f, 0.0f, 0.0f, 360.0f, false));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(1.0f, 1.08f, 1.08f, 1.0f, true), GunAnim.key(2.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(3.0f, 1.08f, 1.08f, 1.0f, true), GunAnim.key(4.0f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 0.35f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, -3.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 0.35f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, -3.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 0.35f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, -3.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 0.3f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.8f, 0.6f, 0.0f, true), GunAnim.key(3.0f, -0.8f, -0.6f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 3.0f, 0.0f, true), GunAnim.key(3.0f, 0.0f, -3.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.5f, 0.0f, -5.0f, 0.0f, true), GunAnim.key(3.0f, 0.0f, 5.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 2.5f, 0.0f, 3.0f, true), GunAnim.key(2.0f, 0.0f, 0.0f, -3.0f, true), GunAnim.key(3.0f, -2.5f, 0.0f, 3.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(4.0f, 0.0f, 0.0f, -360.0f, false));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.3f, 1.0f, 0.9f, 1.0f, true), GunAnim.key(0.9f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(4.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.9f, 1.0f, true), GunAnim.key(1.4f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(4.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.3f, 1.0f, 0.9f, 1.0f, true), GunAnim.key(1.9f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(4.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.8f, 1.0f, 0.9f, 1.0f, true), GunAnim.key(2.4f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(4.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(2.3f, 1.0f, 0.9f, 1.0f, true), GunAnim.key(2.9f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(4.0f, 1.0f, 0.4f, 1.0f, true));
        return a;
    }

    private static GunAnim build_DRAW() {
        GunAnim a = new GunAnim("draw", 1.2f, false);
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, -10.0f, 8.0f, true), GunAnim.key(0.5f, 0.0f, 1.5f, -1.0f, true), GunAnim.key(0.8f, 0.0f, -0.5f, 0.3f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, 50.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, -0.5f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 1.5f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 10.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -35.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -10.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, -0.5f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 1.5f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 10.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -35.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -10.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, -0.5f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 1.5f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 10.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -35.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -10.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.2f, 0.0f, 0.0f, 720.0f, false));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 0.3f, 0.3f, 0.3f, true), GunAnim.key(0.6f, 1.25f, 1.25f, 1.25f, true), GunAnim.key(1.2f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, -25.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 12.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 25.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, -12.0f, 0.0f, 6.0f, true), GunAnim.key(0.9f, 5.0f, 0.0f, -3.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, -720.0f, true));
        a.channel(GunModelData.B_GRIP, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 10.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -12.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 4.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 10.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -12.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 4.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 10.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -12.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 4.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 0.05f, 1.0f, true), GunAnim.key(0.3f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(1.2f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 0.05f, 1.0f, true), GunAnim.key(0.4f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(1.2f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 0.05f, 1.0f, true), GunAnim.key(0.5f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(1.2f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.05f, 1.0f, true), GunAnim.key(0.6f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(1.2f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.05f, 1.0f, true), GunAnim.key(0.7f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(1.2f, 1.0f, 0.4f, 1.0f, true));
        return a;
    }

    private static GunAnim build_INSPECT() {
        GunAnim a = new GunAnim("inspect", 4.0f, false);
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.5f, -2.0f, true), GunAnim.key(2.4f, 0.0f, 0.5f, -2.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 12.0f, 70.0f, 0.0f, true), GunAnim.key(2.4f, -8.0f, -50.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 1.4f, 0.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.2f, 0.0f, 1.4f, 0.0f, true), GunAnim.key(3.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.2f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(3.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 1.4f, 0.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.2f, 0.0f, 1.4f, 0.0f, true), GunAnim.key(3.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.2f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(3.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 1.4f, 0.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.2f, 0.0f, 1.4f, 0.0f, true), GunAnim.key(3.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.2f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(3.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 0.0f, 720.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 900.0f, true));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(1.2f, 1.3f, 1.3f, 1.3f, true), GunAnim.key(2.4f, 1.1f, 1.1f, 1.1f, true), GunAnim.key(4.0f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, -14.0f, 0.0f, true), GunAnim.key(2.4f, 0.0f, 14.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.5f, 0.0f, -20.0f, 0.0f, true), GunAnim.key(2.8f, 0.0f, 20.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 10.0f, 0.0f, 8.0f, true), GunAnim.key(2.4f, -10.0f, 0.0f, -8.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, -1080.0f, true));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.95f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.05f, 0.0f, 0.0f, 0.9f, false), GunAnim.key(1.25f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(2.15f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(2.25f, 0.0f, 0.0f, 0.9f, false), GunAnim.key(2.45f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 20.0f, 0.0f, 0.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.2f, 20.0f, 0.0f, 0.0f, true), GunAnim.key(3.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 20.0f, 0.0f, 0.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.2f, 20.0f, 0.0f, 0.0f, true), GunAnim.key(3.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 20.0f, 0.0f, 0.0f, true), GunAnim.key(1.4f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.2f, 20.0f, 0.0f, 0.0f, true), GunAnim.key(3.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(4.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.0f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(2.4f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(4.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.15f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(2.55f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(4.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.3f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(2.7f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(4.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.45f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(2.85f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(4.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.6f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(3.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(4.0f, 1.0f, 0.4f, 1.0f, true));
        return a;
    }

    private static GunAnim build_GRAB_START() {
        GunAnim a = new GunAnim("grab_start", 0.6f, false);
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, 0.0f, 1.6f, 0.0f, true), GunAnim.key(0.6f, 0.0f, 1.2f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, -36.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, -28.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, 0.0f, 1.6f, 0.0f, true), GunAnim.key(0.6f, 0.0f, 1.2f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, -36.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, -28.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, 0.0f, 1.6f, 0.0f, true), GunAnim.key(0.6f, 0.0f, 1.2f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, -36.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, -28.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 0.0f, 0.0f, 540.0f, true));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.6f, 1.3f, 1.3f, 1.3f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.12f, 0.0f, 0.0f, 1.5f, true), GunAnim.key(0.6f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 0.3f, 0.3f, 0.3f, true), GunAnim.key(0.6f, 0.6f, 0.6f, 0.6f, true));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, 26.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 22.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, 26.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 22.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, 26.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 22.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 0.0f, 0.0f, 0.7f, true), GunAnim.key(0.6f, 0.0f, 0.0f, 0.7f, true));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, 6.0f, 0.0f, 4.0f, true), GunAnim.key(0.6f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 0.0f, 0.0f, -540.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.2f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(0.6f, 1.0f, 1.1f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.25f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(0.6f, 1.0f, 1.1f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.3f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(0.6f, 1.0f, 1.1f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.35f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.6f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.4f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.6f, 1.0f, 0.4f, 1.0f, true));
        return a;
    }

    private static GunAnim build_GRAB_HOLD() {
        GunAnim a = new GunAnim("grab_hold", 1.5f, true);
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 1.2f, 0.0f, true), GunAnim.key(0.75f, 0.0f, 1.5f, 0.0f, true), GunAnim.key(1.5f, 0.0f, 1.2f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, -28.0f, 0.0f, 0.0f, true), GunAnim.key(0.75f, -31.0f, 0.0f, 0.0f, true), GunAnim.key(1.5f, -28.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 1.2f, 0.0f, true), GunAnim.key(0.75f, 0.0f, 1.5f, 0.0f, true), GunAnim.key(1.5f, 0.0f, 1.2f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, -28.0f, 0.0f, 0.0f, true), GunAnim.key(0.75f, -31.0f, 0.0f, 0.0f, true), GunAnim.key(1.5f, -28.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 1.2f, 0.0f, true), GunAnim.key(0.75f, 0.0f, 1.5f, 0.0f, true), GunAnim.key(1.5f, 0.0f, 1.2f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, -28.0f, 0.0f, 0.0f, true), GunAnim.key(0.75f, -31.0f, 0.0f, 0.0f, true), GunAnim.key(1.5f, -28.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.5f, 0.0f, 0.0f, 1080.0f, false));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.3f, 1.3f, 1.3f, true), GunAnim.key(0.75f, 1.42f, 1.42f, 1.42f, true), GunAnim.key(1.5f, 1.3f, 1.3f, 1.3f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 0.5f, -0.3f, true), GunAnim.key(1.1f, 0.0f, -0.5f, 0.3f, true), GunAnim.key(1.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.5f, 0.0f, 360.0f, 0.0f, false));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.6f, 0.6f, 0.6f, true), GunAnim.key(0.75f, 0.72f, 0.72f, 0.72f, true), GunAnim.key(1.5f, 0.6f, 0.6f, 0.6f, true));
        a.channel(GunModelData.B_SPARKS, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.5f, 0.0f, 0.0f, 720.0f, false));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.06f, 0.0f, 0.0f, false), GunAnim.key(0.25f, -0.06f, 0.05f, 0.0f, false), GunAnim.key(0.5f, 0.06f, -0.05f, 0.0f, false), GunAnim.key(0.75f, -0.06f, 0.05f, 0.0f, false), GunAnim.key(1.0f, 0.06f, -0.05f, 0.0f, false), GunAnim.key(1.25f, -0.06f, 0.05f, 0.0f, false), GunAnim.key(1.5f, 0.06f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.75f, 0.0f, 5.0f, 0.0f, true), GunAnim.key(1.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 0.0f, 4.0f, 0.0f, true), GunAnim.key(0.75f, 0.0f, -6.0f, 0.0f, true), GunAnim.key(1.5f, 0.0f, 4.0f, 0.0f, true));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 22.0f, 0.0f, 0.0f, true), GunAnim.key(0.75f, 26.0f, 0.0f, 0.0f, true), GunAnim.key(1.5f, 22.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 22.0f, 0.0f, 0.0f, true), GunAnim.key(0.75f, 26.0f, 0.0f, 0.0f, true), GunAnim.key(1.5f, 22.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 22.0f, 0.0f, 0.0f, true), GunAnim.key(0.75f, 26.0f, 0.0f, 0.0f, true), GunAnim.key(1.5f, 22.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.7f, false));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 2.0f, 0.0f, 2.0f, true), GunAnim.key(0.375f, -2.0f, 0.0f, -2.0f, true), GunAnim.key(0.75f, 2.0f, 0.0f, 2.0f, true), GunAnim.key(1.125f, -2.0f, 0.0f, -2.0f, true), GunAnim.key(1.5f, 2.0f, 0.0f, 2.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.5f, 0.0f, 0.0f, -1080.0f, false));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.75f, 1.0f, 1.25f, 1.0f, true), GunAnim.key(1.5f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.75f, 1.0f, 1.25f, 1.0f, true), GunAnim.key(1.5f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.75f, 1.0f, 1.25f, 1.0f, true), GunAnim.key(1.5f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.75f, 1.0f, 0.45f, 1.0f, true), GunAnim.key(1.5f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.75f, 1.0f, 0.45f, 1.0f, true), GunAnim.key(1.5f, 1.0f, 0.4f, 1.0f, true));
        return a;
    }

    private static GunAnim build_GRAB_RELEASE() {
        GunAnim a = new GunAnim("grab_release", 0.5f, false);
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 1.2f, 0.0f, true), GunAnim.key(0.12f, 0.0f, -0.4f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, -28.0f, 0.0f, 0.0f, true), GunAnim.key(0.12f, 12.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -4.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 1.2f, 0.0f, true), GunAnim.key(0.12f, 0.0f, -0.4f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, -28.0f, 0.0f, 0.0f, true), GunAnim.key(0.12f, 12.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -4.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 1.2f, 0.0f, true), GunAnim.key(0.12f, 0.0f, -0.4f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, -28.0f, 0.0f, 0.0f, true), GunAnim.key(0.12f, 12.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -4.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.6f, 0.6f, 0.6f, true), GunAnim.key(0.1f, 0.2f, 0.2f, 0.2f, true), GunAnim.key(0.15f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.3f, 1.3f, 1.3f, true), GunAnim.key(0.12f, 0.7f, 0.7f, 0.7f, true), GunAnim.key(0.5f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 0.0f, 0.0f, 1.5f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 360.0f, true));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 22.0f, 0.0f, 0.0f, true), GunAnim.key(0.12f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 22.0f, 0.0f, 0.0f, true), GunAnim.key(0.12f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 22.0f, 0.0f, 0.0f, true), GunAnim.key(0.12f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.7f, true), GunAnim.key(0.1f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 10.0f, 0.0f, 6.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, -360.0f, true));
        a.channel(GunModelData.B_GRIP, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, -4.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.12f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.5f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.12f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.5f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.12f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.5f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.12f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.5f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.12f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.5f, 1.0f, 0.4f, 1.0f, true));
        return a;
    }

    private static GunAnim build_CHARGE() {
        GunAnim a = new GunAnim("charge", 2.0f, false);
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.8f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 1.6f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 2.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, -20.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, -34.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, -40.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.8f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 1.6f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 2.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, -20.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, -34.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, -40.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.8f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 1.6f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 2.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, -20.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, -34.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, -40.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 90.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 360.0f, true), GunAnim.key(1.5f, 0.0f, 0.0f, 900.0f, true), GunAnim.key(2.0f, 0.0f, 0.0f, 2160.0f, true));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(2.0f, 1.5f, 1.5f, 1.5f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(2.0f, 0.0f, 720.0f, 0.0f, false));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 0.2f, 0.2f, 0.2f, true), GunAnim.key(1.2f, 0.8f, 0.8f, 0.8f, true), GunAnim.key(2.0f, 1.5f, 1.5f, 1.5f, true));
        a.channel(GunModelData.B_SPARKS, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(2.0f, 0.0f, 0.0f, 1440.0f, false));
        a.channel(GunModelData.B_SPARKS, 2, GunAnim.key(0.0f, 0.6f, 0.6f, 0.6f, true), GunAnim.key(2.0f, 1.3f, 1.3f, 1.3f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.4f, 0.0f, 0.05f, 0.3f, false), GunAnim.key(0.6f, 0.0f, -0.1f, 0.6f, false), GunAnim.key(0.8f, 0.0f, 0.15f, 0.9f, false), GunAnim.key(1.0f, 0.0f, -0.2f, 1.2f, false), GunAnim.key(1.2f, 0.0f, 0.25f, 1.5f, false), GunAnim.key(1.4f, 0.0f, -0.3f, 1.8f, false), GunAnim.key(1.6f, 0.0f, 0.35f, 2.1f, false), GunAnim.key(1.8f, 0.0f, -0.35f, 2.3f, false), GunAnim.key(2.0f, 0.0f, 0.3f, 2.5f, false));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, -6.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 4.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, -4.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, -8.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 8.0f, 0.0f, true));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(1.4f, 26.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 32.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(1.4f, 26.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 32.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(1.4f, 26.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 32.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.12f, 0.0f, 0.0f, 0.9f, true), GunAnim.key(2.0f, 0.0f, 0.0f, 0.9f, true));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, -1.0f, 0.0f, 1.0f, false), GunAnim.key(0.125f, 1.4f, 0.0f, -1.4f, false), GunAnim.key(0.25f, -1.8f, 0.0f, 1.8f, false), GunAnim.key(0.375f, 2.2f, 0.0f, -2.2f, false), GunAnim.key(0.5f, -2.6f, 0.0f, 2.6f, false), GunAnim.key(0.625f, 3.0f, 0.0f, -3.0f, false), GunAnim.key(0.75f, -3.4f, 0.0f, 3.4f, false), GunAnim.key(0.875f, 3.8f, 0.0f, -3.8f, false), GunAnim.key(1.0f, -4.2f, 0.0f, 4.2f, false), GunAnim.key(1.125f, 4.6f, 0.0f, -4.6f, false), GunAnim.key(1.25f, -5.0f, 0.0f, 5.0f, false), GunAnim.key(1.375f, 5.4f, 0.0f, -5.4f, false), GunAnim.key(1.5f, -5.8f, 0.0f, 5.8f, false), GunAnim.key(1.625f, 6.2f, 0.0f, -6.2f, false), GunAnim.key(1.75f, -6.6f, 0.0f, 6.6f, false), GunAnim.key(1.875f, 7.0f, 0.0f, -7.0f, false), GunAnim.key(2.0f, -7.4f, 0.0f, 7.4f, false));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, -540.0f, true), GunAnim.key(2.0f, 0.0f, 0.0f, -2160.0f, true));
        a.channel(GunModelData.B_GRIP, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(2.0f, 0.0f, 0.0f, 0.6f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.2f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.45f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(2.0f, 1.0f, 1.3f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.53f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.78f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(2.0f, 1.0f, 1.3f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.86f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.11f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(2.0f, 1.0f, 1.3f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.19f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.44f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(2.0f, 1.0f, 1.3f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.52f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.77f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(2.0f, 1.0f, 1.3f, 1.0f, true));
        return a;
    }

    private static GunAnim build_CHARGED_HOLD() {
        GunAnim a = new GunAnim("charged_hold", 0.8f, true);
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 2.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 2.3f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 2.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, -40.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -43.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -40.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 2.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 2.3f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 2.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, -40.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -43.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -40.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 2.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 2.3f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 2.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, -40.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -43.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -40.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.8f, 0.0f, 0.0f, 1440.0f, false));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.5f, 1.5f, 1.5f, true), GunAnim.key(0.4f, 1.62f, 1.62f, 1.62f, true), GunAnim.key(0.8f, 1.5f, 1.5f, 1.5f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.8f, 0.0f, 360.0f, 0.0f, false));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 1.5f, 1.5f, 1.5f, true), GunAnim.key(0.4f, 1.66f, 1.66f, 1.66f, true), GunAnim.key(0.8f, 1.5f, 1.5f, 1.5f, true));
        a.channel(GunModelData.B_SPARKS, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.8f, 0.0f, 0.0f, 1080.0f, false));
        a.channel(GunModelData.B_SPARKS, 2, GunAnim.key(0.0f, 1.3f, 1.3f, 1.3f, false));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.05f, 0.0f, 2.5f, false), GunAnim.key(0.1f, -0.35f, 0.2f, 2.5f, false), GunAnim.key(0.2f, 0.35f, -0.2f, 2.5f, false), GunAnim.key(0.3f, -0.35f, 0.2f, 2.5f, false), GunAnim.key(0.4f, 0.35f, -0.2f, 2.5f, false), GunAnim.key(0.5f, -0.35f, 0.2f, 2.5f, false), GunAnim.key(0.6f, 0.35f, -0.2f, 2.5f, false), GunAnim.key(0.7f, -0.35f, 0.2f, 2.5f, false), GunAnim.key(0.8f, 0.05f, 0.0f, 2.5f, false));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, -6.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, -4.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 4.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, -4.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 0.0f, 8.0f, 0.0f, true), GunAnim.key(0.4f, 0.0f, -8.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 8.0f, 0.0f, true));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 32.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 36.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 32.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 32.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 36.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 32.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 32.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 36.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 32.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.9f, false));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, -3.0f, 0.0f, 3.0f, false), GunAnim.key(0.1f, 3.0f, 0.0f, -3.0f, false), GunAnim.key(0.2f, -3.0f, 0.0f, 3.0f, false), GunAnim.key(0.3f, 3.0f, 0.0f, -3.0f, false), GunAnim.key(0.4f, -3.0f, 0.0f, 3.0f, false), GunAnim.key(0.5f, 3.0f, 0.0f, -3.0f, false), GunAnim.key(0.6f, -3.0f, 0.0f, 3.0f, false), GunAnim.key(0.7f, 3.0f, 0.0f, -3.0f, false), GunAnim.key(0.8f, -3.0f, 0.0f, 3.0f, false));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.8f, 0.0f, 0.0f, -1440.0f, false));
        a.channel(GunModelData.B_GRIP, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.6f, false));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.4f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 1.3f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.4f, 1.0f, 1.55f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 1.3f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.4f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 1.3f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.4f, 1.0f, 1.55f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 1.3f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.4f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 1.3f, 1.0f, true));
        return a;
    }

    private static GunAnim build_SHOOT() {
        GunAnim a = new GunAnim("shoot", 1.0f, false);
        a.channel(GunModelData.B_ENERGY_BALL, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.12f, 0.0f, 0.0f, -3.0f, false), GunAnim.key(0.5f, 0.0f, 0.0f, -50.0f, false), GunAnim.key(0.85f, 0.0f, 0.0f, -120.0f, false));
        a.channel(GunModelData.B_ENERGY_BALL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.85f, 0.0f, 0.0f, 720.0f, false));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 1.5f, 1.5f, 1.5f, false), GunAnim.key(0.12f, 1.25f, 1.25f, 1.25f, false), GunAnim.key(0.5f, 0.95f, 0.95f, 0.95f, false), GunAnim.key(0.8f, 0.5f, 0.5f, 0.5f, false), GunAnim.key(0.85f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SPARKS, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.85f, 0.0f, 0.0f, 1440.0f, false));
        a.channel(GunModelData.B_SPARKS, 2, GunAnim.key(0.0f, 1.3f, 1.3f, 1.3f, false));
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 2.0f, 0.0f, true), GunAnim.key(0.08f, 0.0f, -0.5f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 0.3f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, -40.0f, 0.0f, 0.0f, true), GunAnim.key(0.08f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 2.0f, 0.0f, true), GunAnim.key(0.08f, 0.0f, -0.5f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 0.3f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, -40.0f, 0.0f, 0.0f, true), GunAnim.key(0.08f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 2.0f, 0.0f, true), GunAnim.key(0.08f, 0.0f, -0.5f, 0.0f, true), GunAnim.key(0.4f, 0.0f, 0.3f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, -40.0f, 0.0f, 0.0f, true), GunAnim.key(0.08f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 2.5f, true), GunAnim.key(0.06f, 0.0f, 0.4f, 6.0f, true), GunAnim.key(0.3f, 0.0f, 0.1f, 1.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, -20.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, 4.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 900.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 1200.0f, true));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.5f, 1.5f, 1.5f, true), GunAnim.key(0.06f, 0.6f, 0.6f, 0.6f, true), GunAnim.key(0.3f, 1.15f, 1.15f, 1.15f, true), GunAnim.key(1.0f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_SHOCKWAVE, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.3f, 0.0f, 0.0f, -6.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.04f, 0.6f, 0.6f, 0.6f, false), GunAnim.key(0.3f, 3.0f, 3.0f, 3.0f, false), GunAnim.key(0.35f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, -7.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, 22.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, -10.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 4.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 32.0f, 0.0f, 0.0f, true), GunAnim.key(0.08f, -10.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 32.0f, 0.0f, 0.0f, true), GunAnim.key(0.08f, -10.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 32.0f, 0.0f, 0.0f, true), GunAnim.key(0.08f, -10.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.9f, true), GunAnim.key(0.04f, 0.0f, 0.0f, 1.5f, true), GunAnim.key(0.3f, 0.0f, 0.0f, 0.2f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -8.0f, 0.0f, 5.0f, true), GunAnim.key(0.6f, 3.0f, 0.0f, -2.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, -900.0f, true));
        a.channel(GunModelData.B_GRIP, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.6f, true), GunAnim.key(0.06f, 0.0f, 0.2f, 1.4f, true), GunAnim.key(0.35f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRIP, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 2.0f, 0.0f, 0.0f, true), GunAnim.key(1.0f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.02f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.12f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.05f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.16f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.08f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.2f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.11f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.24f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.0f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.14f, 1.0f, 1.3f, 1.0f, true), GunAnim.key(0.28f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.0f, 1.0f, 0.4f, 1.0f, true));
        return a;
    }

    private static GunAnim build_PUNT() {
        GunAnim a = new GunAnim("punt", 0.7f, false);
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, 0.0f, 1.6f, 0.0f, true), GunAnim.key(0.14f, 0.0f, -0.5f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(0.14f, 16.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -4.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, 0.0f, 1.6f, 0.0f, true), GunAnim.key(0.14f, 0.0f, -0.5f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(0.14f, 16.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -4.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, 0.0f, 1.6f, 0.0f, true), GunAnim.key(0.14f, 0.0f, -0.5f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(0.14f, 16.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -4.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.14f, 0.0f, 0.3f, 4.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.3f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.14f, -12.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 2.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.06f, 1.6f, 1.6f, 1.6f, true), GunAnim.key(0.3f, 0.9f, 0.9f, 0.9f, true), GunAnim.key(0.7f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 900.0f, true));
        a.channel(GunModelData.B_SHOCKWAVE, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.4f, 0.0f, 0.0f, -8.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.1f, 0.7f, 0.7f, 0.7f, false), GunAnim.key(0.4f, 3.5f, 3.5f, 3.5f, false), GunAnim.key(0.45f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.12f, 10.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, -5.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, 18.0f, 0.0f, 0.0f, true), GunAnim.key(0.55f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.14f, -12.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.14f, -12.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.14f, -12.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.05f, 0.0f, 0.0f, 1.2f, true), GunAnim.key(0.25f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 12.0f, 0.0f, 6.0f, true), GunAnim.key(0.35f, -6.0f, 0.0f, -3.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, -720.0f, true));
        a.channel(GunModelData.B_GRIP, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.12f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.02f, 1.0f, 1.4f, 1.0f, true), GunAnim.key(0.35f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.7f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.05f, 1.0f, 1.4f, 1.0f, true), GunAnim.key(0.35f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.7f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.08f, 1.0f, 1.4f, 1.0f, true), GunAnim.key(0.35f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.7f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.11f, 1.0f, 1.4f, 1.0f, true), GunAnim.key(0.35f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.7f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.14f, 1.0f, 1.4f, 1.0f, true), GunAnim.key(0.35f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.7f, 1.0f, 0.4f, 1.0f, true));
        return a;
    }

    private static GunAnim build_HOLSTER() {
        GunAnim a = new GunAnim("holster", 0.8f, false);
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 1.0f, -1.0f, true), GunAnim.key(0.8f, 0.0f, -10.0f, 8.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 50.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, 0.0f, 1.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, -0.5f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -20.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 8.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 10.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, 0.0f, 1.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, -0.5f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -20.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 8.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 10.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, 0.0f, 1.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, -0.5f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -20.0f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 8.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 10.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 14.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 14.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 14.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 360.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, -360.0f, true));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.8f, 0.3f, 0.3f, 0.3f, true));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 10.0f, 0.0f, 4.0f, true), GunAnim.key(0.8f, 25.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -20.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 20.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -25.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.3f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.05f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.36f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.05f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.42f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.05f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.48f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.05f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.54f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.05f, 1.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        return a;
    }

    private static GunAnim build_WALK() {
        GunAnim a = new GunAnim("walk", 1.2f, true);
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.4f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, -0.5f, 0.0f, true), GunAnim.key(0.6f, -0.4f, 0.0f, 0.0f, true), GunAnim.key(0.9f, 0.0f, -0.5f, 0.0f, true), GunAnim.key(1.2f, 0.4f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, -1.5f, 0.0f, -1.5f, true), GunAnim.key(0.3f, 0.5f, 0.0f, 0.0f, true), GunAnim.key(0.6f, -1.5f, 0.0f, 1.5f, true), GunAnim.key(0.9f, 0.5f, 0.0f, 0.0f, true), GunAnim.key(1.2f, -1.5f, 0.0f, -1.5f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.45f, -4.0f, 0.0f, 0.0f, true), GunAnim.key(0.9f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.45f, -4.0f, 0.0f, 0.0f, true), GunAnim.key(0.9f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.45f, -4.0f, 0.0f, 0.0f, true), GunAnim.key(0.9f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.55f, 5.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.55f, 5.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.55f, 5.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.2f, 0.0f, 0.0f, 360.0f, false));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.2f, 0.0f, 0.0f, -360.0f, false));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.6f, 1.1f, 1.1f, 1.1f, true), GunAnim.key(1.2f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 6.0f, 0.0f, 2.0f, true), GunAnim.key(0.6f, 0.0f, 0.0f, -2.0f, true), GunAnim.key(0.9f, 6.0f, 0.0f, 2.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, 4.0f, 0.0f, true), GunAnim.key(0.6f, 0.0f, -4.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 4.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 4.0f, 8.0f, 0.0f, true), GunAnim.key(0.6f, -4.0f, -8.0f, 0.0f, true), GunAnim.key(1.2f, 4.0f, 8.0f, 0.0f, true));
        a.channel(GunModelData.B_GRIP, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 1.5f, 0.0f, 0.0f, true), GunAnim.key(0.6f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.9f, 1.5f, 0.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.2f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.5f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.2f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.35f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.65f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.2f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.5f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.2f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.65f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.95f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.2f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(1.1f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.2f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        return a;
    }

    private static GunAnim build_SPRINT() {
        GunAnim a = new GunAnim("sprint", 0.8f, true);
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 1.2f, -1.0f, -2.0f, true), GunAnim.key(0.2f, 0.0f, -1.8f, -2.0f, true), GunAnim.key(0.4f, -1.2f, -1.0f, -2.0f, true), GunAnim.key(0.6f, 0.0f, -1.8f, -2.0f, true), GunAnim.key(0.8f, 1.2f, -1.0f, -2.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, 22.0f, -14.0f, -4.0f, true), GunAnim.key(0.4f, 22.0f, -14.0f, 4.0f, true), GunAnim.key(0.8f, 22.0f, -14.0f, -4.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 6.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 6.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 6.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 6.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 6.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 3.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 6.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 12.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 8.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 12.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 12.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 8.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 12.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 12.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 8.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 12.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.8f, 0.0f, 0.0f, 1080.0f, false));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.8f, 0.0f, 0.0f, -1080.0f, false));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.1f, 1.1f, 1.1f, true), GunAnim.key(0.4f, 1.25f, 1.25f, 1.25f, true), GunAnim.key(0.8f, 1.1f, 1.1f, 1.1f, true));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 14.0f, 0.0f, 4.0f, true), GunAnim.key(0.2f, 18.0f, 0.0f, -4.0f, true), GunAnim.key(0.4f, 14.0f, 0.0f, 4.0f, true), GunAnim.key(0.6f, 18.0f, 0.0f, -4.0f, true), GunAnim.key(0.8f, 14.0f, 0.0f, 4.0f, true));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, -10.0f, 6.0f, 0.0f, true), GunAnim.key(0.4f, -14.0f, -6.0f, 0.0f, true), GunAnim.key(0.8f, -10.0f, 6.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, -16.0f, 12.0f, 0.0f, true), GunAnim.key(0.4f, -22.0f, -12.0f, 0.0f, true), GunAnim.key(0.8f, -16.0f, 12.0f, 0.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.05f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.8f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.15f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.8f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.25f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.8f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.35f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.8f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.8f, 1.0f, true), GunAnim.key(0.45f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.8f, 1.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        return a;
    }

    private static GunAnim build_PULL() {
        GunAnim a = new GunAnim("pull", 0.8f, false);
        a.channel(GunModelData.B_ENERGY_BALL, 0, GunAnim.key(0.0f, 0.0f, 0.0f, -34.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.7f, 0.0f, 540.0f, 0.0f, false));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.2f, 0.2f, 0.2f, true), GunAnim.key(0.35f, 0.35f, 0.35f, 0.35f, true), GunAnim.key(0.7f, 0.6f, 0.6f, 0.6f, true));
        a.channel(GunModelData.B_SPARKS, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.7f, 0.0f, 0.0f, 720.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 0, GunAnim.key(0.0f, 0.0f, 0.0f, -22.0f, false), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 3.0f, 3.0f, 3.0f, false), GunAnim.key(0.2f, 2.2f, 2.2f, 2.2f, false), GunAnim.key(0.5f, 0.4f, 0.4f, 0.4f, false), GunAnim.key(0.55f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, 0.0f, 1.4f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 1.2f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, -28.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, 0.0f, 1.4f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 1.2f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, -28.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, 0.0f, 1.4f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 1.2f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, -30.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, -28.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 22.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 22.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 22.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 0.0f, 0.0f, 0.7f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 0.7f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, 0.0f, 0.0f, -0.8f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.8f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 720.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, -720.0f, true));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.7f, 1.35f, 1.35f, 1.35f, true));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.2f, 8.0f, 0.0f, 5.0f, true), GunAnim.key(0.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.1f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 1.1f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.2f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 1.1f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.3f, 1.0f, 1.1f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 1.1f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.4f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.5f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.4f, 1.0f, true));
        return a;
    }

    private static GunAnim build_LAUNCH_HELD() {
        GunAnim a = new GunAnim("launch_held", 0.7f, false);
        a.channel(GunModelData.B_ENERGY_BALL, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.1f, 0.0f, 0.0f, -4.0f, false), GunAnim.key(0.4f, 0.0f, 0.0f, -60.0f, false), GunAnim.key(0.65f, 0.0f, 0.0f, -120.0f, false));
        a.channel(GunModelData.B_ENERGY_BALL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.65f, 0.0f, 720.0f, 0.0f, false));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.6f, 0.6f, 0.6f, false), GunAnim.key(0.1f, 0.7f, 0.7f, 0.7f, false), GunAnim.key(0.5f, 0.5f, 0.5f, 0.5f, false), GunAnim.key(0.65f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.25f, 0.0f, 0.0f, -5.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.04f, 0.5f, 0.5f, 0.5f, false), GunAnim.key(0.25f, 2.2f, 2.2f, 2.2f, false), GunAnim.key(0.3f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 1.2f, 0.0f, true), GunAnim.key(0.07f, 0.0f, -0.4f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, -28.0f, 0.0f, 0.0f, true), GunAnim.key(0.07f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -5.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 1.2f, 0.0f, true), GunAnim.key(0.07f, 0.0f, -0.4f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, -28.0f, 0.0f, 0.0f, true), GunAnim.key(0.07f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -5.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 1.2f, 0.0f, true), GunAnim.key(0.07f, 0.0f, -0.4f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, -28.0f, 0.0f, 0.0f, true), GunAnim.key(0.07f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, -5.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 22.0f, 0.0f, 0.0f, true), GunAnim.key(0.07f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 2.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 22.0f, 0.0f, 0.0f, true), GunAnim.key(0.07f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 2.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 22.0f, 0.0f, 0.0f, true), GunAnim.key(0.07f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 2.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.7f, true), GunAnim.key(0.04f, 0.0f, 0.0f, 1.4f, true), GunAnim.key(0.3f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, 0.0f, 0.3f, 4.5f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.3f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, -14.0f, 0.0f, 0.0f, true), GunAnim.key(0.4f, 2.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRIP, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.06f, -7.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.3f, 1.3f, 1.3f, true), GunAnim.key(0.06f, 0.6f, 0.6f, 0.6f, true), GunAnim.key(0.4f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 900.0f, true));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.08f, 14.0f, 0.0f, 4.0f, true), GunAnim.key(0.3f, -6.0f, 0.0f, -3.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.1f, 12.0f, 0.0f, 0.0f, true), GunAnim.key(0.35f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.25f, 20.0f, 0.0f, 0.0f, true), GunAnim.key(0.55f, -8.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.12f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.7f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.12f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.7f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, true), GunAnim.key(0.12f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.7f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.12f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.7f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.12f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(0.7f, 1.0f, 0.4f, 1.0f, true));
        return a;
    }

    private static GunAnim build_OVERCHARGE() {
        GunAnim a = new GunAnim("overcharge", 1.6f, false);
        a.channel(GunModelData.B_ENERGY_BALL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.35f, 0.0f, 1440.0f, 0.0f, false));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 1.5f, 1.5f, 1.5f, false), GunAnim.key(0.4f, 1.7f, 1.7f, 1.7f, false), GunAnim.key(0.8f, 1.9f, 1.9f, 1.9f, false), GunAnim.key(1.1f, 2.2f, 2.2f, 2.2f, false), GunAnim.key(1.3f, 2.5f, 2.5f, 2.5f, false), GunAnim.key(1.35f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SPARKS, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.35f, 0.0f, 0.0f, 2880.0f, false));
        a.channel(GunModelData.B_SPARKS, 2, GunAnim.key(0.0f, 1.3f, 1.3f, 1.3f, false), GunAnim.key(1.3f, 2.2f, 2.2f, 2.2f, false));
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 2.0f, 0.0f, false), GunAnim.key(1.3f, 0.0f, 2.8f, 0.0f, false), GunAnim.key(1.35f, 0.0f, -0.5f, 0.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, -40.0f, 0.0f, 0.0f, false), GunAnim.key(0.5f, -44.0f, 0.0f, 0.0f, false), GunAnim.key(0.7f, -38.0f, 0.0f, 0.0f, false), GunAnim.key(0.9f, -45.0f, 0.0f, 0.0f, false), GunAnim.key(1.1f, -36.0f, 0.0f, 0.0f, false), GunAnim.key(1.3f, -46.0f, 0.0f, 0.0f, false), GunAnim.key(1.35f, 16.0f, 0.0f, 0.0f, false), GunAnim.key(1.5f, -5.0f, 0.0f, 0.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 2.0f, 0.0f, false), GunAnim.key(1.3f, 0.0f, 2.8f, 0.0f, false), GunAnim.key(1.35f, 0.0f, -0.5f, 0.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, -40.0f, 0.0f, 0.0f, false), GunAnim.key(0.5f, -44.0f, 0.0f, 0.0f, false), GunAnim.key(0.7f, -38.0f, 0.0f, 0.0f, false), GunAnim.key(0.9f, -45.0f, 0.0f, 0.0f, false), GunAnim.key(1.1f, -36.0f, 0.0f, 0.0f, false), GunAnim.key(1.3f, -46.0f, 0.0f, 0.0f, false), GunAnim.key(1.35f, 16.0f, 0.0f, 0.0f, false), GunAnim.key(1.5f, -5.0f, 0.0f, 0.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 2.0f, 0.0f, false), GunAnim.key(1.3f, 0.0f, 2.8f, 0.0f, false), GunAnim.key(1.35f, 0.0f, -0.5f, 0.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, -40.0f, 0.0f, 0.0f, false), GunAnim.key(0.5f, -44.0f, 0.0f, 0.0f, false), GunAnim.key(0.7f, -38.0f, 0.0f, 0.0f, false), GunAnim.key(0.9f, -45.0f, 0.0f, 0.0f, false), GunAnim.key(1.1f, -36.0f, 0.0f, 0.0f, false), GunAnim.key(1.3f, -46.0f, 0.0f, 0.0f, false), GunAnim.key(1.35f, 16.0f, 0.0f, 0.0f, false), GunAnim.key(1.5f, -5.0f, 0.0f, 0.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 32.0f, 0.0f, 0.0f, false), GunAnim.key(1.3f, 40.0f, 0.0f, 0.0f, false), GunAnim.key(1.35f, -10.0f, 0.0f, 0.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 32.0f, 0.0f, 0.0f, false), GunAnim.key(1.3f, 40.0f, 0.0f, 0.0f, false), GunAnim.key(1.35f, -10.0f, 0.0f, 0.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 32.0f, 0.0f, 0.0f, false), GunAnim.key(1.3f, 40.0f, 0.0f, 0.0f, false), GunAnim.key(1.35f, -10.0f, 0.0f, 0.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 2.5f, false), GunAnim.key(0.1f, -0.3f, -0.0f, 2.5f, false), GunAnim.key(0.2f, 0.38f, 0.03f, 2.5f, false), GunAnim.key(0.3f, -0.46f, -0.06f, 2.5f, false), GunAnim.key(0.4f, 0.54f, 0.09f, 2.5f, false), GunAnim.key(0.5f, -0.62f, -0.12f, 2.5f, false), GunAnim.key(0.6f, 0.7f, 0.15f, 2.5f, false), GunAnim.key(0.7f, -0.78f, -0.18f, 2.5f, false), GunAnim.key(0.8f, 0.86f, 0.21f, 2.5f, false), GunAnim.key(0.9f, -0.94f, -0.24f, 2.5f, false), GunAnim.key(1.0f, 1.02f, 0.27f, 2.5f, false), GunAnim.key(1.1f, -1.1f, -0.3f, 2.5f, false), GunAnim.key(1.2f, 1.18f, 0.33f, 2.5f, false), GunAnim.key(1.35f, 0.0f, 0.5f, 9.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_GRAVITY_GUN, 1, GunAnim.key(0.0f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(1.3f, -9.0f, 0.0f, 0.0f, true), GunAnim.key(1.35f, -22.0f, 0.0f, 0.0f, true), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_SHOCKWAVE, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, -10.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.33f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.38f, 1.0f, 1.0f, 1.0f, false), GunAnim.key(1.55f, 5.0f, 5.0f, 5.0f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.5f, 1.5f, 1.5f, false), GunAnim.key(1.2f, 2.0f, 2.0f, 2.0f, false), GunAnim.key(1.35f, 0.5f, 0.5f, 0.5f, false), GunAnim.key(1.6f, 1.0f, 1.0f, 1.0f, false));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.35f, 0.0f, 0.0f, 2880.0f, true), GunAnim.key(1.6f, 0.0f, 0.0f, 3100.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(1.35f, 0.0f, 0.0f, -2880.0f, false));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(0.05f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(0.1f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(0.15f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(0.2f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(0.25f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(0.3f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(0.35f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(0.4f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(0.45f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(0.5f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(0.55f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(0.6f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(0.65f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(0.7f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(0.75f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(0.8f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(0.85f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(0.9f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(0.95f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(1.0f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(1.05f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(1.1f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(1.15f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(1.2f, -9.0f, 0.0f, 9.0f, false), GunAnim.key(1.25f, 9.0f, 0.0f, -9.0f, false), GunAnim.key(1.3f, -9.0f, 0.0f, 9.0f, false));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.9f, false), GunAnim.key(1.35f, 0.0f, 0.0f, 1.5f, false), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, false), GunAnim.key(0.3f, 1.0f, 0.6f, 1.0f, false), GunAnim.key(0.6f, 1.0f, 1.6f, 1.0f, false), GunAnim.key(0.9f, 1.0f, 0.6f, 1.0f, false), GunAnim.key(1.2f, 1.0f, 1.8f, 1.0f, false), GunAnim.key(1.35f, 1.0f, 0.3f, 1.0f, false), GunAnim.key(1.6f, 1.0f, 0.4f, 1.0f, false));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, false), GunAnim.key(0.3f, 1.0f, 0.6f, 1.0f, false), GunAnim.key(0.6f, 1.0f, 1.6f, 1.0f, false), GunAnim.key(0.9f, 1.0f, 0.6f, 1.0f, false), GunAnim.key(1.2f, 1.0f, 1.8f, 1.0f, false), GunAnim.key(1.35f, 1.0f, 0.3f, 1.0f, false), GunAnim.key(1.6f, 1.0f, 0.4f, 1.0f, false));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, false), GunAnim.key(0.3f, 1.0f, 0.6f, 1.0f, false), GunAnim.key(0.6f, 1.0f, 1.6f, 1.0f, false), GunAnim.key(0.9f, 1.0f, 0.6f, 1.0f, false), GunAnim.key(1.2f, 1.0f, 1.8f, 1.0f, false), GunAnim.key(1.35f, 1.0f, 0.3f, 1.0f, false), GunAnim.key(1.6f, 1.0f, 0.4f, 1.0f, false));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, false), GunAnim.key(0.3f, 1.0f, 0.6f, 1.0f, false), GunAnim.key(0.6f, 1.0f, 1.6f, 1.0f, false), GunAnim.key(0.9f, 1.0f, 0.6f, 1.0f, false), GunAnim.key(1.2f, 1.0f, 1.8f, 1.0f, false), GunAnim.key(1.35f, 1.0f, 0.3f, 1.0f, false), GunAnim.key(1.6f, 1.0f, 0.4f, 1.0f, false));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 1.3f, 1.0f, false), GunAnim.key(0.3f, 1.0f, 0.6f, 1.0f, false), GunAnim.key(0.6f, 1.0f, 1.6f, 1.0f, false), GunAnim.key(0.9f, 1.0f, 0.6f, 1.0f, false), GunAnim.key(1.2f, 1.0f, 1.8f, 1.0f, false), GunAnim.key(1.35f, 1.0f, 0.3f, 1.0f, false), GunAnim.key(1.6f, 1.0f, 0.4f, 1.0f, false));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.35f, 20.0f, 0.0f, 0.0f, true), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.45f, 28.0f, 0.0f, 0.0f, true), GunAnim.key(1.6f, 0.0f, 0.0f, 0.0f, true));
        return a;
    }

    private static GunAnim build_COOLDOWN() {
        GunAnim a = new GunAnim("cooldown", 1.8f, false);
        a.channel(GunModelData.B_CLAW_A, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 1.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.7f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -14.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, -10.0f, 0.0f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 1.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.7f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -14.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, -10.0f, 0.0f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, 0.0f, 1.0f, 0.0f, true), GunAnim.key(1.2f, 0.0f, 0.7f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -14.0f, 0.0f, 0.0f, true), GunAnim.key(1.2f, -10.0f, 0.0f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -12.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -12.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.3f, -12.0f, 0.0f, 0.0f, true), GunAnim.key(0.8f, -6.0f, 0.0f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 0.6f, 0.6f, 0.6f, true), GunAnim.key(0.6f, 1.25f, 1.25f, 1.25f, true), GunAnim.key(1.8f, 1.0f, 1.0f, 1.0f, true));
        a.channel(GunModelData.B_ROTOR, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 720.0f, true));
        a.channel(GunModelData.B_GYRO, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, -540.0f, true));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, -3.0f, 0.0f, 3.0f, false), GunAnim.key(0.2f, 3.0f, 0.0f, -3.0f, false), GunAnim.key(0.4f, -3.0f, 0.0f, 3.0f, false), GunAnim.key(0.6f, 3.0f, 0.0f, -3.0f, false), GunAnim.key(0.8f, -3.0f, 0.0f, 3.0f, false), GunAnim.key(1.0f, 3.0f, 0.0f, -3.0f, false), GunAnim.key(1.2f, -3.0f, 0.0f, 3.0f, false), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CABLE, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 8.0f, 0.0f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_CABLE_TAIL, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.7f, 14.0f, 0.0f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, true), GunAnim.key(0.5f, 0.0f, -0.6f, 0.0f, true), GunAnim.key(1.8f, 0.0f, 0.0f, 0.0f, true));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(0.2f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.8f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(0.4f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.8f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(0.6f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.8f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(0.8f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.8f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 1.2f, 1.0f, true), GunAnim.key(1.0f, 1.0f, 0.4f, 1.0f, true), GunAnim.key(1.8f, 1.0f, 0.4f, 1.0f, true));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        return a;
    }

    private static GunAnim build_DENY() {
        GunAnim a = new GunAnim("deny", 0.5f, false);
        a.channel(GunModelData.B_CLAW_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.06f, -8.0f, 0.0f, 0.0f, false), GunAnim.key(0.12f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.2f, -8.0f, 0.0f, 0.0f, false), GunAnim.key(0.28f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.06f, -8.0f, 0.0f, 0.0f, false), GunAnim.key(0.12f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.2f, -8.0f, 0.0f, 0.0f, false), GunAnim.key(0.28f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.06f, -8.0f, 0.0f, 0.0f, false), GunAnim.key(0.12f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.2f, -8.0f, 0.0f, 0.0f, false), GunAnim.key(0.28f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_A, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.06f, 6.0f, 0.0f, 0.0f, false), GunAnim.key(0.12f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.2f, 6.0f, 0.0f, 0.0f, false), GunAnim.key(0.28f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_B, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.06f, 6.0f, 0.0f, 0.0f, false), GunAnim.key(0.12f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.2f, 6.0f, 0.0f, 0.0f, false), GunAnim.key(0.28f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CLAW_TIP_C, 1, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.06f, 6.0f, 0.0f, 0.0f, false), GunAnim.key(0.12f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.2f, 6.0f, 0.0f, 0.0f, false), GunAnim.key(0.28f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_GRAVITY_GUN, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.05f, 0.4f, 0.0f, 0.0f, false), GunAnim.key(0.1f, -0.4f, 0.0f, 0.0f, false), GunAnim.key(0.15f, 0.4f, 0.0f, 0.0f, false), GunAnim.key(0.2f, -0.4f, 0.0f, 0.0f, false), GunAnim.key(0.3f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_CORE_GLOW, 2, GunAnim.key(0.0f, 1.0f, 1.0f, 1.0f, false), GunAnim.key(0.06f, 0.6f, 0.6f, 0.6f, false), GunAnim.key(0.12f, 1.1f, 1.1f, 1.1f, false), GunAnim.key(0.2f, 0.6f, 0.6f, 0.6f, false), GunAnim.key(0.5f, 1.0f, 1.0f, 1.0f, false));
        a.channel(GunModelData.B_TRIGGER, 0, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.05f, 0.0f, 0.0f, 0.8f, false), GunAnim.key(0.2f, 0.0f, 0.0f, 0.0f, false), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_ANTENNA, 1, GunAnim.key(0.0f, -5.0f, 0.0f, 5.0f, false), GunAnim.key(0.067f, 5.0f, 0.0f, -5.0f, false), GunAnim.key(0.133f, -5.0f, 0.0f, 5.0f, false), GunAnim.key(0.2f, 5.0f, 0.0f, -5.0f, false), GunAnim.key(0.267f, -5.0f, 0.0f, 5.0f, false), GunAnim.key(0.333f, 5.0f, 0.0f, -5.0f, false), GunAnim.key(0.4f, -5.0f, 0.0f, 5.0f, false), GunAnim.key(0.5f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_BAR_0, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, false), GunAnim.key(0.06f, 1.0f, 1.4f, 1.0f, false), GunAnim.key(0.2f, 1.0f, 0.4f, 1.0f, false));
        a.channel(GunModelData.B_BAR_1, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, false), GunAnim.key(0.06f, 1.0f, 0.4f, 1.0f, false), GunAnim.key(0.2f, 1.0f, 0.4f, 1.0f, false));
        a.channel(GunModelData.B_BAR_2, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, false), GunAnim.key(0.06f, 1.0f, 0.4f, 1.0f, false), GunAnim.key(0.2f, 1.0f, 0.4f, 1.0f, false));
        a.channel(GunModelData.B_BAR_3, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, false), GunAnim.key(0.06f, 1.0f, 0.4f, 1.0f, false), GunAnim.key(0.2f, 1.0f, 0.4f, 1.0f, false));
        a.channel(GunModelData.B_BAR_4, 2, GunAnim.key(0.0f, 1.0f, 0.4f, 1.0f, false), GunAnim.key(0.06f, 1.0f, 0.4f, 1.0f, false), GunAnim.key(0.2f, 1.0f, 0.4f, 1.0f, false));
        a.channel(GunModelData.B_ENERGY_BALL, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        a.channel(GunModelData.B_SHOCKWAVE, 2, GunAnim.key(0.0f, 0.0f, 0.0f, 0.0f, false));
        return a;
    }

}
