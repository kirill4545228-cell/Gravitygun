package com.gravitygun.client;

import com.gravitygun.GravityGunItem;
import com.gravitygun.client.model.GunAnimData;
import com.gravitygun.network.FeedbackPacket;

import net.minecraft.client.Minecraft;

/** Entry points for server -> client messages (kept in a client-only class). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void onFeedback(int code) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !(mc.player.getMainHandItem().getItem() instanceof GravityGunItem)) return;
        if (code == FeedbackPacket.GRAB_OK) {
            ClientState.holdingObject = true;
        } else if (code == FeedbackPacket.DENY) {
            ClientState.holdingObject = false;
            ClientState.ANIM.play(GunAnimData.DENY, GunAnimData.IDLE, 0.05f);
        }
    }
}
