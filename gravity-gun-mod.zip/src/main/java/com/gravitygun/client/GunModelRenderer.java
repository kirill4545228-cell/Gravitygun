package com.gravitygun.client;

import com.gravitygun.GravityGunMod;
import com.gravitygun.GravityMode;
import com.gravitygun.client.model.GunModelData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Renders the gravity gun model (bones + cubes from the Blockbench file) with an animation pose.
 * Each mode has its own texture variant (glowing parts are re-coloured).
 */
public final class GunModelRenderer {
    private GunModelRenderer() {}

    private static final float TEX_SIZE = 256f;
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[GravityMode.values().length];

    static {
        for (GravityMode mode : GravityMode.values()) {
            TEXTURES[mode.ordinal()] = new ResourceLocation(GravityGunMod.MODID,
                    "textures/models/gravity_gun_" + mode.key + ".png");
        }
    }

    /**
     * Renders in "model units" (1/16 block): the caller is expected to have scaled the pose stack.
     *
     * @param pose per-bone pose: [pos xyz, rot xyz, scale xyz]
     */
    public static void render(PoseStack ps, MultiBufferSource buffers, int light, int overlay,
                              float[][] pose, GravityMode mode) {
        ResourceLocation tex = TEXTURES[mode.ordinal()];
        // pass 1: opaque parts, pass 2: translucent parts (energy shell of the projectile)
        VertexConsumer opaque = buffers.getBuffer(RenderType.entityCutoutNoCull(tex));
        renderBone(0, ps, opaque, light, overlay, pose, false);
        VertexConsumer translucent = buffers.getBuffer(RenderType.entityTranslucent(tex));
        renderBone(0, ps, translucent, light, overlay, pose, true);
    }

    private static boolean hidden(float[] p) {
        return Math.max(0f, p[6]) < 0.001f || Math.max(0f, p[7]) < 0.001f || Math.max(0f, p[8]) < 0.001f;
    }

    private static void renderBone(int idx, PoseStack ps, VertexConsumer vc, int light, int overlay,
                                   float[][] pose, boolean translucentPass) {
        float[] p = pose[idx];
        if (hidden(p)) return;
        float[] pv = GunModelData.PIVOT[idx];
        ps.pushPose();
        // Blockbench animation convention: position.x, rotation.x and rotation.y are inverted
        ps.translate(pv[0] - p[0], pv[1] + p[1], pv[2] + p[2]);
        ps.mulPose(Axis.ZP.rotationDegrees(p[5]));
        ps.mulPose(Axis.YP.rotationDegrees(-p[4]));
        ps.mulPose(Axis.XP.rotationDegrees(-p[3]));
        ps.scale(Math.max(0f, p[6]), Math.max(0f, p[7]), Math.max(0f, p[8]));
        ps.translate(-pv[0], -pv[1], -pv[2]);

        for (float[] c : GunModelData.CUBES[idx]) {
            int flags = (int) c[12];
            if (((flags & 2) != 0) != translucentPass) continue;
            int l = (flags & 1) != 0 ? LightTexture.FULL_BRIGHT : light;
            boolean rotated = c[6] != 0f || c[7] != 0f || c[8] != 0f;
            if (rotated) {
                ps.pushPose();
                ps.translate(c[9], c[10], c[11]);
                ps.mulPose(Axis.ZP.rotationDegrees(c[8]));
                ps.mulPose(Axis.YP.rotationDegrees(c[7]));
                ps.mulPose(Axis.XP.rotationDegrees(c[6]));
                ps.translate(-c[9], -c[10], -c[11]);
            }
            PoseStack.Pose last = ps.last();
            cube(vc, last.pose(), last.normal(), c, l, overlay, translucentPass ? 0.85f : 1f);
            if (rotated) ps.popPose();
        }
        for (int child = 0; child < GunModelData.PARENT.length; child++) {
            if (GunModelData.PARENT[child] == idx) {
                renderBone(child, ps, vc, light, overlay, pose, translucentPass);
            }
        }
        ps.popPose();
    }

    private static void cube(VertexConsumer vc, Matrix4f m, Matrix3f n, float[] c, int light, int overlay, float alpha) {
        float x0 = c[0], y0 = c[1], z0 = c[2], x1 = c[3], y1 = c[4], z1 = c[5];
        // faces in the data: north, east, south, west, up, down
        // north (-Z)
        quad(vc, m, n, x1, y1, z0, x1, y0, z0, x0, y0, z0, x0, y1, z0, 0, 0, -1, c, 13, light, overlay, alpha);
        // east (+X)
        quad(vc, m, n, x1, y1, z1, x1, y0, z1, x1, y0, z0, x1, y1, z0, 1, 0, 0, c, 17, light, overlay, alpha);
        // south (+Z)
        quad(vc, m, n, x0, y1, z1, x0, y0, z1, x1, y0, z1, x1, y1, z1, 0, 0, 1, c, 21, light, overlay, alpha);
        // west (-X)
        quad(vc, m, n, x0, y1, z0, x0, y0, z0, x0, y0, z1, x0, y1, z1, -1, 0, 0, c, 25, light, overlay, alpha);
        // up (+Y)
        quad(vc, m, n, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, 0, 1, 0, c, 29, light, overlay, alpha);
        // down (-Y)
        quad(vc, m, n, x0, y0, z1, x0, y0, z0, x1, y0, z0, x1, y0, z1, 0, -1, 0, c, 33, light, overlay, alpha);
    }

    /** Vertices in order: top-left, bottom-left, bottom-right, top-right (same as vanilla block models). */
    private static void quad(VertexConsumer vc, Matrix4f m, Matrix3f n,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float nx, float ny, float nz,
                             float[] data, int uvIndex, int light, int overlay, float alpha) {
        float eps = 0.02f;
        float u0 = data[uvIndex], v0 = data[uvIndex + 1], u1 = data[uvIndex + 2], v1 = data[uvIndex + 3];
        u0 += Math.signum(u1 - u0) * eps;
        u1 -= Math.signum(u1 - u0) * eps;
        v0 += Math.signum(v1 - v0) * eps;
        v1 -= Math.signum(v1 - v0) * eps;
        u0 /= TEX_SIZE;
        u1 /= TEX_SIZE;
        v0 /= TEX_SIZE;
        v1 /= TEX_SIZE;
        vertex(vc, m, n, ax, ay, az, u0, v0, nx, ny, nz, light, overlay, alpha);
        vertex(vc, m, n, bx, by, bz, u0, v1, nx, ny, nz, light, overlay, alpha);
        vertex(vc, m, n, cx, cy, cz, u1, v1, nx, ny, nz, light, overlay, alpha);
        vertex(vc, m, n, dx, dy, dz, u1, v0, nx, ny, nz, light, overlay, alpha);
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float z,
                               float u, float v, float nx, float ny, float nz,
                               int light, int overlay, float alpha) {
        vc.vertex(m, x, y, z)
                .color(1f, 1f, 1f, alpha)
                .uv(u, v)
                .overlayCoords(overlay)
                .uv2(light)
                .normal(n, nx, ny, nz)
                .endVertex();
    }
}
