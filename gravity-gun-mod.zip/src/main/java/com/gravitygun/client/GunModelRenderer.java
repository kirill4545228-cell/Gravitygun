package com.gravitygun.client;

import com.gravitygun.GravityGunMod;
import com.gravitygun.GravityMode;
import com.gravitygun.client.model.GunModelData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Renders the gravity gun model (bones + cubes from the Blockbench file) with an animation pose. */
public final class GunModelRenderer {
    private GunModelRenderer() {}

    public static final ResourceLocation TEXTURE =
            new ResourceLocation(GravityGunMod.MODID, "textures/models/gravity_gun.png");

    /**
     * Renders in "model units" (1/16 block): the caller is expected to have scaled the pose stack.
     *
     * @param pose per-bone pose: [pos xyz, rot xyz, scale xyz]
     */
    public static void render(PoseStack ps, MultiBufferSource buffers, int light, int overlay,
                              float[][] pose, GravityMode mode) {
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        renderBone(0, ps, vc, light, overlay, pose, mode);
    }

    private static void renderBone(int idx, PoseStack ps, VertexConsumer vc, int light, int overlay,
                                   float[][] pose, GravityMode mode) {
        float[] p = pose[idx];
        float[] pv = GunModelData.PIVOT[idx];
        ps.pushPose();
        // Blockbench animation convention: position.x, rotation.x and rotation.y are inverted
        ps.translate(pv[0] - p[0], pv[1] + p[1], pv[2] + p[2]);
        ps.mulPose(Axis.ZP.rotationDegrees(p[5]));
        ps.mulPose(Axis.YP.rotationDegrees(-p[4]));
        ps.mulPose(Axis.XP.rotationDegrees(-p[3]));
        ps.scale(p[6], p[7], p[8]);
        ps.translate(-pv[0], -pv[1], -pv[2]);

        PoseStack.Pose last = ps.last();
        Matrix4f m = last.pose();
        Matrix3f n = last.normal();
        for (float[] c : GunModelData.CUBES[idx]) {
            cube(vc, m, n, c, light, overlay, mode);
        }
        for (int child = 0; child < GunModelData.PARENT.length; child++) {
            if (GunModelData.PARENT[child] == idx) {
                renderBone(child, ps, vc, light, overlay, pose, mode);
            }
        }
        ps.popPose();
    }

    private static void cube(VertexConsumer vc, Matrix4f m, Matrix3f n, float[] c, int light, int overlay, GravityMode mode) {
        float x0 = c[0], y0 = c[1], z0 = c[2], x1 = c[3], y1 = c[4], z1 = c[5];
        int emissive = (int) c[10];
        float r = 1f, g = 1f, b = 1f;
        float u0, v0, u1, v1;
        int l = light;
        if (emissive > 0) {
            // white swatch of the texture, colour comes from the mode
            u0 = (4f + 0.5f) / 16f;
            u1 = (8f - 0.5f) / 16f;
            v0 = (12f + 0.5f) / 16f;
            v1 = (16f - 0.5f) / 16f;
            r = mode.r;
            g = mode.g;
            b = mode.b;
            if (emissive == 2) {
                r = r + (1f - r) * 0.55f;
                g = g + (1f - g) * 0.55f;
                b = b + (1f - b) * 0.55f;
            }
            l = LightTexture.FULL_BRIGHT;
        } else {
            u0 = (c[6] + 0.5f) / 16f;
            v0 = (c[7] + 0.5f) / 16f;
            u1 = (c[8] - 0.5f) / 16f;
            v1 = (c[9] - 0.5f) / 16f;
        }
        // north (-Z)
        quad(vc, m, n, x1, y1, z0, x1, y0, z0, x0, y0, z0, x0, y1, z0, 0, 0, -1, u0, v0, u1, v1, r, g, b, l, overlay);
        // south (+Z)
        quad(vc, m, n, x0, y1, z1, x0, y0, z1, x1, y0, z1, x1, y1, z1, 0, 0, 1, u0, v0, u1, v1, r, g, b, l, overlay);
        // east (+X)
        quad(vc, m, n, x1, y1, z1, x1, y0, z1, x1, y0, z0, x1, y1, z0, 1, 0, 0, u0, v0, u1, v1, r, g, b, l, overlay);
        // west (-X)
        quad(vc, m, n, x0, y1, z0, x0, y0, z0, x0, y0, z1, x0, y1, z1, -1, 0, 0, u0, v0, u1, v1, r, g, b, l, overlay);
        // up (+Y)
        quad(vc, m, n, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, 0, 1, 0, u0, v0, u1, v1, r, g, b, l, overlay);
        // down (-Y)
        quad(vc, m, n, x0, y0, z1, x0, y0, z0, x1, y0, z0, x1, y0, z1, 0, -1, 0, u0, v0, u1, v1, r, g, b, l, overlay);
    }

    /** Vertices in order: top-left, bottom-left, bottom-right, top-right. */
    private static void quad(VertexConsumer vc, Matrix4f m, Matrix3f n,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float nx, float ny, float nz,
                             float u0, float v0, float u1, float v1,
                             float r, float g, float b, int light, int overlay) {
        vertex(vc, m, n, ax, ay, az, u0, v0, nx, ny, nz, r, g, b, light, overlay);
        vertex(vc, m, n, bx, by, bz, u0, v1, nx, ny, nz, r, g, b, light, overlay);
        vertex(vc, m, n, cx, cy, cz, u1, v1, nx, ny, nz, r, g, b, light, overlay);
        vertex(vc, m, n, dx, dy, dz, u1, v0, nx, ny, nz, r, g, b, light, overlay);
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float z,
                               float u, float v, float nx, float ny, float nz,
                               float r, float g, float b, int light, int overlay) {
        vc.vertex(m, x, y, z)
                .color(r, g, b, 1f)
                .uv(u, v)
                .overlayCoords(overlay)
                .uv2(light)
                .normal(n, nx, ny, nz)
                .endVertex();
    }
}
