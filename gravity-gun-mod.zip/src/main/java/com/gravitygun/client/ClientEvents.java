package com.gravitygun.client;

import com.gravitygun.GravityGunItem;
import com.gravitygun.GravityGunMod;
import com.gravitygun.GravityMode;
import com.gravitygun.client.model.GunAnimData;
import com.gravitygun.client.model.GunAnims;
import com.gravitygun.network.ActionPacket;
import com.gravitygun.network.ModNetwork;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GravityGunMod.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    private static boolean holdingGun(LocalPlayer p) {
        return p != null && p.getMainHandItem().getItem() instanceof GravityGunItem;
    }

    private static boolean onCooldown(LocalPlayer p) {
        return p.getCooldowns().isOnCooldown(p.getMainHandItem().getItem());
    }

    private static void send(ActionPacket.Action action, int value) {
        ModNetwork.CHANNEL.sendToServer(new ActionPacket(action, value));
    }

    // ------------------------------------------------------------ first person rendering

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        ItemStack stack = event.getItemStack();
        if (!(stack.getItem() instanceof GravityGunItem)) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) return;

        event.setCanceled(true);

        float[][] pose = ClientState.ANIM.update(Util.getMillis() / 1000.0);
        GravityMode mode = GravityGunItem.getMode(stack);

        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        // lower the gun while switching away to another slot (vanilla equip progress: 0 raised, 1 lowered)
        if (!holdingGun(player)) {
            ps.translate(0.0, -0.6 * event.getEquipProgress(), 0.0);
        }
        ps.translate(0.26, -0.27, -0.62);
        ps.mulPose(Axis.YP.rotationDegrees(8f));
        ps.mulPose(Axis.XP.rotationDegrees(2f));
        ps.scale(0.0145f, 0.0145f, 0.0145f);
        ps.translate(0.0, -2.0, 0.0);
        GunModelRenderer.render(ps, event.getMultiBufferSource(), event.getPackedLight(),
                OverlayTexture.NO_OVERLAY, pose, mode);
        ps.popPose();
    }

    // ------------------------------------------------------------ input

    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (!holdingGun(player) || event.getHand() != InteractionHand.MAIN_HAND) return;

        if (event.isAttack()) {
            event.setCanceled(true);
            event.setSwingHand(false);
            if (mc.screen == null && !onCooldown(player)) {
                send(ActionPacket.Action.FIRE, 0);
                ClientState.ANIM.play(GunAnimData.RELEASE, GunAnimData.IDLE, 0.03f);
            }
        } else if (event.isUseItem()) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.screen != null || !holdingGun(player) || !ClientState.lastUse) return;
        GravityMode mode = GravityGunItem.getMode(player.getMainHandItem());
        if (mode != GravityMode.GRAB && mode != GravityMode.MAGNET) return;
        double delta = event.getScrollDelta();
        if (delta == 0) return;
        event.setCanceled(true);
        send(ActionPacket.Action.SCROLL, delta > 0 ? 1 : -1);
    }

    private static void onPress(GravityMode mode, LocalPlayer player) {
        switch (mode) {
            case GRAB, MAGNET -> ClientState.ANIM.play(GunAnimData.GRAB, GunAnimData.GRAB_HOLD, 0.08f);
            case CANNON -> {
                if (!onCooldown(player)) {
                    ClientState.charging = true;
                    ClientState.chargeTicks = 0;
                    ClientState.ANIM.play(GunAnimData.CHARGE, GunAnimData.CHARGED_HOLD, 0.1f);
                }
            }
            case SHOCKWAVE -> {
                if (!onCooldown(player)) ClientState.ANIM.play(GunAnimData.RELEASE, GunAnimData.IDLE, 0.03f);
            }
            case LEVITATE, SINGULARITY -> {
                if (!onCooldown(player)) ClientState.ANIM.play(GunAnimData.GRAB, GunAnimData.IDLE, 0.05f);
            }
        }
    }

    private static void onRelease(GravityMode mode) {
        switch (mode) {
            case GRAB, MAGNET -> ClientState.ANIM.play(GunAnimData.RELEASE, GunAnimData.IDLE, 0.08f);
            case CANNON -> {
                if (ClientState.charging) {
                    if (ClientState.chargeTicks >= ClientState.CHARGE_MIN) {
                        ClientState.ANIM.play(GunAnimData.FIRE, GunAnimData.IDLE, 0.03f);
                    } else {
                        ClientState.ANIM.play(GunAnimData.RELEASE, GunAnimData.IDLE, 0.08f);
                    }
                }
            }
            default -> { }
        }
        ClientState.charging = false;
        ClientState.chargeTicks = 0;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) {
            ClientState.lastUse = false;
            ClientState.charging = false;
            ClientState.wasHolding = false;
            while (ModKeys.MODE.consumeClick()) { /* drain */ }
            return;
        }

        boolean gun = holdingGun(player);
        int slot = player.getInventory().selected;
        if (gun && (!ClientState.wasHolding || slot != ClientState.lastSlot)) {
            ClientState.ANIM.play(GunAnims.EQUIP, GunAnimData.IDLE, 0.05f);
            ClientState.charging = false;
        }
        ClientState.wasHolding = gun;
        ClientState.lastSlot = slot;

        boolean canAct = gun && mc.screen == null && mc.mouseHandler.isMouseGrabbed();
        boolean down = mc.options.keyUse.isDown();
        if (!down) ClientState.suppressUse = false;
        boolean use = canAct && down && !ClientState.suppressUse;
        GravityMode mode = gun ? GravityGunItem.getMode(player.getMainHandItem()) : GravityMode.GRAB;

        if (use != ClientState.lastUse) {
            ClientState.lastUse = use;
            send(ActionPacket.Action.HOLD, use ? 1 : 0);
            if (use) onPress(mode, player);
            else onRelease(mode);
        }
        if (use && ClientState.charging && ClientState.chargeTicks < ClientState.CHARGE_FULL) {
            ClientState.chargeTicks++;
        }

        while (ModKeys.MODE.consumeClick()) {
            if (canAct) {
                send(ActionPacket.Action.MODE, player.isShiftKeyDown() ? -1 : 1);
                ClientState.ANIM.play(GunAnims.SWITCH, GunAnimData.IDLE, 0.04f);
                ClientState.switchAtMs = Util.getMillis();
                ClientState.charging = false;
                ClientState.chargeTicks = 0;
                if (down) ClientState.suppressUse = true;
            }
        }
    }
}
