package com.gravitygun.client;

import com.gravitygun.GravityGunItem;
import com.gravitygun.GravityGunMod;
import com.gravitygun.GravityMode;
import com.gravitygun.client.model.GunAnimData;
import com.gravitygun.client.model.GunAnim;
import com.gravitygun.network.ActionPacket;
import com.gravitygun.network.ModNetwork;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GravityGunMod.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    private static boolean holdingGun(LocalPlayer p) {
        return p != null && p.getMainHandItem().getItem() instanceof GravityGunItem;
    }

    private static boolean onCooldown(LocalPlayer p) {
        return p.getCooldowns().isOnCooldown(p.getMainHandItem().getItem());
    }

    private static void send(ActionPacket.Action action, int value) {
        ModNetwork.CHANNEL.sendToServer(new ActionPacket(action, value));
    }

    // ------------------------------------------------------------ first person rendering

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        ItemStack stack = event.getItemStack();
        if (!(stack.getItem() instanceof GravityGunItem)) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) return;

        event.setCanceled(true);

        float[][] pose = ClientState.ANIM.update(Util.getMillis() / 1000.0);
        GravityMode mode = GravityGunItem.getMode(stack);

        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        // lower the gun while switching away to another slot (vanilla equip progress: 0 raised, 1 lowered)
        if (!holdingGun(player)) {
            ps.translate(0.0, -0.6 * event.getEquipProgress(), 0.0);
        }
        ps.translate(0.34, -0.40, -0.80);
        ps.mulPose(Axis.YP.rotationDegrees(8f));
        ps.mulPose(Axis.XP.rotationDegrees(12f));
        ps.mulPose(Axis.ZP.rotationDegrees(-10f));
        ps.scale(0.021f, 0.021f, 0.021f);
        ps.translate(0.0, -6.0, -4.0);
        GunModelRenderer.render(ps, event.getMultiBufferSource(), event.getPackedLight(),
                OverlayTexture.NO_OVERLAY, pose, mode, true);
        ps.popPose();
    }

    // ------------------------------------------------------------ input

    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (!holdingGun(player) || event.getHand() != InteractionHand.MAIN_HAND) return;

        if (event.isAttack()) {
            event.setCanceled(true);
            event.setSwingHand(false);
            if (mc.screen == null && !ClientState.holstered && !onCooldown(player)) {
                send(ActionPacket.Action.FIRE, 0);
                ClientState.idleTicks = 0;
                if (ClientState.holdingObject) {
                    ClientState.holdingObject = false;
                    ClientState.ANIM.play(GunAnimData.LAUNCH_HELD, GunAnimData.IDLE, 0.03f);
                } else {
                    ClientState.ANIM.play(GunAnimData.PUNT, GunAnimData.IDLE, 0.03f);
                }
            }
        } else if (event.isUseItem()) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.screen != null || !holdingGun(player) || !ClientState.lastUse) return;
        GravityMode mode = GravityGunItem.getMode(player.getMainHandItem());
        if (mode != GravityMode.GRAB && mode != GravityMode.MAGNET) return;
        double delta = event.getScrollDelta();
        if (delta == 0) return;
        event.setCanceled(true);
        send(ActionPacket.Action.SCROLL, delta > 0 ? 1 : -1);
    }

    private static void deny() {
        ClientState.ANIM.play(GunAnimData.DENY, GunAnimData.IDLE, 0.05f);
    }

    private static void onPress(GravityMode mode, LocalPlayer player) {
        ClientState.idleTicks = 0;
        switch (mode) {
            case GRAB -> {
                ClientState.holdingObject = false;
                ClientState.ANIM.play(GunAnimData.GRAB_START, GunAnimData.GRAB_HOLD, 0.08f);
            }
            case MAGNET -> ClientState.ANIM.play(GunAnimData.PULL, GunAnimData.GRAB_HOLD, 0.08f);
            case CANNON -> {
                if (onCooldown(player)) {
                    deny();
                } else {
                    ClientState.charging = true;
                    ClientState.chargeTicks = 0;
                    ClientState.ANIM.play(GunAnimData.CHARGE, GunAnimData.CHARGED_HOLD, 0.1f);
                }
            }
            case SHOCKWAVE -> {
                if (onCooldown(player)) deny();
                else ClientState.ANIM.play(GunAnimData.PUNT, GunAnimData.IDLE, 0.03f);
            }
            case LEVITATE -> {
                if (onCooldown(player)) deny();
                else ClientState.ANIM.play(GunAnimData.GRAB_START, GunAnimData.GRAB_RELEASE, 0.05f);
            }
            case SINGULARITY -> {
                if (onCooldown(player)) deny();
                else ClientState.ANIM.play(GunAnimData.OVERCHARGE, GunAnimData.IDLE, 0.05f);
            }
        }
    }

    private static void onRelease(GravityMode mode) {
        switch (mode) {
            case GRAB -> {
                if (ClientState.holdingObject) {
                    ClientState.ANIM.play(GunAnimData.GRAB_RELEASE, GunAnimData.IDLE, 0.08f);
                }
                ClientState.holdingObject = false;
            }
            case MAGNET -> ClientState.ANIM.play(GunAnimData.GRAB_RELEASE, GunAnimData.IDLE, 0.08f);
            case CANNON -> {
                if (ClientState.charging) {
                    if (ClientState.chargeTicks >= ClientState.CHARGE_MIN) {
                        ClientState.ANIM.play(GunAnimData.SHOOT, GunAnimData.COOLDOWN, 0.03f);
                    } else {
                        ClientState.ANIM.play(GunAnimData.GRAB_RELEASE, GunAnimData.IDLE, 0.08f);
                    }
                }
            }
            default -> { }
        }
        ClientState.charging = false;
        ClientState.chargeTicks = 0;
    }

    private static boolean isLocomotion(GunAnim a) {
        return a == GunAnimData.IDLE || a == GunAnimData.WALK || a == GunAnimData.SPRINT;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) {
            ClientState.lastUse = false;
            ClientState.charging = false;
            ClientState.wasHolding = false;
            ClientState.holdingObject = false;
            ClientState.holstered = false;
            while (ModKeys.MODE.consumeClick()) { /* drain */ }
            while (ModKeys.INSPECT.consumeClick()) { /* drain */ }
            while (ModKeys.HOLSTER.consumeClick()) { /* drain */ }
            return;
        }

        boolean gun = holdingGun(player);
        int slot = player.getInventory().selected;
        if (gun && (!ClientState.wasHolding || slot != ClientState.lastSlot)) {
            ClientState.ANIM.play(GunAnimData.DRAW, GunAnimData.IDLE, 0.05f);
            ClientState.charging = false;
            ClientState.holdingObject = false;
            ClientState.holstered = false;
            ClientState.idleTicks = 0;
        }
        ClientState.wasHolding = gun;
        ClientState.lastSlot = slot;

        boolean canAct = gun && mc.screen == null && mc.mouseHandler.isMouseGrabbed();
        boolean active = canAct && !ClientState.holstered;
        boolean down = mc.options.keyUse.isDown();
        if (!down) ClientState.suppressUse = false;
        boolean use = active && down && !ClientState.suppressUse;
        GravityMode mode = gun ? GravityGunItem.getMode(player.getMainHandItem()) : GravityMode.GRAB;

        if (use != ClientState.lastUse) {
            ClientState.lastUse = use;
            send(ActionPacket.Action.HOLD, use ? 1 : 0);
            if (use) onPress(mode, player);
            else onRelease(mode);
        }
        if (use && ClientState.charging && mode == GravityMode.CANNON) {
            if (ClientState.chargeTicks < ClientState.CHARGE_OVER) ClientState.chargeTicks++;
            if (ClientState.chargeTicks >= ClientState.CHARGE_OVER) {
                // overloaded: the server fires by itself
                ClientState.charging = false;
                ClientState.chargeTicks = 0;
                ClientState.ANIM.play(GunAnimData.OVERCHARGE, GunAnimData.COOLDOWN, 0.05f);
            }
        }

        while (ModKeys.MODE.consumeClick()) {
            if (active) {
                send(ActionPacket.Action.MODE, player.isShiftKeyDown() ? -1 : 1);
                // the "draw" animation played fast: the gun re-arms itself, glow colour changes
                ClientState.ANIM.play(GunAnimData.DRAW, GunAnimData.IDLE, 0.04f, 2.4f);
                ClientState.switchAtMs = Util.getMillis();
                ClientState.charging = false;
                ClientState.chargeTicks = 0;
                ClientState.holdingObject = false;
                ClientState.idleTicks = 0;
                if (down) ClientState.suppressUse = true;
            }
        }
        while (ModKeys.INSPECT.consumeClick()) {
            if (active && isLocomotion(ClientState.ANIM.current())) {
                ClientState.ANIM.play(GunAnimData.INSPECT, GunAnimData.IDLE, 0.15f);
                ClientState.idleTicks = 0;
            }
        }
        while (ModKeys.HOLSTER.consumeClick()) {
            if (canAct) {
                ClientState.holstered = !ClientState.holstered;
                if (ClientState.holstered) {
                    if (ClientState.lastUse) {
                        ClientState.lastUse = false;
                        send(ActionPacket.Action.HOLD, 0);
                    }
                    ClientState.charging = false;
                    ClientState.holdingObject = false;
                    ClientState.ANIM.playAndHold(GunAnimData.HOLSTER, 0.1f);
                } else {
                    ClientState.ANIM.play(GunAnimData.DRAW, GunAnimData.IDLE, 0.05f);
                }
                player.displayClientMessage(Component.translatable(
                        ClientState.holstered ? "message.gravitygun.safe_on" : "message.gravitygun.safe_off"), true);
            }
        }

        if (active) {
            GunAnim cur = ClientState.ANIM.current();
            boolean busy = use || ClientState.charging;
            if (isLocomotion(cur) && !busy) {
                double speed = player.getDeltaMovement().horizontalDistanceSqr();
                boolean moving = speed > 0.0025 && player.onGround();
                GunAnim want = !moving ? GunAnimData.IDLE : (player.isSprinting() ? GunAnimData.SPRINT : GunAnimData.WALK);
                if (want != cur) ClientState.ANIM.play(want, GunAnimData.IDLE, 0.2f);
                if (want == GunAnimData.IDLE) {
                    if (++ClientState.idleTicks > ClientState.INSPECT_AFTER_TICKS) {
                        ClientState.idleTicks = 0;
                        ClientState.ANIM.play(GunAnimData.INSPECT, GunAnimData.IDLE, 0.2f);
                    }
                } else {
                    ClientState.idleTicks = 0;
                }
            } else if (!isLocomotion(cur)) {
                ClientState.idleTicks = 0;
            }
        }
    }
}
