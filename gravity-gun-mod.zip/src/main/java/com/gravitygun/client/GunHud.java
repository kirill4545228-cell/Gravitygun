package com.gravitygun.client;

import com.gravitygun.GravityGunItem;
import com.gravitygun.GravityGunMod;
import com.gravitygun.GravityMode;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Small HUD under the crosshair: mode selector, mode name, cooldown and cannon charge. */
@Mod.EventBusSubscriber(modid = GravityGunMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class GunHud {
    private GunHud() {}

    @SubscribeEvent
    public static void register(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("mode_hud", (gui, graphics, partialTick, width, height) -> render(graphics, width, height, partialTick));
    }

    private static int withAlpha(int argb, int alpha) {
        return (alpha << 24) | (argb & 0x00FFFFFF);
    }

    private static void render(GuiGraphics g, int w, int h, float partial) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui) return;
        ItemStack stack = player.getMainHandItem();
        if (!(stack.getItem() instanceof GravityGunItem)) return;

        GravityMode mode = GravityGunItem.getMode(stack);
        GravityMode[] all = GravityMode.values();
        int cx = w / 2;
        int cy = h / 2;

        int size = 7;
        int gap = 4;
        int total = all.length * size + (all.length - 1) * gap;
        int x0 = cx - total / 2;
        int y0 = cy + 17;

        for (int i = 0; i < all.length; i++) {
            boolean selected = all[i] == mode;
            int col = all[i].argb();
            int sx = x0 + i * (size + gap);
            g.fill(sx - 1, y0 - 1, sx + size + 1, y0 + size + 1, selected ? 0xFFFFFFFF : 0x80000000);
            g.fill(sx, y0, sx + size, y0 + size, selected ? col : withAlpha(col, 0x70));
        }

        long since = Util.getMillis() - ClientState.switchAtMs;
        boolean flash = since < 450;
        int nameColor = flash && (since / 70) % 2 == 0 ? 0xFFFFFFFF : mode.argb();
        Component name = mode.displayName();
        int tw = mc.font.width(name);
        g.drawString(mc.font, name, cx - tw / 2, y0 + size + 4, nameColor, true);

        int barW = 54;
        int barY = y0 + size + 16;
        float cooldown = player.getCooldowns().getCooldownPercent(stack.getItem(), partial);
        if (cooldown > 0f) {
            g.fill(cx - barW / 2, barY, cx + barW / 2, barY + 2, 0x80000000);
            g.fill(cx - barW / 2, barY, cx - barW / 2 + (int) (barW * (1f - cooldown)), barY + 2, withAlpha(mode.argb(), 0xB0));
        }

        if (mode == GravityMode.CANNON && ClientState.charging) {
            float prog = Math.min(1f, ClientState.chargeTicks / (float) ClientState.CHARGE_FULL);
            boolean ready = ClientState.chargeTicks >= ClientState.CHARGE_MIN;
            int by = cy + 8 - 28;
            int bw = 64;
            g.fill(cx - bw / 2 - 1, by - 1, cx + bw / 2 + 1, by + 5, 0xA0000000);
            int fillCol = ready ? mode.argb() : withAlpha(mode.argb(), 0x90);
            if (ClientState.chargeTicks >= ClientState.CHARGE_FULL && (Util.getMillis() / 100) % 2 == 0) {
                fillCol = 0xFFFFFFFF;
            }
            g.fill(cx - bw / 2, by, cx - bw / 2 + (int) (bw * prog), by + 4, fillCol);
            int minX = cx - bw / 2 + (int) (bw * ClientState.CHARGE_MIN / (float) ClientState.CHARGE_FULL);
            g.fill(minX, by - 2, minX + 1, by + 6, 0xFFFFFFFF);
        }
    }
}
