package com.gravitygun.client;

import com.gravitygun.GravityGunMod;
import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GravityGunMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ModKeys {
    private ModKeys() {}

    public static final KeyMapping MODE = new KeyMapping("key.gravitygun.mode",
            InputConstants.KEY_R, "key.categories.gravitygun");
    public static final KeyMapping INSPECT = new KeyMapping("key.gravitygun.inspect",
            InputConstants.KEY_V, "key.categories.gravitygun");
    public static final KeyMapping HOLSTER = new KeyMapping("key.gravitygun.holster",
            InputConstants.KEY_G, "key.categories.gravitygun");

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        event.register(MODE);
        event.register(INSPECT);
        event.register(HOLSTER);
    }
}
