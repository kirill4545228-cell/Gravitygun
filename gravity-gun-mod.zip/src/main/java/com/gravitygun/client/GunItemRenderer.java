package com.gravitygun.client;

import com.gravitygun.GravityGunItem;
import com.gravitygun.GravityMode;
import com.gravitygun.client.model.GunAnimData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Renders the gun for inventory, ground, item frames, third person and off-hand. */
public class GunItemRenderer extends BlockEntityWithoutLevelRenderer {
    private static GunItemRenderer instance;

    public static GunItemRenderer get() {
        if (instance == null) {
            Minecraft mc = Minecraft.getInstance();
            instance = new GunItemRenderer(mc.getBlockEntityRenderDispatcher(), mc.getEntityModels());
        }
        return instance;
    }

    private GunItemRenderer(net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher dispatcher,
                            net.minecraft.client.model.geom.EntityModelSet models) {
        super(dispatcher, models);
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack ps,
                             MultiBufferSource buffers, int light, int overlay) {
        GravityMode mode = GravityGunItem.getMode(stack);
        float t = (float) ((Util.getMillis() / 1000.0) % 4.0);
        float[][] pose = GunAnimData.IDLE.sample(t);

        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        int l = light;
        switch (ctx) {
            case GUI, FIXED -> {
                l = LightTexture.FULL_BRIGHT;
                ps.mulPose(Axis.ZP.rotationDegrees(24f));
                ps.mulPose(Axis.XP.rotationDegrees(14f));
                ps.mulPose(Axis.YP.rotationDegrees(-90f));
                ps.scale(0.048f, 0.048f, 0.048f);
                ps.translate(0.0, 1.0, 1.2);
            }
            case THIRD_PERSON_RIGHT_HAND, THIRD_PERSON_LEFT_HAND -> {
                ps.mulPose(Axis.XP.rotationDegrees(90f));
                ps.scale(0.032f, 0.032f, 0.032f);
                ps.translate(0.0, 3.5, -4.5);
            }
            case FIRST_PERSON_RIGHT_HAND, FIRST_PERSON_LEFT_HAND -> {
                ps.mulPose(Axis.YP.rotationDegrees(10f));
                ps.scale(0.04f, 0.04f, 0.04f);
                ps.translate(0.0, 1.0, 1.2);
            }
            default -> {
                ps.scale(0.03f, 0.03f, 0.03f);
                ps.translate(0.0, 1.0, 1.2);
            }
        }
        GunModelRenderer.render(ps, buffers, l, overlay, pose, mode);
        ps.popPose();
    }
}
