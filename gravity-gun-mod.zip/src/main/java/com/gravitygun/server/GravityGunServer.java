package com.gravitygun.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.gravitygun.GravityGunItem;
import com.gravitygun.GravityMode;
import com.gravitygun.network.ActionPacket;
import com.gravitygun.network.FeedbackPacket;
import com.gravitygun.network.ModNetwork;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageSources;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.EnderDragonPart;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

/** All server side behaviour of the gravity gun. Everything runs on the server thread. */
public final class GravityGunServer {
    private GravityGunServer() {}

    private static final double GRAB_RANGE = 16.0;
    private static final double PUNT_RANGE = 24.0;

    // ------------------------------------------------------------------ state

    static final class PlayerState {
        boolean holding;
        Entity held;
        boolean origNoGravity;
        boolean origNoPhysics;
        double distance = 5.0;
        double radius = 10.0;
        Vec3 vel = Vec3.ZERO;
        int charge;
        Vec3 grapplePoint;
        Entity grappleEntity;
        int grappleTicks;
    }

    static final class Thrown {
        final Entity entity;
        final UUID owner;
        int age;
        Vec3 lastVel = Vec3.ZERO;
        final Set<Integer> hit = new HashSet<>();
        /** "Momentum" of a thrown block: how much material it can still smash through. */
        double budget;

        Thrown(Entity entity, UUID owner) {
            this.entity = entity;
            this.owner = owner;
        }
    }

    static final class Well {
        final ServerLevel level;
        final UUID owner;
        final Vec3 pos;
        int ticks;

        Well(ServerLevel level, UUID owner, Vec3 pos, int ticks) {
            this.level = level;
            this.owner = owner;
            this.pos = pos;
            this.ticks = ticks;
        }
    }

    static final class Bolt {
        final ServerLevel level;
        final UUID owner;
        Vec3 pos;
        final Vec3 dir;
        final float power;
        int ticks;

        Bolt(ServerLevel level, UUID owner, Vec3 pos, Vec3 dir, float power) {
            this.level = level;
            this.owner = owner;
            this.pos = pos;
            this.dir = dir;
            this.power = power;
        }
    }

    private static final int CHARGE_MIN = 24;
    private static final int CHARGE_FULL = 40;
    private static final int CHARGE_OVER = 80;
    private static final DustParticleOptions BOLT_DUST = new DustParticleOptions(new Vector3f(1.0f, 0.3f, 0.7f), 1.6f);

    static final class Frozen {
        final Entity entity;
        int ticks;

        Frozen(Entity entity, int ticks) {
            this.entity = entity;
            this.ticks = ticks;
        }
    }

    private static final List<Frozen> FROZEN = new ArrayList<>();
    private static final List<Bolt> BOLTS = new ArrayList<>();
    private static final Map<UUID, PlayerState> STATES = new HashMap<>();
    private static final List<Thrown> THROWN = new ArrayList<>();
    private static final List<Well> WELLS = new ArrayList<>();

    private static PlayerState state(ServerPlayer p) {
        return STATES.computeIfAbsent(p.getUUID(), id -> new PlayerState());
    }

    public static void clearAll(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            PlayerState st = STATES.get(p.getUUID());
            if (st != null) {
                st.holding = false;
                releaseHeld(p, st, null);
            }
        }
        STATES.clear();
        THROWN.clear();
        WELLS.clear();
        BOLTS.clear();
        FROZEN.clear();
    }

    public static void forget(ServerPlayer p) {
        PlayerState st = STATES.remove(p.getUUID());
        if (st != null) {
            st.holding = false;
            releaseHeld(p, st, null);
        }
    }

    // ---------------------------------------------------------------- packets

    public static void handleAction(ServerPlayer p, ActionPacket.Action action, int value) {
        ItemStack stack = p.getMainHandItem();
        boolean gun = stack.getItem() instanceof GravityGunItem;
        switch (action) {
            case HOLD -> {
                if (value != 0 && gun) startHold(p, stack);
                else stopHold(p);
            }
            case FIRE -> {
                if (gun) fire(p, stack);
            }
            case SCROLL -> {
                if (gun) scroll(p, stack, value);
            }
            case MODE -> {
                if (gun) changeMode(p, stack, value);
            }
        }
    }

    private static void startHold(ServerPlayer p, ItemStack stack) {
        PlayerState st = state(p);
        if (st.holding) return;
        GravityMode mode = GravityGunItem.getMode(stack);
        if (mode.instant) {
            if (p.getCooldowns().isOnCooldown(stack.getItem())) return;
            switch (mode) {
                case SHOCKWAVE -> shockwave(p, stack);
                case LEVITATE -> levitate(p, stack);
                case SINGULARITY -> singularity(p, stack);
                case STASIS -> stasis(p, stack);
                default -> {}
            }
            return;
        }
        if (mode == GravityMode.CANNON && p.getCooldowns().isOnCooldown(stack.getItem())) return;
        st.holding = true;
        st.charge = 0;
        if (mode == GravityMode.CANNON) {
            sound(p, SoundEvents.BEACON_ACTIVATE, 0.5f, 1.4f);
        } else if (mode == GravityMode.GRAB) {
            tryGrab(p, st);
        } else if (mode == GravityMode.MAGNET) {
            sound(p, SoundEvents.BEACON_ACTIVATE, 0.4f, 1.9f);
        } else if (mode == GravityMode.GRAPPLE) {
            startGrapple(p, st);
        } else if (mode == GravityMode.SHIELD) {
            sound(p, SoundEvents.BEACON_ACTIVATE, 0.6f, 1.2f);
        }
    }

    private static void stopHold(ServerPlayer p) {
        PlayerState st = STATES.get(p.getUUID());
        if (st == null) return;
        boolean wasHolding = st.holding;
        st.holding = false;
        releaseHeld(p, st, null);
        ItemStack stack = p.getMainHandItem();
        if (wasHolding && stack.getItem() instanceof GravityGunItem
                && GravityGunItem.getMode(stack) == GravityMode.CANNON && st.charge >= CHARGE_MIN) {
            fireBolt(p, stack, st.charge);
        }
        st.charge = 0;
    }

    private static void changeMode(ServerPlayer p, ItemStack stack, int dir) {
        PlayerState st = state(p);
        st.holding = false;
        st.charge = 0;
        releaseHeld(p, st, null);
        GravityMode mode = GravityGunItem.getMode(stack).shift(dir >= 0 ? 1 : -1);
        GravityGunItem.setMode(stack, mode);
        sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0f, 0.8f + 0.2f * mode.ordinal());
    }

    private static void scroll(ServerPlayer p, ItemStack stack, int dir) {
        PlayerState st = state(p);
        GravityMode mode = GravityGunItem.getMode(stack);
        if (mode == GravityMode.GRAB) {
            st.distance = Mth.clamp(st.distance + dir * 0.75, 1.5, 14.0);
        } else if (mode == GravityMode.MAGNET) {
            st.radius = Mth.clamp(st.radius + dir * 1.5, 3.0, 16.0);
            p.displayClientMessage(Component.translatable("message.gravitygun.radius", String.format("%.1f", st.radius)), true);
        }
    }

    // ------------------------------------------------------------ ticking

    public static void tickPlayer(ServerPlayer p) {
        PlayerState st = STATES.get(p.getUUID());
        if (st == null || !st.holding) return;
        ItemStack stack = p.getMainHandItem();
        if (!(stack.getItem() instanceof GravityGunItem) || !p.isAlive()) {
            st.holding = false;
            st.charge = 0;
            releaseHeld(p, st, null);
            return;
        }
        GravityMode mode = GravityGunItem.getMode(stack);
        if (mode == GravityMode.GRAB) updateHeld(p, st);
        else if (mode == GravityMode.MAGNET) magnet(p, st);
        else if (mode == GravityMode.CANNON) chargeTick(p, st);
        else if (mode == GravityMode.GRAPPLE) grappleTick(p, st);
        else if (mode == GravityMode.SHIELD) shieldTick(p, st);
    }

    public static void serverTickStart() {
        Iterator<Thrown> it = THROWN.iterator();
        while (it.hasNext()) {
            Thrown t = it.next();
            Entity e = t.entity;
            if (e.isRemoved()) {
                it.remove();
                continue;
            }
            t.lastVel = e.getDeltaMovement();
            if (e instanceof FallingBlockEntity fb && t.age >= 1 && t.lastVel.length() > 0.8) {
                if (!thrownBlockStep(fb, t)) it.remove();
            }
        }
    }

    /** Returns false when the block has been destroyed. Strong blocks smash weaker ones, otherwise it shatters. */
    private static boolean thrownBlockStep(FallingBlockEntity fb, Thrown t) {
        Level level = fb.level();
        double speed = t.lastVel.length();
        Vec3 dir = t.lastVel.scale(1.0 / speed);
        Vec3 start = fb.position().add(0, fb.getBbHeight() * 0.5, 0);
        Vec3 end = start.add(dir.scale(speed + 0.55));
        BlockHitResult hit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, fb));
        if (hit.getType() != HitResult.Type.BLOCK) return true;

        BlockPos hp = hit.getBlockPos();
        BlockState target = level.getBlockState(hp);
        float targetHardness = target.getDestroySpeed(level, hp);
        float myHardness = fb.getBlockState().getDestroySpeed(level, hp);
        ServerPlayer owner = ownerOf(fb, t.owner);

        boolean canSmash = owner != null && t.budget > 0 && targetHardness >= 0 && myHardness > targetHardness
                && breakAllowed(level, owner, hp, target);
        if (canSmash) {
            level.destroyBlock(hp, true, owner);
            t.budget -= Math.max(0.5, targetHardness);
            Vec3 slowed = t.lastVel.scale(0.88);
            fb.setDeltaMovement(slowed);
            t.lastVel = slowed;
            sync(fb);
            if (t.budget > 0) return true;
        }
        shatter(fb, t);
        return false;
    }

    private static ServerPlayer ownerOf(Entity e, UUID owner) {
        MinecraftServer server = e.getServer();
        return server != null ? server.getPlayerList().getPlayer(owner) : null;
    }

    /** Common checks before a block may be destroyed by the gun (protection mods, tile entities, bedrock...). */
    private static boolean breakAllowed(Level level, ServerPlayer owner, BlockPos pos, BlockState state) {
        if (state.isAir() || !state.getFluidState().isEmpty() || state.hasBlockEntity()) return false;
        if (state.getDestroySpeed(level, pos) < 0) return false;
        if (!owner.mayBuild() || !level.mayInteract(owner, pos)) return false;
        return !MinecraftForge.EVENT_BUS.post(new BlockEvent.BreakEvent(level, pos, state, owner));
    }

    public static void serverTickEnd() {
        Iterator<Thrown> it = THROWN.iterator();
        while (it.hasNext()) {
            Thrown t = it.next();
            if (!tickThrown(t)) it.remove();
        }
        Iterator<Frozen> fi = FROZEN.iterator();
        while (fi.hasNext()) {
            if (!tickFrozen(fi.next())) fi.remove();
        }
        Iterator<Bolt> bi = BOLTS.iterator();
        while (bi.hasNext()) {
            if (!tickBolt(bi.next())) bi.remove();
        }
        Iterator<Well> wi = WELLS.iterator();
        while (wi.hasNext()) {
            Well w = wi.next();
            if (!tickWell(w)) wi.remove();
        }
    }

    // ------------------------------------------------------------ grabbing

    private static final class Target {
        Entity entity;
        BlockPos block;
        Vec3 point;
        double dist;
    }

    private static Target pick(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(range));
        Level level = p.level();

        Target best = null;
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, p));
        if (hit.getType() == HitResult.Type.BLOCK) {
            best = new Target();
            best.block = hit.getBlockPos();
            best.point = hit.getLocation();
            best.dist = eye.distanceTo(hit.getLocation());
        }

        AABB search = p.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0);
        Entity found = null;
        double foundDist = best != null ? best.dist : range;
        Vec3 foundPoint = null;
        for (Entity e : level.getEntities(p, search, x -> x.isAlive() && !x.isSpectator() && canGrab(x))) {
            AABB bb = e.getBoundingBox().inflate(Math.max(0.3, e.getPickRadius()));
            Optional<Vec3> clip = bb.clip(eye, end);
            Vec3 pt = null;
            if (clip.isPresent()) pt = clip.get();
            else if (bb.contains(eye)) pt = eye;
            if (pt == null) continue;
            double d = eye.distanceTo(pt);
            if (d <= foundDist) {
                foundDist = d;
                found = e;
                foundPoint = pt;
            }
        }
        if (found != null) {
            Target t = new Target();
            t.entity = found;
            t.point = foundPoint;
            t.dist = foundDist;
            return t;
        }
        return best;
    }

    private static boolean canGrab(Entity e) {
        if (e instanceof Player || e instanceof EnderDragon || e instanceof EnderDragonPart) return false;
        if (e instanceof HangingEntity) return false;
        if (e.isPassenger() || e.isVehicle()) return false;
        return !e.isRemoved();
    }

    private static boolean isHeldByAnyone(Entity e) {
        for (PlayerState st : STATES.values()) {
            if (st.held == e) return true;
        }
        return false;
    }

    private static boolean canGrabBlock(ServerPlayer p, Level level, BlockPos pos, BlockState state) {
        if (state.isAir() || !state.getFluidState().isEmpty()) return false;
        if (state.hasBlockEntity()) return false;
        float hardness = state.getDestroySpeed(level, pos);
        if (hardness < 0 || hardness > 50) return false;
        if (!state.isCollisionShapeFullBlock(level, pos)) return false;
        if (!p.mayBuild()) return false;
        return level.mayInteract(p, pos);
    }

    private static FallingBlockEntity grabBlock(ServerPlayer p, BlockPos pos) {
        ServerLevel level = p.serverLevel();
        BlockState state = level.getBlockState(pos);
        if (!canGrabBlock(p, level, pos, state)) return null;
        if (MinecraftForge.EVENT_BUS.post(new BlockEvent.BreakEvent(level, pos, state, p))) return null;
        return FallingBlockEntity.fall(level, pos, state);
    }

    private static void tryGrab(ServerPlayer p, PlayerState st) {
        Target t = pick(p, GRAB_RANGE);
        if (t == null) {
            deny(p);
            return;
        }
        Entity e = t.entity;
        if (e == null) {
            e = grabBlock(p, t.block);
            if (e == null) {
                deny(p);
                return;
            }
        } else if (isHeldByAnyone(e)) {
            deny(p);
            return;
        }
        removeThrown(e);
        st.held = e;
        st.origNoGravity = e.isNoGravity();
        st.origNoPhysics = e.noPhysics;
        e.setNoGravity(true);
        if (e instanceof FallingBlockEntity) e.noPhysics = true;
        st.distance = Mth.clamp(p.getEyePosition().distanceTo(e.position()), 2.0, 12.0);
        st.vel = Vec3.ZERO;
        sound(p, SoundEvents.BEACON_ACTIVATE, 0.5f, 2.0f);
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new FeedbackPacket(FeedbackPacket.GRAB_OK));
    }

    private static void updateHeld(ServerPlayer p, PlayerState st) {
        Entity e = st.held;
        if (e == null) return;
        if (e.isRemoved() || e.level() != p.level()) {
            st.held = null;
            return;
        }
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double dist = st.distance;
        double margin = Math.max(e.getBbWidth(), e.getBbHeight()) * 0.5 + 0.15;

        BlockHitResult hit = p.level().clip(new ClipContext(eye, eye.add(look.scale(dist)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (hit.getType() != HitResult.Type.MISS) {
            dist = Math.max(1.0, Math.min(dist, eye.distanceTo(hit.getLocation()) - margin));
        }
        Vec3 target = eye.add(look.scale(dist));
        Vec3 goal = new Vec3(target.x, target.y - e.getBbHeight() * 0.5, target.z);
        Vec3 old = e.position();
        Vec3 next = old.add(goal.subtract(old).scale(0.55));
        st.vel = next.subtract(old);
        if (st.vel.length() > 1.2) st.vel = st.vel.normalize().scale(1.2);

        e.setNoGravity(true);
        e.moveTo(next.x, next.y, next.z);
        e.setDeltaMovement(Vec3.ZERO);
        e.fallDistance = 0;
        sync(e);

        if (e instanceof FallingBlockEntity fb) {
            fb.time = 1;
        }
        if (e instanceof Mob mob) {
            mob.setTarget(null);
            mob.getNavigation().stop();
        }
        if (e instanceof LivingEntity le && p.tickCount % 10 == 0) {
            le.addEffect(new MobEffectInstance(MobEffects.GLOWING, 15, 0, false, false));
        }
        if (p.tickCount % 2 == 0) {
            Vec3 from = eye.add(look.scale(1.0)).add(0, -0.35, 0);
            Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0);
            double f = p.getRandom().nextDouble();
            Vec3 pt = from.add(to.subtract(from).scale(f));
            p.serverLevel().sendParticles(ParticleTypes.ELECTRIC_SPARK, pt.x, pt.y, pt.z, 1, 0.05, 0.05, 0.05, 0.0);
        }
    }

    private static void releaseHeld(ServerPlayer p, PlayerState st, Vec3 launchVel) {
        st.grapplePoint = null;
        st.grappleEntity = null;
        st.grappleTicks = 0;
        Entity e = st.held;
        st.held = null;
        if (e == null || e.isRemoved()) return;
        e.setNoGravity(st.origNoGravity);
        e.noPhysics = st.origNoPhysics;
        e.setDeltaMovement(st.vel.scale(0.8));
        sync(e);
        sound(p, SoundEvents.BEACON_DEACTIVATE, 0.4f, 2.0f);
    }

    // ------------------------------------------------------------- firing

    private static void fire(ServerPlayer p, ItemStack stack) {
        if (p.getCooldowns().isOnCooldown(stack.getItem())) return;
        PlayerState st = state(p);
        Vec3 look = p.getLookAngle();

        Entity e = st.held;
        if (e != null && !e.isRemoved()) {
            st.held = null;
            launch(p, e, st.origNoGravity, st.origNoPhysics, look);
            p.getCooldowns().addCooldown(stack.getItem(), 12);
            return;
        }
        st.held = null;

        Target t = pick(p, PUNT_RANGE);
        if (t == null) {
            sound(p, SoundEvents.DISPENSER_FAIL, 0.3f, 1.8f);
            return;
        }
        boolean ng = false;
        boolean np = false;
        e = t.entity;
        if (e == null) {
            e = grabBlock(p, t.block);
            if (e == null) {
                sound(p, SoundEvents.DISPENSER_FAIL, 0.3f, 1.8f);
                return;
            }
        } else {
            if (isHeldByAnyone(e)) return;
            ng = e.isNoGravity();
            np = e.noPhysics;
        }
        launch(p, e, ng, np, look);
        p.getCooldowns().addCooldown(stack.getItem(), 12);
    }

    private static void launch(ServerPlayer p, Entity e, boolean noGravity, boolean noPhysics, Vec3 look) {
        e.setNoGravity(noGravity);
        e.noPhysics = noPhysics;
        double power;
        if (e instanceof FallingBlockEntity fb) {
            power = 2.4;
            fb.setHurtsEntities(2.0f, 40);
        } else if (e instanceof ItemEntity || e instanceof ExperienceOrb) {
            power = 1.8;
        } else {
            double mass = Math.max(0.5, e.getBbWidth() * e.getBbWidth() * e.getBbHeight());
            power = Mth.clamp(2.0 / Math.pow(mass, 0.33), 0.9, 2.4);
        }
        Vec3 vel = look.scale(power).add(0, 0.12, 0);
        e.setDeltaMovement(vel);
        sync(e);
        e.fallDistance = 0;
        Thrown thrown = addThrown(e, p);
        if (e instanceof FallingBlockEntity fb2) {
            thrown.budget = Math.max(0.5f, fb2.getBlockState().getDestroySpeed(p.level(), fb2.blockPosition())) * 1.5;
        }

        ServerLevel level = p.serverLevel();
        Vec3 muzzle = p.getEyePosition().add(look.scale(1.2));
        level.sendParticles(ParticleTypes.CLOUD, muzzle.x, muzzle.y - 0.2, muzzle.z, 6, 0.1, 0.1, 0.1, 0.05);
        sound(p, SoundEvents.GENERIC_EXPLODE, 0.35f, 1.9f);
    }

    private static Thrown addThrown(Entity e, ServerPlayer p) {
        return addThrown(e, p.getUUID());
    }

    private static Thrown addThrown(Entity e, UUID owner) {
        removeThrown(e);
        Thrown t = new Thrown(e, owner);
        THROWN.add(t);
        return t;
    }

    private static void removeThrown(Entity e) {
        THROWN.removeIf(t -> t.entity == e);
    }

    private static boolean tickThrown(Thrown t) {
        Entity e = t.entity;
        if (e.isRemoved()) return false;
        t.age++;
        if (t.age > 100) return false;
        Level level = e.level();
        Vec3 lv = t.lastVel;
        double speed = lv.length();
        MinecraftServer server = e.getServer();
        ServerPlayer owner = server != null ? server.getPlayerList().getPlayer(t.owner) : null;
        DamageSources ds = level.damageSources();
        DamageSource source = owner != null ? ds.playerAttack(owner) : ds.generic();

        if (speed > 0.5) {
            AABB box = e.getBoundingBox().inflate(0.25);
            List<Entity> others = level.getEntities(e, box,
                    x -> x instanceof LivingEntity && x.isAlive() && !x.getUUID().equals(t.owner) && !x.isSpectator());
            for (Entity o : others) {
                if (!t.hit.add(o.getId())) continue;
                float dmg = (float) Math.min(24.0, speed * 5.0 * (e instanceof FallingBlockEntity ? 1.3 : 1.0));
                o.hurt(source, dmg);
                o.push(lv.x * 0.4, 0.25, lv.z * 0.4);
                sync(o);
                if (e instanceof FallingBlockEntity fb) {
                    if (speed > 1.2) {
                        shatter(fb, t);
                        return false;
                    }
                } else if (e instanceof LivingEntity self) {
                    self.hurt(ds.flyIntoWall(), dmg * 0.4f);
                }
                e.setDeltaMovement(lv.scale(0.45));
                sync(e);
            }
        }

        if (e instanceof LivingEntity le && t.age > 1 && speed > 0.55) {
            boolean ceiling = e.verticalCollision && !e.onGround();
            if (e.horizontalCollision || ceiling) {
                le.hurt(ds.flyIntoWall(), (float) ((speed - 0.4) * 9.0));
                if (level instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.POOF, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 8, 0.2, 0.2, 0.2, 0.05);
                }
                level.playSound(null, e.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.3f, 1.6f);
                return false;
            }
        }
        if (t.age > 3 && e.onGround() && e.getDeltaMovement().length() < 0.15) return false;
        return true;
    }

    private static void shatter(FallingBlockEntity fb, Thrown t) {
        Level level = fb.level();
        BlockState state = fb.getBlockState();
        BlockPos pos = fb.blockPosition();
        level.levelEvent(2001, pos, Block.getId(state));
        Block.popResource(level, pos, new ItemStack(state.getBlock()));
        DamageSources ds = level.damageSources();
        MinecraftServer server = fb.getServer();
        ServerPlayer owner = server != null ? server.getPlayerList().getPlayer(t.owner) : null;
        DamageSource source = owner != null ? ds.playerAttack(owner) : ds.generic();
        for (Entity o : level.getEntities(fb, fb.getBoundingBox().inflate(1.5),
                x -> x instanceof LivingEntity && x.isAlive() && !x.getUUID().equals(t.owner))) {
            if (t.hit.contains(o.getId())) continue;
            o.hurt(source, 4.0f);
        }
        fb.discard();
    }

    // ------------------------------------------------------------- magnet

    private static void magnet(ServerPlayer p, PlayerState st) {
        ServerLevel level = p.serverLevel();
        double radius = st.radius;
        AABB box = p.getBoundingBox().inflate(radius);
        Vec3 target = p.position().add(0, p.getBbHeight() * 0.5, 0);

        List<Entity> targets = new ArrayList<>(level.getEntitiesOfClass(ItemEntity.class, box));
        targets.addAll(level.getEntitiesOfClass(ExperienceOrb.class, box));

        for (Entity e : targets) {
            if (e.isRemoved()) continue;
            Vec3 to = target.subtract(e.position());
            double d = to.length();
            if (d > radius) continue;
            if (d < 1.4) {
                if (e instanceof ItemEntity ie) {
                    ie.setNoPickUpDelay();
                    ie.playerTouch(p);
                } else if (e instanceof ExperienceOrb orb) {
                    orb.playerTouch(p);
                }
                continue;
            }
            double speed = 0.3 + (1.0 - d / radius) * 0.5;
            Vec3 v = to.normalize().scale(speed).add(0, 0.04, 0);
            e.setDeltaMovement(v);
            sync(e);
            if (e instanceof ItemEntity ie) ie.setNoPickUpDelay();
        }
        if (p.tickCount % 6 == 0 && !targets.isEmpty()) {
            Vec3 f = p.getEyePosition().add(p.getLookAngle().scale(1.2));
            level.sendParticles(ParticleTypes.GLOW, f.x, f.y - 0.3, f.z, 2, 0.15, 0.15, 0.15, 0.0);
        }
    }

    // ---------------------------------------------------------- shockwave

    private static void shockwave(ServerPlayer p, ItemStack stack) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double range = 12.0;
        DamageSource source = level.damageSources().playerAttack(p);

        List<Entity> list = level.getEntities(p, p.getBoundingBox().inflate(range),
                x -> x.isAlive() && !x.isSpectator() && !(x instanceof HangingEntity) && !(x instanceof EnderDragonPart));
        for (Entity e : list) {
            Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(eye);
            double d = to.length();
            if (d > range || d < 0.01) continue;
            if (to.normalize().dot(look) < 0.7) continue;
            double force = 0.6 + 2.2 * (1.0 - d / range);
            Vec3 push = look.scale(force).add(0, 0.35, 0);
            e.setDeltaMovement(e.getDeltaMovement().add(push));
            sync(e);
            if (e instanceof LivingEntity) {
                e.hurt(source, 2.0f);
                addThrown(e, p.getUUID());
            }
        }
        Vec3 c = eye.add(look.scale(2.0));
        level.sendParticles(ParticleTypes.SONIC_BOOM, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        for (int i = 1; i <= 6; i++) {
            Vec3 pt = eye.add(look.scale(i * 1.8));
            level.sendParticles(ParticleTypes.CLOUD, pt.x, pt.y, pt.z, 6, 0.3 + i * 0.12, 0.3 + i * 0.12, 0.3 + i * 0.12, 0.02);
        }
        sound(p, SoundEvents.GENERIC_EXPLODE, 0.6f, 0.7f);
        sound(p, SoundEvents.ENDER_DRAGON_FLAP, 1.0f, 0.8f);
        p.getCooldowns().addCooldown(stack.getItem(), 25);
    }

    // ----------------------------------------------------------- levitate

    private static void levitate(ServerPlayer p, ItemStack stack) {
        ServerLevel level = p.serverLevel();
        if (p.isShiftKeyDown()) {
            p.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 60, 1, false, true));
            p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 260, 0, false, false));
            level.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 0.2, p.getZ(), 20, 0.4, 0.1, 0.4, 0.05);
        } else {
            Target t = pick(p, GRAB_RANGE);
            Vec3 c = t != null ? t.point : p.getEyePosition().add(p.getLookAngle().scale(GRAB_RANGE));
            double r = 4.5;
            for (Entity e : level.getEntities(p, new AABB(c, c).inflate(r), x -> x.isAlive() && !x.isSpectator())) {
                if (e.position().distanceTo(c) > r + 1.0) continue;
                if (e instanceof LivingEntity le) {
                    le.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 100, 0, false, true));
                    le.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 300, 0, false, false));
                } else if (e instanceof ItemEntity || e instanceof FallingBlockEntity || e instanceof ExperienceOrb) {
                    e.setDeltaMovement(e.getDeltaMovement().add(0, 0.6, 0));
                    sync(e);
                }
            }
            for (int i = 0; i < 4; i++) {
                level.sendParticles(ParticleTypes.END_ROD, c.x, c.y + i * 0.6, c.z, 12, r * 0.5, 0.2, r * 0.5, 0.03);
            }
        }
        sound(p, SoundEvents.ENDERMAN_TELEPORT, 0.8f, 1.6f);
        p.getCooldowns().addCooldown(stack.getItem(), 40);
    }

    // -------------------------------------------------------- singularity

    private static void singularity(ServerPlayer p, ItemStack stack) {
        ServerLevel level = p.serverLevel();
        Target t = pick(p, GRAB_RANGE);
        Vec3 look = p.getLookAngle();
        Vec3 c = t != null ? t.point.subtract(look.scale(0.8)) : p.getEyePosition().add(look.scale(8.0));
        WELLS.removeIf(w -> w.owner.equals(p.getUUID()));
        WELLS.add(new Well(level, p.getUUID(), c, 100));
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 40, 0.6, 0.6, 0.6, 0.3);
        sound(p, SoundEvents.BEACON_ACTIVATE, 1.0f, 0.5f);
        sound(p, SoundEvents.ENDERMAN_TELEPORT, 0.8f, 0.5f);
        p.getCooldowns().addCooldown(stack.getItem(), 200);
    }

    private static boolean tickWell(Well w) {
        ServerLevel level = w.level;
        Vec3 c = w.pos;
        double radius = 9.0;
        MinecraftServer server = level.getServer();
        ServerPlayer owner = server.getPlayerList().getPlayer(w.owner);
        DamageSources ds = level.damageSources();
        DamageSource source = owner != null ? ds.indirectMagic(owner, owner) : ds.magic();
        boolean ending = w.ticks <= 1;

        AABB box = new AABB(c, c).inflate(radius);
        for (Entity e : level.getEntities((Entity) null, box, x -> x.isAlive() && canGrab(x) && !isHeldByAnyone(x))) {
            Vec3 center = e.position().add(0, e.getBbHeight() * 0.5, 0);
            Vec3 to = c.subtract(center);
            double d = to.length();
            if (d > radius) continue;
            if (ending) {
                Vec3 away = d < 0.01 ? new Vec3(0, 1, 0) : to.normalize().scale(-1.0);
                double force = 0.6 + 1.4 * (1.0 - d / radius);
                e.setDeltaMovement(away.scale(force).add(0, 0.35, 0));
                sync(e);
                if (e instanceof LivingEntity) addThrown(e, w.owner);
            } else {
                double f = Mth.clamp(1.4 / (d * 0.6 + 1.0), 0.15, 1.0) * 0.35;
                Vec3 dir = d < 0.05 ? Vec3.ZERO : to.normalize();
                e.setDeltaMovement(e.getDeltaMovement().scale(0.55).add(dir.scale(f * 1.6)));
                e.fallDistance = 0;
                sync(e);
                if (d < 1.8 && w.ticks % 10 == 0 && e instanceof LivingEntity) {
                    e.hurt(source, 2.0f);
                }
            }
        }
        if (ending) {
            level.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 3, 0.5, 0.5, 0.5, 0.0);
            level.sendParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 80, 0.4, 0.4, 0.4, 1.2);
            level.playSound(null, c.x, c.y, c.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.8f, 0.8f);
            return false;
        }
        level.sendParticles(ParticleTypes.PORTAL, c.x, c.y, c.z, 24, 1.5, 1.5, 1.5, 1.0);
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 4, 0.3, 0.3, 0.3, 0.1);
        if (w.ticks % 20 == 0) {
            level.playSound(null, c.x, c.y, c.z, SoundEvents.PORTAL_AMBIENT, SoundSource.PLAYERS, 0.8f, 0.6f);
        }
        w.ticks--;
        return true;
    }

    // ------------------------------------------------------------- cannon

    private static Vec3 muzzle(ServerPlayer p) {
        return p.getEyePosition().add(p.getLookAngle().scale(1.5)).add(0, -0.25, 0);
    }

    private static void chargeTick(ServerPlayer p, PlayerState st) {
        if (st.charge < CHARGE_OVER) st.charge++;
        ServerLevel level = p.serverLevel();
        float prog = Math.min(1f, st.charge / (float) CHARGE_FULL);
        Vec3 m = muzzle(p);
        if (st.charge % 8 == 0 && st.charge < CHARGE_FULL) {
            sound(p, SoundEvents.BEACON_AMBIENT, 0.6f, 0.6f + prog * 1.2f);
        }
        if (st.charge == CHARGE_MIN) sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0f, 1.4f);
        if (st.charge >= CHARGE_OVER) {
            // held too long: the cannon overloads and discharges by itself
            int c = st.charge;
            st.holding = false;
            st.charge = 0;
            fireBolt(p, p.getMainHandItem(), c);
            return;
        }
        if (st.charge == CHARGE_FULL) {
            sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0f, 2.0f);
        }
    }

    private static void fireBolt(ServerPlayer p, ItemStack stack, int charge) {
        float f = Mth.clamp((charge - CHARGE_MIN) / (float) (CHARGE_FULL - CHARGE_MIN), 0f, 1f);
        boolean over = charge >= CHARGE_OVER;
        float power = over ? 1.5f : 0.5f + 0.5f * f;
        Vec3 look = p.getLookAngle();
        Vec3 start = p.getEyePosition().add(look.scale(0.8)).add(0, -0.2, 0);
        ServerLevel level = p.serverLevel();
        BOLTS.add(new Bolt(level, p.getUUID(), start, look, power));
        Vec3 m = muzzle(p);
        sound(p, SoundEvents.FIREWORK_ROCKET_LARGE_BLAST, 1.0f, 0.7f);
        sound(p, SoundEvents.ENDER_DRAGON_SHOOT, 0.5f, 1.4f);
        if (over) {
            p.setDeltaMovement(p.getDeltaMovement().add(look.scale(-0.9)).add(0, 0.25, 0));
            p.hurtMarked = true;
        }
        p.getCooldowns().addCooldown(stack.getItem(), over ? 60 : 40);
    }

    private static boolean tickBolt(Bolt b) {
        ServerPlayer owner = ownerOf(b.level.getServer(), b.owner);
        if (owner == null || b.ticks++ > 70) return false;
        ServerLevel level = b.level;
        Vec3 end = b.pos.add(b.dir.scale(2.4));

        Vec3 impact = null;
        double best = Double.MAX_VALUE;
        BlockHitResult block = level.clip(new ClipContext(b.pos, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, owner));
        if (block.getType() == HitResult.Type.BLOCK) {
            impact = block.getLocation();
            best = b.pos.distanceToSqr(impact);
        }
        AABB sweep = new AABB(b.pos, end).inflate(0.8);
        for (Entity e : level.getEntities(owner, sweep, x -> x instanceof LivingEntity && x.isAlive() && !x.isSpectator())) {
            Optional<Vec3> c = e.getBoundingBox().inflate(0.35).clip(b.pos, end);
            if (c.isPresent()) {
                double d = b.pos.distanceToSqr(c.get());
                if (d < best) {
                    best = d;
                    impact = c.get();
                }
            }
        }

        if (impact != null) {
            explodeBolt(level, owner, impact.subtract(b.dir.scale(0.2)), b.power);
            return false;
        }
        b.pos = end;
        return true;
    }

    private static ServerPlayer ownerOf(MinecraftServer server, UUID owner) {
        return server != null ? server.getPlayerList().getPlayer(owner) : null;
    }

    private static void explodeBolt(ServerLevel level, ServerPlayer owner, Vec3 pos, float power) {
        double radius = 3.0 + 3.0 * power;
        DamageSource source = level.damageSources().playerAttack(owner);
        for (Entity e : level.getEntities(owner, new AABB(pos, pos).inflate(radius),
                x -> x.isAlive() && !x.isSpectator() && !(x instanceof HangingEntity) && !(x instanceof EnderDragonPart))) {
            Vec3 center = e.position().add(0, e.getBbHeight() * 0.5, 0);
            Vec3 d = center.subtract(pos);
            double dist = d.length();
            if (dist > radius) continue;
            double f = 1.0 - dist / radius;
            Vec3 dir = dist < 0.01 ? new Vec3(0, 1, 0) : d.normalize();
            if (e instanceof LivingEntity) {
                e.hurt(source, (float) (6.0 + 18.0 * power * f));
                addThrown(e, owner.getUUID());
            }
            e.setDeltaMovement(e.getDeltaMovement().add(dir.scale(1.6 * f + 0.5).add(0, 0.3, 0)));
            sync(e);
        }

        // crater: blocks up to a certain hardness are destroyed (stone yes, obsidian no)
        double blockRadius = 2.0 + 2.5 * power;
        float maxHardness = 1.5f + 4.5f * power;
        BlockPos center = BlockPos.containing(pos.x, pos.y, pos.z);
        int r = (int) Math.ceil(blockRadius);
        int broken = 0;
        outer:
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos bp = center.offset(dx, dy, dz);
                    if (bp.distToCenterSqr(pos.x, pos.y, pos.z) > blockRadius * blockRadius) continue;
                    BlockState st = level.getBlockState(bp);
                    if (st.isAir() || !st.getFluidState().isEmpty()) continue;
                    float h = st.getDestroySpeed(level, bp);
                    if (h < 0 || h > maxHardness) continue;
                    if (!breakAllowed(level, owner, bp, st)) continue;
                    level.destroyBlock(bp, true, owner);
                    if (++broken >= 250) break outer;
                }
            }
        }

        level.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 1, 0, 0, 0, 0);
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.2f, 0.9f);
    }

    // ------------------------------------------------------------- stasis

    private static void stasis(ServerPlayer p, ItemStack stack) {
        ServerLevel level = p.serverLevel();
        Target t = pick(p, GRAB_RANGE);
        Vec3 c = t != null ? t.point : p.getEyePosition().add(p.getLookAngle().scale(GRAB_RANGE));
        double r = 5.0;
        for (Entity e : level.getEntities(p, new AABB(c, c).inflate(r),
                x -> x instanceof LivingEntity && x.isAlive() && !x.isSpectator() && !(x instanceof Player))) {
            if (e.position().distanceTo(c) > r + 1.0) continue;
            LivingEntity le = (LivingEntity) e;
            le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 9, false, false));
            le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 9, false, false));
            le.addEffect(new MobEffectInstance(MobEffects.JUMP, 100, 128, false, false));
            e.setTicksFrozen(200);
            FROZEN.removeIf(f -> f.entity == e);
            FROZEN.add(new Frozen(e, 100));
        }
        level.sendParticles(ParticleTypes.SNOWFLAKE, c.x, c.y + 1.0, c.z, 40, r * 0.5, 1.0, r * 0.5, 0.02);
        sound(p, SoundEvents.GLASS_BREAK, 0.7f, 1.6f);
        sound(p, SoundEvents.ENDERMAN_TELEPORT, 0.6f, 1.9f);
        p.getCooldowns().addCooldown(stack.getItem(), 60);
    }

    private static boolean tickFrozen(Frozen f) {
        Entity e = f.entity;
        if (e.isRemoved() || --f.ticks <= 0) return false;
        if (e instanceof Mob mob) {
            mob.setTarget(null);
            mob.getNavigation().stop();
        }
        Vec3 v = e.getDeltaMovement();
        e.setDeltaMovement(0, v.y < 0 ? v.y : 0, 0);
        if (f.ticks % 20 == 0) e.setTicksFrozen(200);
        if (f.ticks % 6 == 0 && e.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.SNOWFLAKE, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 2,
                    e.getBbWidth() * 0.4, e.getBbHeight() * 0.4, e.getBbWidth() * 0.4, 0.0);
        }
        return true;
    }

    // ------------------------------------------------------------ grapple

    private static void startGrapple(ServerPlayer p, PlayerState st) {
        Target t = pick(p, 48.0);
        if (t == null) {
            deny(p);
            return;
        }
        st.grappleTicks = 0;
        if (t.entity != null) {
            if (!(t.entity instanceof LivingEntity) || isHeldByAnyone(t.entity)) {
                deny(p);
                return;
            }
            st.grappleEntity = t.entity;
        } else {
            st.grapplePoint = t.point;
        }
        sound(p, SoundEvents.BEACON_ACTIVATE, 0.6f, 1.6f);
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new FeedbackPacket(FeedbackPacket.GRAB_OK));
    }

    private static void endGrapple(ServerPlayer p, PlayerState st) {
        st.grapplePoint = null;
        st.grappleEntity = null;
        st.grappleTicks = 0;
        st.holding = false;
        p.fallDistance = 0;
        sound(p, SoundEvents.BEACON_DEACTIVATE, 0.5f, 1.8f);
    }

    private static void grappleTick(ServerPlayer p, PlayerState st) {
        if (st.grapplePoint == null && st.grappleEntity == null) return;
        if (++st.grappleTicks > 50) {
            endGrapple(p, st);
            return;
        }
        ServerLevel level = p.serverLevel();
        Vec3 target;
        if (st.grappleEntity != null) {
            Entity e = st.grappleEntity;
            if (e.isRemoved() || e.level() != p.level()) {
                endGrapple(p, st);
                return;
            }
            Vec3 to = p.position().add(0, 0.5, 0).subtract(e.position());
            double d = to.length();
            if (d < 2.5) {
                endGrapple(p, st);
                return;
            }
            e.setDeltaMovement(to.normalize().scale(Math.min(1.3, 0.5 + d * 0.04)).add(0, 0.08, 0));
            e.fallDistance = 0;
            sync(e);
            target = e.position().add(0, e.getBbHeight() * 0.5, 0);
        } else {
            target = st.grapplePoint;
            Vec3 to = target.subtract(p.position().add(0, p.getBbHeight() * 0.5, 0));
            double d = to.length();
            if (d < 2.5) {
                endGrapple(p, st);
                return;
            }
            p.setDeltaMovement(to.normalize().scale(Math.min(1.2, 0.45 + d * 0.04)));
            p.fallDistance = 0;
            p.hurtMarked = true;
        }
        if (p.tickCount % 2 == 0) {
            Vec3 from = p.getEyePosition().add(p.getLookAngle().scale(1.0)).add(0, -0.3, 0);
            for (int i = 1; i <= 3; i++) {
                Vec3 pt = from.add(target.subtract(from).scale(i / 4.0));
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, pt.x, pt.y, pt.z, 1, 0.05, 0.05, 0.05, 0.0);
            }
        }
    }

    // ------------------------------------------------------------- shield

    private static void shieldTick(ServerPlayer p, PlayerState st) {
        ServerLevel level = p.serverLevel();
        double radius = 4.5;
        Vec3 c = p.position().add(0, p.getBbHeight() * 0.5, 0);
        for (Entity e : level.getEntities(p, p.getBoundingBox().inflate(radius),
                x -> x.isAlive() && !x.isSpectator() && !(x instanceof Player) && !(x instanceof HangingEntity)
                        && !(x instanceof ItemEntity) && !(x instanceof ExperienceOrb) && !isHeldByAnyone(x))) {
            Vec3 away = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(c);
            double d = away.length();
            if (d > radius || d < 0.01) continue;
            away = away.normalize();
            if (e instanceof Projectile proj) {
                Vec3 v = proj.getDeltaMovement();
                if (v.dot(away) < 0) {
                    proj.setDeltaMovement(away.scale(Math.max(0.8, v.length())));
                    proj.setOwner(p);
                    sync(proj);
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, e.getX(), e.getY(), e.getZ(), 6, 0.2, 0.2, 0.2, 0.2);
                }
            } else {
                double f = 0.12 + 0.35 * (1.0 - d / radius);
                e.setDeltaMovement(e.getDeltaMovement().add(away.x * f, 0.03, away.z * f));
                sync(e);
            }
        }
        if (p.tickCount % 3 == 0) {
            for (int i = 0; i < 6; i++) {
                double ang = p.getRandom().nextDouble() * Math.PI * 2.0;
                double h = (p.getRandom().nextDouble() - 0.5) * 2.0;
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x + Math.cos(ang) * radius, c.y + h, c.z + Math.sin(ang) * radius, 1, 0, 0, 0, 0.0);
            }
        }
        if (p.tickCount % 30 == 0) sound(p, SoundEvents.BEACON_AMBIENT, 0.5f, 1.4f);
    }

    // ------------------------------------------------------------ helpers

    /** Forces the tracker to send position/velocity of this entity right now (needed for smooth movement). */
    private static void sync(Entity e) {
        e.hurtMarked = true;
        e.hasImpulse = true;
    }

    private static void deny(ServerPlayer p) {
        sound(p, SoundEvents.DISPENSER_FAIL, 0.4f, 1.6f);
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new FeedbackPacket(FeedbackPacket.DENY));
    }

    private static void sound(ServerPlayer p, net.minecraft.sounds.SoundEvent ev, float vol, float pitch) {
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), ev, SoundSource.PLAYERS, vol, pitch);
    }
}
