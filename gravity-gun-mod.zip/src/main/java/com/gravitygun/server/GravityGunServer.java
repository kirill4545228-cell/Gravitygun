package com.gravitygun.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.gravitygun.GravityGunItem;
import com.gravitygun.GravityMode;
import com.gravitygun.network.ActionPacket;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageSources;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.EnderDragonPart;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.level.BlockEvent;

/** All server side behaviour of the gravity gun. Everything runs on the server thread. */
public final class GravityGunServer {
    private GravityGunServer() {}

    private static final double GRAB_RANGE = 16.0;
    private static final double PUNT_RANGE = 24.0;

    // ------------------------------------------------------------------ state

    static final class PlayerState {
        boolean holding;
        Entity held;
        boolean origNoGravity;
        boolean origNoPhysics;
        double distance = 5.0;
        double radius = 10.0;
        Vec3 vel = Vec3.ZERO;
    }

    static final class Thrown {
        final Entity entity;
        final UUID owner;
        int age;
        Vec3 lastVel = Vec3.ZERO;
        final Set<Integer> hit = new HashSet<>();

        Thrown(Entity entity, UUID owner) {
            this.entity = entity;
            this.owner = owner;
        }
    }

    static final class Well {
        final ServerLevel level;
        final UUID owner;
        final Vec3 pos;
        int ticks;

        Well(ServerLevel level, UUID owner, Vec3 pos, int ticks) {
            this.level = level;
            this.owner = owner;
            this.pos = pos;
            this.ticks = ticks;
        }
    }

    private static final Map<UUID, PlayerState> STATES = new HashMap<>();
    private static final List<Thrown> THROWN = new ArrayList<>();
    private static final List<Well> WELLS = new ArrayList<>();

    private static PlayerState state(ServerPlayer p) {
        return STATES.computeIfAbsent(p.getUUID(), id -> new PlayerState());
    }

    public static void clearAll(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            PlayerState st = STATES.get(p.getUUID());
            if (st != null) {
                st.holding = false;
                releaseHeld(p, st, null);
            }
        }
        STATES.clear();
        THROWN.clear();
        WELLS.clear();
    }

    public static void forget(ServerPlayer p) {
        PlayerState st = STATES.remove(p.getUUID());
        if (st != null) {
            st.holding = false;
            releaseHeld(p, st, null);
        }
    }

    // ---------------------------------------------------------------- packets

    public static void handleAction(ServerPlayer p, ActionPacket.Action action, int value) {
        ItemStack stack = p.getMainHandItem();
        boolean gun = stack.getItem() instanceof GravityGunItem;
        switch (action) {
            case HOLD -> {
                if (value != 0 && gun) startHold(p, stack);
                else stopHold(p);
            }
            case FIRE -> {
                if (gun) fire(p, stack);
            }
            case SCROLL -> {
                if (gun) scroll(p, stack, value);
            }
            case MODE -> {
                if (gun) changeMode(p, stack, value);
            }
        }
    }

    private static void startHold(ServerPlayer p, ItemStack stack) {
        PlayerState st = state(p);
        if (st.holding) return;
        GravityMode mode = GravityGunItem.getMode(stack);
        if (mode.instant) {
            if (p.getCooldowns().isOnCooldown(stack.getItem())) return;
            switch (mode) {
                case SHOCKWAVE -> shockwave(p, stack);
                case LEVITATE -> levitate(p, stack);
                case SINGULARITY -> singularity(p, stack);
                default -> {}
            }
            return;
        }
        st.holding = true;
        if (mode == GravityMode.GRAB) {
            tryGrab(p, st);
        } else if (mode == GravityMode.MAGNET) {
            sound(p, SoundEvents.BEACON_ACTIVATE, 0.4f, 1.9f);
        }
    }

    private static void stopHold(ServerPlayer p) {
        PlayerState st = STATES.get(p.getUUID());
        if (st == null) return;
        st.holding = false;
        releaseHeld(p, st, null);
    }

    private static void changeMode(ServerPlayer p, ItemStack stack, int dir) {
        PlayerState st = state(p);
        st.holding = false;
        releaseHeld(p, st, null);
        GravityMode mode = GravityGunItem.getMode(stack).shift(dir >= 0 ? 1 : -1);
        GravityGunItem.setMode(stack, mode);
        p.displayClientMessage(Component.translatable("message.gravitygun.mode", mode.displayName()), true);
        sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0f, 0.8f + 0.2f * mode.ordinal());
    }

    private static void scroll(ServerPlayer p, ItemStack stack, int dir) {
        PlayerState st = state(p);
        GravityMode mode = GravityGunItem.getMode(stack);
        if (mode == GravityMode.GRAB) {
            st.distance = Mth.clamp(st.distance + dir * 0.75, 1.5, 14.0);
        } else if (mode == GravityMode.MAGNET) {
            st.radius = Mth.clamp(st.radius + dir * 1.5, 3.0, 16.0);
            p.displayClientMessage(Component.translatable("message.gravitygun.radius", String.format("%.1f", st.radius)), true);
        }
    }

    // ------------------------------------------------------------ ticking

    public static void tickPlayer(ServerPlayer p) {
        PlayerState st = STATES.get(p.getUUID());
        if (st == null || !st.holding) return;
        ItemStack stack = p.getMainHandItem();
        if (!(stack.getItem() instanceof GravityGunItem) || !p.isAlive()) {
            st.holding = false;
            releaseHeld(p, st, null);
            return;
        }
        GravityMode mode = GravityGunItem.getMode(stack);
        if (mode == GravityMode.GRAB) updateHeld(p, st);
        else if (mode == GravityMode.MAGNET) magnet(p, st);
    }

    public static void serverTickStart() {
        Iterator<Thrown> it = THROWN.iterator();
        while (it.hasNext()) {
            Thrown t = it.next();
            Entity e = t.entity;
            if (e.isRemoved()) {
                it.remove();
                continue;
            }
            t.lastVel = e.getDeltaMovement();
            if (e instanceof FallingBlockEntity fb && t.age >= 1 && t.lastVel.length() > 0.8) {
                AABB box = fb.getBoundingBox().expandTowards(t.lastVel);
                if (!fb.level().noCollision(fb, box)) {
                    shatter(fb, t);
                    it.remove();
                }
            }
        }
    }

    public static void serverTickEnd() {
        Iterator<Thrown> it = THROWN.iterator();
        while (it.hasNext()) {
            Thrown t = it.next();
            if (!tickThrown(t)) it.remove();
        }
        Iterator<Well> wi = WELLS.iterator();
        while (wi.hasNext()) {
            Well w = wi.next();
            if (!tickWell(w)) wi.remove();
        }
    }

    // ------------------------------------------------------------ grabbing

    private static final class Target {
        Entity entity;
        BlockPos block;
        Vec3 point;
        double dist;
    }

    private static Target pick(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(range));
        Level level = p.level();

        Target best = null;
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, p));
        if (hit.getType() == HitResult.Type.BLOCK) {
            best = new Target();
            best.block = hit.getBlockPos();
            best.point = hit.getLocation();
            best.dist = eye.distanceTo(hit.getLocation());
        }

        AABB search = p.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0);
        Entity found = null;
        double foundDist = best != null ? best.dist : range;
        Vec3 foundPoint = null;
        for (Entity e : level.getEntities(p, search, x -> x.isAlive() && !x.isSpectator() && canGrab(x))) {
            AABB bb = e.getBoundingBox().inflate(Math.max(0.3, e.getPickRadius()));
            Optional<Vec3> clip = bb.clip(eye, end);
            Vec3 pt = null;
            if (clip.isPresent()) pt = clip.get();
            else if (bb.contains(eye)) pt = eye;
            if (pt == null) continue;
            double d = eye.distanceTo(pt);
            if (d <= foundDist) {
                foundDist = d;
                found = e;
                foundPoint = pt;
            }
        }
        if (found != null) {
            Target t = new Target();
            t.entity = found;
            t.point = foundPoint;
            t.dist = foundDist;
            return t;
        }
        return best;
    }

    private static boolean canGrab(Entity e) {
        if (e instanceof Player || e instanceof EnderDragon || e instanceof EnderDragonPart) return false;
        if (e instanceof HangingEntity) return false;
        if (e.isPassenger() || e.isVehicle()) return false;
        return !e.isRemoved();
    }

    private static boolean isHeldByAnyone(Entity e) {
        for (PlayerState st : STATES.values()) {
            if (st.held == e) return true;
        }
        return false;
    }

    private static boolean canGrabBlock(ServerPlayer p, Level level, BlockPos pos, BlockState state) {
        if (state.isAir() || !state.getFluidState().isEmpty()) return false;
        if (state.hasBlockEntity()) return false;
        float hardness = state.getDestroySpeed(level, pos);
        if (hardness < 0 || hardness > 50) return false;
        if (!state.isCollisionShapeFullBlock(level, pos)) return false;
        if (!p.mayBuild()) return false;
        return level.mayInteract(p, pos);
    }

    private static FallingBlockEntity grabBlock(ServerPlayer p, BlockPos pos) {
        ServerLevel level = p.serverLevel();
        BlockState state = level.getBlockState(pos);
        if (!canGrabBlock(p, level, pos, state)) return null;
        if (MinecraftForge.EVENT_BUS.post(new BlockEvent.BreakEvent(level, pos, state, p))) return null;
        return FallingBlockEntity.fall(level, pos, state);
    }

    private static void tryGrab(ServerPlayer p, PlayerState st) {
        Target t = pick(p, GRAB_RANGE);
        if (t == null) {
            sound(p, SoundEvents.DISPENSER_FAIL, 0.4f, 1.6f);
            return;
        }
        Entity e = t.entity;
        if (e == null) {
            e = grabBlock(p, t.block);
            if (e == null) {
                sound(p, SoundEvents.DISPENSER_FAIL, 0.4f, 1.6f);
                return;
            }
        } else if (isHeldByAnyone(e)) {
            return;
        }
        removeThrown(e);
        st.held = e;
        st.origNoGravity = e.isNoGravity();
        st.origNoPhysics = e.noPhysics;
        e.setNoGravity(true);
        if (e instanceof FallingBlockEntity) e.noPhysics = true;
        st.distance = Mth.clamp(p.getEyePosition().distanceTo(e.position()), 2.0, 12.0);
        st.vel = Vec3.ZERO;
        sound(p, SoundEvents.BEACON_ACTIVATE, 0.5f, 2.0f);
    }

    private static void updateHeld(ServerPlayer p, PlayerState st) {
        Entity e = st.held;
        if (e == null) return;
        if (e.isRemoved() || e.level() != p.level()) {
            st.held = null;
            return;
        }
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double dist = st.distance;
        double margin = Math.max(e.getBbWidth(), e.getBbHeight()) * 0.5 + 0.15;

        BlockHitResult hit = p.level().clip(new ClipContext(eye, eye.add(look.scale(dist)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (hit.getType() != HitResult.Type.MISS) {
            dist = Math.max(1.0, Math.min(dist, eye.distanceTo(hit.getLocation()) - margin));
        }
        Vec3 target = eye.add(look.scale(dist));
        Vec3 goal = new Vec3(target.x, target.y - e.getBbHeight() * 0.5, target.z);
        Vec3 old = e.position();
        Vec3 next = old.add(goal.subtract(old).scale(0.55));
        st.vel = next.subtract(old);
        if (st.vel.length() > 1.2) st.vel = st.vel.normalize().scale(1.2);

        e.setNoGravity(true);
        e.moveTo(next.x, next.y, next.z);
        e.setDeltaMovement(Vec3.ZERO);
        e.fallDistance = 0;
        sync(e);

        if (e instanceof FallingBlockEntity fb) {
            fb.time = 1;
        }
        if (e instanceof Mob mob) {
            mob.setTarget(null);
            mob.getNavigation().stop();
        }
        if (e instanceof LivingEntity le && p.tickCount % 10 == 0) {
            le.addEffect(new MobEffectInstance(MobEffects.GLOWING, 15, 0, false, false));
        }
        if (p.tickCount % 2 == 0) {
            Vec3 from = eye.add(look.scale(1.0)).add(0, -0.35, 0);
            Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0);
            double f = p.getRandom().nextDouble();
            Vec3 pt = from.add(to.subtract(from).scale(f));
            p.serverLevel().sendParticles(ParticleTypes.ELECTRIC_SPARK, pt.x, pt.y, pt.z, 1, 0.05, 0.05, 0.05, 0.0);
        }
    }

    private static void releaseHeld(ServerPlayer p, PlayerState st, Vec3 launchVel) {
        Entity e = st.held;
        st.held = null;
        if (e == null || e.isRemoved()) return;
        e.setNoGravity(st.origNoGravity);
        e.noPhysics = st.origNoPhysics;
        e.setDeltaMovement(st.vel.scale(0.8));
        sync(e);
        sound(p, SoundEvents.BEACON_DEACTIVATE, 0.4f, 2.0f);
    }

    // ------------------------------------------------------------- firing

    private static void fire(ServerPlayer p, ItemStack stack) {
        if (p.getCooldowns().isOnCooldown(stack.getItem())) return;
        PlayerState st = state(p);
        Vec3 look = p.getLookAngle();

        Entity e = st.held;
        if (e != null && !e.isRemoved()) {
            st.held = null;
            launch(p, e, st.origNoGravity, st.origNoPhysics, look);
            p.getCooldowns().addCooldown(stack.getItem(), 12);
            return;
        }
        st.held = null;

        Target t = pick(p, PUNT_RANGE);
        if (t == null) {
            sound(p, SoundEvents.DISPENSER_FAIL, 0.3f, 1.8f);
            return;
        }
        boolean ng = false;
        boolean np = false;
        e = t.entity;
        if (e == null) {
            e = grabBlock(p, t.block);
            if (e == null) {
                sound(p, SoundEvents.DISPENSER_FAIL, 0.3f, 1.8f);
                return;
            }
        } else {
            if (isHeldByAnyone(e)) return;
            ng = e.isNoGravity();
            np = e.noPhysics;
        }
        launch(p, e, ng, np, look);
        p.getCooldowns().addCooldown(stack.getItem(), 12);
    }

    private static void launch(ServerPlayer p, Entity e, boolean noGravity, boolean noPhysics, Vec3 look) {
        e.setNoGravity(noGravity);
        e.noPhysics = noPhysics;
        double power;
        if (e instanceof FallingBlockEntity fb) {
            power = 2.4;
            fb.setHurtsEntities(2.0f, 40);
        } else if (e instanceof ItemEntity || e instanceof ExperienceOrb) {
            power = 1.8;
        } else {
            double mass = Math.max(0.5, e.getBbWidth() * e.getBbWidth() * e.getBbHeight());
            power = Mth.clamp(2.0 / Math.pow(mass, 0.33), 0.9, 2.4);
        }
        Vec3 vel = look.scale(power).add(0, 0.12, 0);
        e.setDeltaMovement(vel);
        sync(e);
        e.fallDistance = 0;
        addThrown(e, p);

        ServerLevel level = p.serverLevel();
        Vec3 muzzle = p.getEyePosition().add(look.scale(1.2));
        level.sendParticles(ParticleTypes.CLOUD, muzzle.x, muzzle.y - 0.2, muzzle.z, 6, 0.1, 0.1, 0.1, 0.05);
        sound(p, SoundEvents.GENERIC_EXPLODE, 0.35f, 1.9f);
    }

    private static void addThrown(Entity e, ServerPlayer p) {
        removeThrown(e);
        THROWN.add(new Thrown(e, p.getUUID()));
    }

    private static void addThrown(Entity e, UUID owner) {
        removeThrown(e);
        THROWN.add(new Thrown(e, owner));
    }

    private static void removeThrown(Entity e) {
        THROWN.removeIf(t -> t.entity == e);
    }

    private static boolean tickThrown(Thrown t) {
        Entity e = t.entity;
        if (e.isRemoved()) return false;
        t.age++;
        if (t.age > 100) return false;
        Level level = e.level();
        Vec3 lv = t.lastVel;
        double speed = lv.length();
        MinecraftServer server = e.getServer();
        ServerPlayer owner = server != null ? server.getPlayerList().getPlayer(t.owner) : null;
        DamageSources ds = level.damageSources();
        DamageSource source = owner != null ? ds.playerAttack(owner) : ds.generic();

        if (speed > 0.5) {
            AABB box = e.getBoundingBox().inflate(0.25);
            List<Entity> others = level.getEntities(e, box,
                    x -> x instanceof LivingEntity && x.isAlive() && !x.getUUID().equals(t.owner) && !x.isSpectator());
            for (Entity o : others) {
                if (!t.hit.add(o.getId())) continue;
                float dmg = (float) Math.min(24.0, speed * 5.0 * (e instanceof FallingBlockEntity ? 1.3 : 1.0));
                o.hurt(source, dmg);
                o.push(lv.x * 0.4, 0.25, lv.z * 0.4);
                sync(o);
                if (e instanceof FallingBlockEntity fb) {
                    if (speed > 1.2) {
                        shatter(fb, t);
                        return false;
                    }
                } else if (e instanceof LivingEntity self) {
                    self.hurt(ds.flyIntoWall(), dmg * 0.4f);
                }
                e.setDeltaMovement(lv.scale(0.45));
                sync(e);
            }
        }

        if (e instanceof LivingEntity le && t.age > 1 && speed > 0.55) {
            boolean ceiling = e.verticalCollision && !e.onGround();
            if (e.horizontalCollision || ceiling) {
                le.hurt(ds.flyIntoWall(), (float) ((speed - 0.4) * 9.0));
                if (level instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.POOF, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 8, 0.2, 0.2, 0.2, 0.05);
                }
                level.playSound(null, e.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.3f, 1.6f);
                return false;
            }
        }
        if (t.age > 3 && e.onGround() && e.getDeltaMovement().length() < 0.15) return false;
        return true;
    }

    private static void shatter(FallingBlockEntity fb, Thrown t) {
        Level level = fb.level();
        BlockState state = fb.getBlockState();
        BlockPos pos = fb.blockPosition();
        level.levelEvent(2001, pos, Block.getId(state));
        Block.popResource(level, pos, new ItemStack(state.getBlock()));
        DamageSources ds = level.damageSources();
        MinecraftServer server = fb.getServer();
        ServerPlayer owner = server != null ? server.getPlayerList().getPlayer(t.owner) : null;
        DamageSource source = owner != null ? ds.playerAttack(owner) : ds.generic();
        for (Entity o : level.getEntities(fb, fb.getBoundingBox().inflate(1.5),
                x -> x instanceof LivingEntity && x.isAlive() && !x.getUUID().equals(t.owner))) {
            if (t.hit.contains(o.getId())) continue;
            o.hurt(source, 4.0f);
        }
        fb.discard();
    }

    // ------------------------------------------------------------- magnet

    private static void magnet(ServerPlayer p, PlayerState st) {
        ServerLevel level = p.serverLevel();
        double radius = st.radius;
        AABB box = p.getBoundingBox().inflate(radius);
        Vec3 target = p.position().add(0, p.getBbHeight() * 0.5, 0);

        List<Entity> targets = new ArrayList<>(level.getEntitiesOfClass(ItemEntity.class, box));
        targets.addAll(level.getEntitiesOfClass(ExperienceOrb.class, box));

        for (Entity e : targets) {
            if (e.isRemoved()) continue;
            Vec3 to = target.subtract(e.position());
            double d = to.length();
            if (d > radius) continue;
            if (d < 1.4) {
                if (e instanceof ItemEntity ie) {
                    ie.setNoPickUpDelay();
                    ie.playerTouch(p);
                } else if (e instanceof ExperienceOrb orb) {
                    orb.playerTouch(p);
                }
                continue;
            }
            double speed = 0.3 + (1.0 - d / radius) * 0.5;
            Vec3 v = to.normalize().scale(speed).add(0, 0.04, 0);
            e.setDeltaMovement(v);
            sync(e);
            if (e instanceof ItemEntity ie) ie.setNoPickUpDelay();
        }
        if (p.tickCount % 6 == 0 && !targets.isEmpty()) {
            Vec3 f = p.getEyePosition().add(p.getLookAngle().scale(1.2));
            level.sendParticles(ParticleTypes.GLOW, f.x, f.y - 0.3, f.z, 2, 0.15, 0.15, 0.15, 0.0);
        }
    }

    // ---------------------------------------------------------- shockwave

    private static void shockwave(ServerPlayer p, ItemStack stack) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double range = 12.0;
        DamageSource source = level.damageSources().playerAttack(p);

        List<Entity> list = level.getEntities(p, p.getBoundingBox().inflate(range),
                x -> x.isAlive() && !x.isSpectator() && !(x instanceof HangingEntity) && !(x instanceof EnderDragonPart));
        for (Entity e : list) {
            Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(eye);
            double d = to.length();
            if (d > range || d < 0.01) continue;
            if (to.normalize().dot(look) < 0.7) continue;
            double force = 0.6 + 2.2 * (1.0 - d / range);
            Vec3 push = look.scale(force).add(0, 0.35, 0);
            e.setDeltaMovement(e.getDeltaMovement().add(push));
            sync(e);
            if (e instanceof LivingEntity) {
                e.hurt(source, 2.0f);
                addThrown(e, p.getUUID());
            }
        }
        Vec3 c = eye.add(look.scale(2.0));
        level.sendParticles(ParticleTypes.SONIC_BOOM, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        for (int i = 1; i <= 6; i++) {
            Vec3 pt = eye.add(look.scale(i * 1.8));
            level.sendParticles(ParticleTypes.CLOUD, pt.x, pt.y, pt.z, 6, 0.3 + i * 0.12, 0.3 + i * 0.12, 0.3 + i * 0.12, 0.02);
        }
        sound(p, SoundEvents.GENERIC_EXPLODE, 0.6f, 0.7f);
        sound(p, SoundEvents.ENDER_DRAGON_FLAP, 1.0f, 0.8f);
        p.getCooldowns().addCooldown(stack.getItem(), 25);
    }

    // ----------------------------------------------------------- levitate

    private static void levitate(ServerPlayer p, ItemStack stack) {
        ServerLevel level = p.serverLevel();
        if (p.isShiftKeyDown()) {
            p.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 60, 1, false, true));
            p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 260, 0, false, false));
            level.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 0.2, p.getZ(), 20, 0.4, 0.1, 0.4, 0.05);
        } else {
            Target t = pick(p, GRAB_RANGE);
            Vec3 c = t != null ? t.point : p.getEyePosition().add(p.getLookAngle().scale(GRAB_RANGE));
            double r = 4.5;
            for (Entity e : level.getEntities(p, new AABB(c, c).inflate(r), x -> x.isAlive() && !x.isSpectator())) {
                if (e.position().distanceTo(c) > r + 1.0) continue;
                if (e instanceof LivingEntity le) {
                    le.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 100, 0, false, true));
                    le.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 300, 0, false, false));
                } else if (e instanceof ItemEntity || e instanceof FallingBlockEntity || e instanceof ExperienceOrb) {
                    e.setDeltaMovement(e.getDeltaMovement().add(0, 0.6, 0));
                    sync(e);
                }
            }
            for (int i = 0; i < 4; i++) {
                level.sendParticles(ParticleTypes.END_ROD, c.x, c.y + i * 0.6, c.z, 12, r * 0.5, 0.2, r * 0.5, 0.03);
            }
        }
        sound(p, SoundEvents.ENDERMAN_TELEPORT, 0.8f, 1.6f);
        p.getCooldowns().addCooldown(stack.getItem(), 40);
    }

    // -------------------------------------------------------- singularity

    private static void singularity(ServerPlayer p, ItemStack stack) {
        ServerLevel level = p.serverLevel();
        Target t = pick(p, GRAB_RANGE);
        Vec3 look = p.getLookAngle();
        Vec3 c = t != null ? t.point.subtract(look.scale(0.8)) : p.getEyePosition().add(look.scale(8.0));
        WELLS.removeIf(w -> w.owner.equals(p.getUUID()));
        WELLS.add(new Well(level, p.getUUID(), c, 100));
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 40, 0.6, 0.6, 0.6, 0.3);
        sound(p, SoundEvents.BEACON_ACTIVATE, 1.0f, 0.5f);
        sound(p, SoundEvents.ENDERMAN_TELEPORT, 0.8f, 0.5f);
        p.getCooldowns().addCooldown(stack.getItem(), 200);
    }

    private static boolean tickWell(Well w) {
        ServerLevel level = w.level;
        Vec3 c = w.pos;
        double radius = 9.0;
        MinecraftServer server = level.getServer();
        ServerPlayer owner = server.getPlayerList().getPlayer(w.owner);
        DamageSources ds = level.damageSources();
        DamageSource source = owner != null ? ds.indirectMagic(owner, owner) : ds.magic();
        boolean ending = w.ticks <= 1;

        AABB box = new AABB(c, c).inflate(radius);
        for (Entity e : level.getEntities((Entity) null, box, x -> x.isAlive() && canGrab(x) && !isHeldByAnyone(x))) {
            Vec3 center = e.position().add(0, e.getBbHeight() * 0.5, 0);
            Vec3 to = c.subtract(center);
            double d = to.length();
            if (d > radius) continue;
            if (ending) {
                Vec3 away = d < 0.01 ? new Vec3(0, 1, 0) : to.normalize().scale(-1.0);
                double force = 0.6 + 1.4 * (1.0 - d / radius);
                e.setDeltaMovement(away.scale(force).add(0, 0.35, 0));
                sync(e);
                if (e instanceof LivingEntity) addThrown(e, w.owner);
            } else {
                double f = Mth.clamp(1.4 / (d * 0.6 + 1.0), 0.15, 1.0) * 0.35;
                Vec3 dir = d < 0.05 ? Vec3.ZERO : to.normalize();
                e.setDeltaMovement(e.getDeltaMovement().scale(0.55).add(dir.scale(f * 1.6)));
                e.fallDistance = 0;
                sync(e);
                if (d < 1.8 && w.ticks % 10 == 0 && e instanceof LivingEntity) {
                    e.hurt(source, 2.0f);
                }
            }
        }
        if (ending) {
            level.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 3, 0.5, 0.5, 0.5, 0.0);
            level.sendParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 80, 0.4, 0.4, 0.4, 1.2);
            level.playSound(null, c.x, c.y, c.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.8f, 0.8f);
            return false;
        }
        level.sendParticles(ParticleTypes.PORTAL, c.x, c.y, c.z, 24, 1.5, 1.5, 1.5, 1.0);
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 4, 0.3, 0.3, 0.3, 0.1);
        if (w.ticks % 20 == 0) {
            level.playSound(null, c.x, c.y, c.z, SoundEvents.PORTAL_AMBIENT, SoundSource.PLAYERS, 0.8f, 0.6f);
        }
        w.ticks--;
        return true;
    }

    // ------------------------------------------------------------ helpers

    /** Forces the tracker to send position/velocity of this entity right now (needed for smooth movement). */
    private static void sync(Entity e) {
        e.hurtMarked = true;
        e.hasImpulse = true;
    }

    private static void sound(ServerPlayer p, net.minecraft.sounds.SoundEvent ev, float vol, float pitch) {
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), ev, SoundSource.PLAYERS, vol, pitch);
    }
}
