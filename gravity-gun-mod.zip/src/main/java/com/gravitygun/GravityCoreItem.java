package com.gravitygun;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class GravityCoreItem extends Item {
    public GravityCoreItem(Properties properties) {
        super(properties);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
