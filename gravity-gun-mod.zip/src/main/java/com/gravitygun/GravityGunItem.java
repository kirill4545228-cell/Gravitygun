package com.gravitygun;

import java.util.List;
import java.util.function.Consumer;

import javax.annotation.Nullable;

import com.gravitygun.client.GunItemRenderer;

import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

public class GravityGunItem extends Item {
    public static final String TAG_MODE = "Mode";

    public GravityGunItem(Properties properties) {
        super(properties);
    }

    public static GravityMode getMode(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return GravityMode.byId(tag == null ? 0 : tag.getInt(TAG_MODE));
    }

    public static void setMode(ItemStack stack, GravityMode mode) {
        stack.getOrCreateTag().putInt(TAG_MODE, mode.ordinal());
    }

    /** The gun never breaks blocks. */
    @Override
    public boolean canAttackBlock(BlockState state, Level level, BlockPos pos, Player player) {
        return false;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return InteractionResultHolder.pass(player.getItemInHand(hand));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        GravityMode mode = getMode(stack);
        tooltip.add(Component.translatable("tooltip.gravitygun.mode", mode.displayName()).withStyle(ChatFormatting.AQUA));
        tooltip.add(mode.description().copy().withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.gravitygun.controls.rmb").withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.gravitygun.controls.lmb").withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.gravitygun.controls.mode").withStyle(ChatFormatting.DARK_GRAY));
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                return GunItemRenderer.get();
            }
        });
    }
}
