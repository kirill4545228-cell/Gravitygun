package com.gravitygun;

import net.minecraft.network.chat.Component;

/** Working modes of the gravity gun. Left click always launches, right click does the mode action. */
public enum GravityMode {
    GRAB("grab", 0.27f, 0.78f, 1.00f, false),
    MAGNET("magnet", 1.00f, 0.82f, 0.20f, false),
    SHOCKWAVE("shockwave", 1.00f, 0.30f, 0.25f, true),
    LEVITATE("levitate", 0.40f, 1.00f, 0.50f, true),
    SINGULARITY("singularity", 0.65f, 0.35f, 1.00f, true),
    /** Hold to charge a projectile, release to fire it. */
    CANNON("cannon", 1.00f, 0.30f, 0.70f, false),
    /** Freezes living things around the target for a few seconds. */
    STASIS("stasis", 0.35f, 0.55f, 1.00f, true),
    /** Hold to pull yourself to a block (or pull a mob to you). */
    GRAPPLE("grapple", 1.00f, 0.55f, 0.15f, false),
    /** Hold to push away mobs and reflect projectiles around you. */
    SHIELD("shield", 0.60f, 1.00f, 0.25f, false);

    public final String key;
    public final float r, g, b;
    /** Instant modes trigger once per right click, others work while the button is held. */
    public final boolean instant;

    GravityMode(String key, float r, float g, float b, boolean instant) {
        this.key = key;
        this.r = r;
        this.g = g;
        this.b = b;
        this.instant = instant;
    }

    public static GravityMode byId(int id) {
        GravityMode[] all = values();
        return all[Math.floorMod(id, all.length)];
    }

    public GravityMode shift(int dir) {
        return byId(ordinal() + dir);
    }

    /** Opaque ARGB colour of the mode (used by the HUD). */
    public int argb() {
        return 0xFF000000 | ((int) (r * 255f) << 16) | ((int) (g * 255f) << 8) | (int) (b * 255f);
    }

    public Component displayName() {
        return Component.translatable("mode.gravitygun." + key);
    }

    public Component description() {
        return Component.translatable("mode.gravitygun." + key + ".desc");
    }
}
