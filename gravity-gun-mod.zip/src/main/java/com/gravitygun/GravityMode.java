package com.gravitygun;

import net.minecraft.network.chat.Component;

/** Working modes of the gravity gun. Left click always launches, right click does the mode action. */
public enum GravityMode {
    GRAB("grab", 0.25f, 0.86f, 1.00f, false),
    MAGNET("magnet", 1.00f, 0.80f, 0.15f, false),
    SHOCKWAVE("shockwave", 1.00f, 0.40f, 0.15f, true),
    LEVITATE("levitate", 0.40f, 1.00f, 0.55f, true),
    SINGULARITY("singularity", 0.70f, 0.30f, 1.00f, true);

    public final String key;
    public final float r, g, b;
    /** Instant modes trigger once per right click, others work while the button is held. */
    public final boolean instant;

    GravityMode(String key, float r, float g, float b, boolean instant) {
        this.key = key;
        this.r = r;
        this.g = g;
        this.b = b;
        this.instant = instant;
    }

    public static GravityMode byId(int id) {
        GravityMode[] all = values();
        return all[Math.floorMod(id, all.length)];
    }

    public GravityMode shift(int dir) {
        return byId(ordinal() + dir);
    }

    public Component displayName() {
        return Component.translatable("mode.gravitygun." + key);
    }

    public Component description() {
        return Component.translatable("mode.gravitygun." + key + ".desc");
    }
}
