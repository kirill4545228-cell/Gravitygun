package com.gravitygun;

import com.gravitygun.network.ModNetwork;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(GravityGunMod.MODID)
public class GravityGunMod {
    public static final String MODID = "gravitygun";

    public GravityGunMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModItems.TABS.register(bus);
        ModNetwork.register();
    }
}
