package com.gravitygun.network;

import java.util.function.Supplier;

import com.gravitygun.server.GravityGunServer;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Client -> server: player input related to the gravity gun. */
public class ActionPacket {
    public enum Action { HOLD, FIRE, SCROLL, MODE }

    public final Action action;
    public final int value;

    public ActionPacket(Action action, int value) {
        this.action = action;
        this.value = value;
    }

    public static void encode(ActionPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.action.ordinal());
        buf.writeInt(msg.value);
    }

    public static ActionPacket decode(FriendlyByteBuf buf) {
        int id = buf.readVarInt();
        Action[] all = Action.values();
        Action action = all[Math.floorMod(id, all.length)];
        return new ActionPacket(action, buf.readInt());
    }

    public static void handle(ActionPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player != null) {
                GravityGunServer.handleAction(player, msg.action, msg.value);
            }
        });
        ctx.setPacketHandled(true);
    }
}
