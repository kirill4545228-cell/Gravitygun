package com.gravitygun.network;

import java.util.function.Supplier;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Server -> client: result of an action, so the first person animation can react (deny, grabbed...). */
public class FeedbackPacket {
    public static final int GRAB_OK = 1;
    public static final int DENY = 2;

    public final int code;

    public FeedbackPacket(int code) {
        this.code = code;
    }

    public static void encode(FeedbackPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.code);
    }

    public static FeedbackPacket decode(FriendlyByteBuf buf) {
        return new FeedbackPacket(buf.readVarInt());
    }

    public static void handle(FeedbackPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.gravitygun.client.ClientHooks.onFeedback(msg.code)));
        ctx.setPacketHandled(true);
    }
}
